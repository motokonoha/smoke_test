from ms import create_ms
import unittest
import math
from time import sleep
from mot_test import MotTestCase

class ms1_Attachments(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2"):
        super(ms1_Attachments, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 5

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
    
    def connect(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
    
    def test_001_switching_between_TMO_TG(self):
        self.connect()
        
        for i in range(self.loop):
            self.ms1.ChangeTG("TG1", async = True)
            self.ms2.ChangeTG("TG1")
            self.ms1.wait()

            self.ms1.MakeGC('TG1')
            self.ms2.VerifyIncomingGC(self.ms1, "TG1",1)
            self.ms1.ReleasePTT()
            self.ms2.VerifyOngoingGC('TG1')

            self.ms1.ChangeTG("TG2", async = True)
            self.ms2.ChangeTG("TG2")
            self.ms1.wait()

            self.ms2.MakeGC('TG2')
            self.ms1.VerifyIncomingGC(self.ms2,"TG2",1)
            self.ms2.ReleasePTT()
            self.ms1.VerifyOngoingGC('TG2')
            
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
    
    def test_002_switching_between_modes(self):
        self.connect()
        dmo_mode = self.ms1.IsDMOMode()
        rep_mode = self.ms1.IsREPMode()
        gw_mode = self.ms1.IsGWMode()
        for i in range(math.floor(self.loop/2)):

            if dmo_mode:
                self.ms1.EnterDMO()
                self.ms1.VerifyDMOIdle("DTG_H1_1")
                self.ms1.EnterTMO()
                self.ms1.VerifyTMOIdle("TG1")
                self.ms1.MakeGC('TG1')
                self.ms2.VerifyIncomingGC(self.ms1, "TG1", 1)
                self.ms1.ReleasePTT()
                self.ms2.VerifyOngoingGC('TG1')         
            
            if rep_mode:    
                self.ms1.EnterREP()
                self.ms1.VerifyREPIdle("DTG_H1_1")
                self.ms1.EnterTMO()
                self.ms1.VerifyTMOIdle("TG1")
                self.ms1.MakeGC('TG1')
                self.ms2.VerifyIncomingGC(self.ms1, "TG1", 1)
                self.ms1.ReleasePTT()
                self.ms2.VerifyOngoingGC('TG1') 

            if gw_mode:    
                self.ms1.EnterGW()
                self.ms1.IsTextOnScreen(["Gateway monitor", "Please Wait"])
                self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
                self.ms1.EnterTMO()
                self.ms1.VerifyTMOIdle("TG1")
                self.ms1.MakeGC('TG1')
                self.ms2.VerifyIncomingGC(self.ms1, "TG1", 1)
                self.ms1.ReleasePTT()
                self.ms2.VerifyOngoingGC('TG1')

                
class ms2_Attachments(ms1_Attachments):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_Attachments, self).__init__(testname, ms1_cfg, ms2_cfg)
        
class ms3_Attachments(ms1_Attachments):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_Attachments, self).__init__(testname, ms1_cfg, ms2_cfg)                