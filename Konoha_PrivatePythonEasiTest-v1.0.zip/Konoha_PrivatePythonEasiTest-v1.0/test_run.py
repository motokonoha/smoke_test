import argparse, os, zipfile
import configparser
import xmlrunner
from mot_test import get_tests_from_xml, get_tests_from_list
import re

def print_stats(junit_name, outsuffix):
    base, ext = os.path.splitext(junit_name)
    filename = base+"-"+outsuffix+ext
    ms1 = ""
    ms2 = ""
    ms3 = ""
    with open(filename, "rb") as f:
        txt = f.read()
        m = re.search(b'ms1\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms1 = m.group(1).decode()
        m = re.search(b'ms2\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms2 = m.group(1).decode()
        m = re.search(b'ms3\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms3 = m.group(1).decode()

        m = re.findall(b'Detected (\d+) ResetLog', txt, re.M|re.I)
        resets = 0
        if m:
            for p in m:
                resets += int(p)

        m = re.findall(b'<testcase', txt, re.M|re.I)
        tests = 0
        if m:
            for p in m:
                tests += 1

        m = re.findall(b'<error', txt, re.M|re.I)
        fails = 0
        if m:
            for p in m:
                fails += 1

        m = re.findall(b'<skipped', txt, re.M|re.I)
        skipped = 0
        if m:
            for p in m:
                skipped += 1

    print("ms1: "+ms1+" ms2: "+ms2+" ms3: "+ms3 + " resets: "+str(resets) + " pass: "+str(tests-fails-skipped) + " ("+str(round((((tests-fails-skipped)*100)/tests),1))+"%)" + " fail: "+str(fails)+" ("+str(round(((fails*100)/tests),1))+"%)" + " skip: "+str(skipped)+" ("+str(round(((skipped*100)//tests),1))+"%)" + " total: "+str(tests))

def zip_logs(dir, zip_file, name_filter = None):
    zip = zipfile.ZipFile(zip_file, 'w', compression=zipfile.ZIP_DEFLATED)
    root_len = len(os.path.abspath(dir))
    for root, dirs, files in os.walk(dir):
        archive_root = os.path.abspath(root)[root_len:]
        for f in files:
            if name_filter is not None and name_filter not in f:
                continue
            fullpath = os.path.join(root, f)
            archive_name = os.path.join(archive_root, f)
            zip.write(fullpath, archive_name, zipfile.ZIP_DEFLATED)
    zip.close()
    return zip_file

def zip_resetLogs(dir, zip_file):
    zip_logs(dir, zip_file, name_filter = "DspResetLog")

def getRadioType(cfgs_path, ms):
    ini_path = os.path.join(cfgs_path, ms) + ".ini"
    config = configparser.ConfigParser()
    config.read(ini_path)
    return config["MS"]["Name"]

def parseResetLogs(arguments, outsuffix):

    # Read list of resetLogs
    resets = []
    base, ext = os.path.splitext(junit_name)
    fname = base+"-"+outsuffix+ext
    fcontent = open(fname, "rb").read().splitlines()
    for line in fcontent:
        if b"ResetLog saved" not in line: continue
        if b"DspResetLog" not in line: continue
        line = line.decode("utf-8").split(" ")
        MS, resetFile = line[1].replace(":", ""), line[-1]
        resets.append((MS, resetFile))

    # Print descriptions
    if len(resets) != 0:
        print("Parsing %d resetLogs:\n" % len(resets))
        print("-"*20)

    # Parse resetLogs
    for (MS, resetFile) in resets:
        try:
            # Prepare map file and ResetLog descriptor for given MS
            MS_type = getRadioType(arguments.cfgs, MS)
            MS_map, MS_descriptor = None, None
            if MS_type == "Frodo":
                MS_map = arguments.frodo_map
                MS_descriptor = arguments.nextgens_xml
            if MS_type == "Aragorn":
                MS_map = arguments.aragorn_map
                MS_descriptor = arguments.nextgens_xml
            if MS_type == "Barney":
                MS_map = arguments.barney_map
                MS_descriptor = arguments.patriot_xml
            if MS_map is None: raise Exception("Map for %s is not defined" % MS_type)
            if MS_descriptor is None: raise Exception("ResetLog descriptor for %s is not defined" % MS_type)

            # Parse resetLog
            resetInputFile = os.path.join(arguments.logs, resetFile)
            resetOutputFile = resetInputFile.replace("DspResetLog", "Parsed_DspResetLog")
            os.system("%s --binary_log_file %s --xml_descriptor %s --map_file %s --output_file %s" % (
                arguments.RLR,
                resetInputFile,
                MS_descriptor,
                MS_map,
                resetOutputFile
            ))

            # Read and print brief info
            MONITORED_TAGS = [
                b"Current task name =",
                b"current task name =",
                b"SIG Reset Reason =",
                b"Reset Type ="
            ]
            for line in open(resetOutputFile, "rb").read().splitlines():
                line = line.strip()
                if b"Return address = " in line:
                    line = line.decode("utf-8")
                    if not line.replace("Return address = ", "").strip().startswith("("):
                        print(line)
                        continue
                else:
                    for tag in MONITORED_TAGS:
                        if tag in line:
                            print(line.decode("utf-8"))
                            continue
            print("")
            print("-"*20)

        except Exception as ex:
            print("Exception %s raised during parsing resetLog %s for %s" % (str(type(ex)), resetFile, MS))
            print("Details: " + str(ex))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-f","--filepath",  help="path to the file with testcases",                         type=str)
    parser.add_argument("-j","--junit",     help="name of the file with junit results",                     type=str)
    parser.add_argument("-o","--outsuffix", help="suffix to name of the file with junit results",           type=str)
    parser.add_argument("--cfgs",           help="directory where python *.ini files are stored",           type=str)
    parser.add_argument("--logs",           help="directory where python logs files are stored",            type=str)
    parser.add_argument("-l","--test_list", help="list of module or module.class or module.class.testname", type=str)
    parser.add_argument("--RLR",            help="path to console version of ResetLog Reader",              type=str)
    parser.add_argument("--nextgens_xml",   help="path to ResetLog descriptor for NextGens",                type=str)
    parser.add_argument("--patriot_xml",    help="path to ResetLog descriptor for Patriot",                 type=str)
    parser.add_argument("--frodo_map",      help="path to DSP map for Frodo",                               type=str)
    parser.add_argument("--barney_map",     help="path to DSP map for Barney",                              type=str)
    parser.add_argument("--aragorn_map",    help="path to DSP map for Aragorn",                             type=str)
    arguments = parser.parse_args()

    if arguments.cfgs and os.path.exists(arguments.cfgs):
        os.environ["PYEASITEST_CFGS"] = arguments.cfgs
    if arguments.logs:
        os.environ["PYEASITEST_LOGS"] = arguments.logs
    else:
        arguments.logs = "logs/"
    if arguments.junit:
        junit_name = arguments.junit
    else:
        junit_name = "test-results.xml"
    if arguments.outsuffix:
        outsuffix = arguments.outsuffix
    else:
        outsuffix = "tmp"

    if arguments.test_list is not None:
        suite = get_tests_from_list(arguments.test_list)
    elif arguments.filepath is not None:
        suite = get_tests_from_xml(arguments.filepath)
    else:
        raise Exception("test_list or filepath parameters weren't present. I don't know what kind of tests to run.")

    # Run tests
    xmlrunner.XMLTestRunner(verbosity=2, per_test_output=True, output=junit_name, outsuffix=outsuffix).run(suite)

    # Parse ResetLogs
    if arguments.RLR is not None:
        try:
            parseResetLogs(arguments, outsuffix)
        except Exception as ex:
            print("Exception raised during parsing resetLogs:")
            print(str(ex))

    # Archive output
    print_stats(junit_name, outsuffix)
    zip_logs(arguments.logs, "logs.zip")
    zip_resetLogs(arguments.logs, "resets.zip")
