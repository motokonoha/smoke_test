from ms import create_ms
import unittest, xmlrunner
from time import sleep
from network_if import get_main_ipv4_address
from mot_test import MotTestCase

class ms1_SDS(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2"):
        super(ms1_SDS, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()

    def test_003_sending_priv_sds_during_FDPC(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()
        self.ms1.MakeFDPC(self.ms2)
        self.ms2.AnswerFDPC(self.ms1)
        for i in range(3):
            self.ms1.SendPrivSDSFromTemplate(self.ms2, "long", 40)
            self.ms1.IsPrivateCallOngoing(self.ms2)
            self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.EndFDPC()
        self.ms2.EndFDPC()
        self.ms2.VerifyNumberOfMsgInInbox(3)
        
    def test_001_sending_priv_sds(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()
        sleep(1)
        for i in range(3):
            self.ms1.SendPrivSDSFromTemplate(self.ms2, "long")
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")
            sleep(10)
        self.ms2.VerifyNumberOfMsgInInbox(3)
        
    def test_004_sending_group_sds(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()
        for i in range(3):
            self.ms1.SendGroupSDSFromTemplate("long")
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")
            self.ms1.IsTextOnScreen(str(i+1)+" New Message")
            sleep(10)
        self.ms1.EndFDPC()
        self.ms2.EndFDPC()
        self.ms1.VerifyNumberOfMsgInInbox(3, async = True)
        self.ms2.VerifyNumberOfMsgInInbox(3)
        self.ms1.wait()
        
        
    def test_005_sending_group_sds_during_GC(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()
        for i in range(3):
            self.ms1.MakeGC('TG1')
            self.ms2.VerifyIncomingGC(self.ms1, self.ms2.tgs["TG1"][1])
            self.ms1.SendGroupSDSFromTemplate("long", 40)
            self.ms2.VerifyIncomingGC(self.ms1, self.ms2.tgs["TG1"][1])
            self.ms1.VerifyOngoingGC("TG1")
            self.ms1.ReleasePTT()
            sleep(10)
        self.ms1.EndFDPC()
        self.ms2.EndFDPC()
        self.ms1.VerifyNumberOfMsgInInbox(3, async = True)
        self.ms2.VerifyNumberOfMsgInInbox(3)
        self.ms1.wait()
        

    def test_002_sending_priv_sds_during_GC(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()
        for i in range(3):
            self.ms1.MakeGC('TG1')
            self.ms2.VerifyIncomingGC(self.ms1, self.ms2.tgs["TG1"][1])
            self.ms1.SendPrivSDSFromTemplate(self.ms2,"long", 40)
            self.ms2.VerifyIncomingGC(self.ms1, self.ms2.tgs["TG1"][1])
            self.ms1.VerifyOngoingGC("TG1")
            self.ms1.ReleasePTT()
            sleep(10)
        self.ms1.EndFDPC()
        self.ms2.EndFDPC()
        self.ms2.VerifyNumberOfMsgInInbox(3)
        
class ms2_SDS(ms1_SDS):
    def __init__(self, testname, ms2_cfg = "ms1", ms1_cfg = "ms2"):
        super(ms2_SDS, self).__init__(testname, ms1_cfg, ms2_cfg)
        
        
class ms3_SDS(ms1_SDS):
    def __init__(self, testname, ms2_cfg = "ms1", ms1_cfg = "ms3"):
        super(ms3_SDS, self).__init__(testname, ms1_cfg, ms2_cfg)        
