from ms import create_ms, is_ms_patriot
import unittest, math, os
from time import sleep
from mot_test import MotTestCase

class checklist(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3"):
        super(checklist, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 2

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()
    
    def connectTMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO(async = True)
        self.ms3.EnterTMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1", async = True)
        self.ms3.ChangeTG("TG1")
        self.ms1.wait()
        self.ms2.wait()
        
    def connectDMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()       
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("DTG_H1_1",async = True)
        self.ms2.ChangeTG("DTG_H1_1",async = True)
        self.ms3.ChangeTG("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        
          
    def test_004_power_off_and_on_in_DMO(self):
        self.connectDMO()
        self.ms1.Reset(async = True)
        self.ms2.Reset(async = True)
        self.ms3.Reset()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms2.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms3.VerifyDMOIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        
    def test_005_ms_goes_into_test_mode(self):
        self.connectDMO()
        self.ms1.PowerOff(async = True)
        self.ms2.PowerOff(async = True)
        self.ms3.PowerOff()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.PowerOn(async = True)
        self.ms2.PowerOn(async = True)
        self.ms3.PowerOn()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms2.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms3.VerifyDMOIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()

    def test_006_ms_airtracer(self):
        self.connectTMO()
        if not self.ms1.is_ms_patriot():
            log1 = self.ms1.airtracer_file
            self.assertNotEqual(log1, None)
            self.assertNotEqual(os.path.getsize(log1), 0)
        if not self.ms2.is_ms_patriot():
            log2 = self.ms2.airtracer_file
            self.assertNotEqual(log2, None)
            self.assertNotEqual(os.path.getsize(log2), 0)
        if not self.ms3.is_ms_patriot():
            log3 = self.ms3.airtracer_file
            self.assertNotEqual(log3, None)
            self.assertNotEqual(os.path.getsize(log3), 0)

    def test_007_ms_at_commands(self):
        self.connectTMO()
        self.ms1.SwitchToAT(async = True)
        self.ms2.SwitchToAT(async = True)
        self.ms3.SwitchToAT()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.at.Open()
        self.ms2.at.Open()
        self.ms3.at.Open()
        at_result1 = self.ms1.at.Send('at\r')
        at_result2 = self.ms2.at.Send('at\r')
        at_result3 = self.ms3.at.Send('at\r')
        self.ms1.at.Close()
        self.ms2.at.Close()
        self.ms3.at.Close()
        self.ms1.SwitchToIMT(async = True)
        self.ms2.SwitchToIMT(async = True)
        self.ms3.SwitchToIMT()
        self.ms1.wait()
        self.ms2.wait()
        self.assertNotEqual(at_result1, None)
        self.assertNotEqual(at_result2, None)
        self.assertNotEqual(at_result3, None)            
            
    def test_008_power_off_and_on_in_repeater_mode(self):
        rep_mode1 = self.ms1.IsREPMode()
        if rep_mode1:
            self.ms1.Connect()
            self.ms1.EnterREP()
            self.ms1.ChangeTG("DTG_H1_1")
            self.ms1.VerifyREPIdle("DTG_H1_1")
            self.ms1.Reset()
            self.ms1.VerifyREPIdle("DTG_H1_1")
        else:
            self.logger.info("Not supporting gateway feature for ms1")
        
        rep_mode2 = self.ms2.IsREPMode()
        if rep_mode2:
            self.ms2.Connect()
            self.ms2.EnterREP()
            self.ms2.ChangeTG("DTG_H1_1")
            self.ms2.VerifyREPIdle("DTG_H1_1")
            self.ms2.Reset()
            self.ms2.VerifyREPIdle("DTG_H1_1")
        else:
            self.logger.info("Not supporting gateway feature for ms2")

        rep_mode3 = self.ms3.IsREPMode()
        if rep_mode3:
            self.ms3.Connect()
            self.ms3.EnterREP()
            self.ms3.ChangeTG("DTG_H1_1")
            self.ms3.VerifyREPIdle("DTG_H1_1")
            self.ms3.Reset()
            self.ms3.VerifyREPIdle("DTG_H1_1")
        else:
            self.logger.info("Not supporting gateway feature for ms3")                          
            
    def test_009_power_off_and_on_in_gateway_mode(self):
        gw_mode1 = self.ms1.IsGWMode()
        self.connectTMO()
        if gw_mode1:
            self.ms1.EnterGW()
            self.ms1.ChangeTG("DTG_H1_1")
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms1.Reset()
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1") 
        else:
            self.skipTest("Not supporting gateway feature for ms1")

        gw_mode2 = self.ms2.IsGWMode()
        if gw_mode2:
            self.ms2.EnterGW()
            self.ms2.ChangeTG("DTG_H1_1")
            self.ms2.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms2.Reset()
            self.ms2.VerifyGWIdle("TG1", "DTG_H1_1") 
        else:
            self.skipTest("Not supporting gateway feature for ms2")

        gw_mode3 = self.ms3.IsGWMode()
        if gw_mode3:
            self.ms3.EnterGW()
            self.ms3.ChangeTG("DTG_H1_1")
            self.ms3.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms3.Reset()
            self.ms3.VerifyGWIdle("TG1", "DTG_H1_1") 
        else:
            self.skipTest("Not supporting gateway feature for ms3")               
    
    def test_010_power_off_and_on_in_TMO(self):
        self.connectTMO()
        self.ms1.Reset(async = True)
        self.ms2.Reset(async = True)
        self.ms3.Reset()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyTMOIdle("TG1", async = True)
        self.ms2.VerifyTMOIdle("TG1", async = True)
        self.ms1.VerifyTMOIdle("TG1")
        self.ms1.wait()
        self.ms2.wait()
       
    def test_011_crypto_registr(self):
        if self.ms1.isBSI():
            self.connectTMO()
            self.ms1.CryptoRegistr(async = True)
            self.ms2.CryptoRegistr(async = True)
            self.ms3.CryptoRegistr()
            self.ms1.wait()
            self.ms2.wait()
            self.ms1.VerifyTMOIdle("TG1", async = True)
            self.ms2.VerifyTMOIdle("TG1", async = True)
            self.ms3.VerifyTMOIdle("TG1")
            self.ms1.wait()
            self.ms2.wait()
        else:
            self.skipTest("Non BSI radios")
            
               
                
if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(checklist)
    suite = unittest.TestSuite([suite1])
    #suite = unittest.TestSuite([suite1, suite2, suite3])
    unittest.TextTestRunner(verbosity=2).run(suite)                     