from ms import create_ms
import unittest, xmlrunner
from time import sleep
from network_if import get_main_ipv4_address
from mot_test import MotTestCase

class TPCTestsTwoMs(MotTestCase):
    def __init__(self, testname, ms_cfg = "ms1", ms2_cfg = "ms3"):
        super(TPCTestsTwoMs, self).__init__(testname)
        self.ms_cfg = ms_cfg
        self.ms2_cfg = ms2_cfg
        self.time_rank = [0,0,0,0]
        self.result = None

    def check_result(self, result, max_time, perfect_time, size):
        if result == None:
            self.fail("Connection Error")
        transmission_time = float(result[1]) - float(result[0])
        print ("transmission time = " + str(transmission_time) + " data send = " + str(result[2]) + " data received = " + str(result[3]), " network fials = " + str(result[4]))
        if int(result[4]) != 0:
            self.fail("Network fails!")
        if int(result[3]) != size and int(result[2]) != size:
            self.fail("received/sent message size error")
        if transmission_time > max_time:
            print ("Too long transmission")
        if transmission_time <= perfect_time:
            print ("Perfect transmission")
            self.time_rank[0] = int(self.time_rank[0])+ 1
        if transmission_time > perfect_time and transmission_time <= max_time:
            print("Good transmission")
            self.time_rank[1] = int(self.time_rank[1]) + 1
        return 0



    def check_time(self, number_of_good, number_of_perfect):
        print("Number of perfect transmissions = " + str(self.time_rank[0]))
        print("Number of good transmissions = " + str(self.time_rank[1]))
        if self.time_rank[0]+self.time_rank[1] < number_of_good or self.time_rank[0] < number_of_perfect:
            self.fail("Too few transmission with good or perfect time")
        return 0

    
    def setUp(self):
        self.ms = create_ms(self.ms_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        
    def tearDown(self):
        self.ms.destroy()
        self.ms2.destroy()

    def test_DownloadUploadTwoRadios(self):
        self.ms.Connect()
        self.ms2.Connect()
        self.ms.EnterTMO(async = True)
        self.ms2.EnterTMO(async = True)
        self.ms.wait()
        self.ms2.wait()
        self.ms.SetPDConnection()
        self.ms2.SetPDConnection()
        sleep(5)
        self.ms.ReceiveFileViaTPC(100000, 30, async = True)
        resultSecons = self.ms2.SendFileViaTPC(100000, 30)
        self.assertEqual(0, self.check_result(resultsecond, 11.00, 10.00, 100000))
        resultFirst = self.ms.wait()
        self.assertEqual(0, self.check_result(resultFirst, 11.00, 10.00, 1024000))
        self.ms.ClosePDConnection()
        self.ms2.ClosePDConnection()
        sleep(5)
        
    def test_DownloadTwoRadios(self):
        self.ms.Connect()
        self.ms2.Connect()
        self.ms.EnterTMO(async = True)
        self.ms2.EnterTMO(async = True)
        self.ms.wait()
        self.ms2.wait()
        self.ms.SetPDConnection()
        self.ms2.SetPDConnection()
        sleep(5)
        self.ms.ReceiveFileViaTPC(100000, 30, async = True)
        resultSecons = self.ms2.ReceiveFileViaTPC(100000, 30)
        self.assertEqual(0, self.check_result(resultsecond, 11.00, 10.00, 100000))
        resultFirst = self.ms.wait()
        self.assertEqual(0, self.check_result(resultFirst, 11.00, 10.00, 100000))
        self.ms.ClosePDConnection()
        self.ms2.ClosePDConnection()
        sleep(5)

    def test_UploadTwoRadios(self):
        self.ms.Connect()
        self.ms2.Connect()
        self.ms.EnterTMO(async = True)
        self.ms2.EnterTMO(async = True)
        self.ms.wait()
        self.ms2.wait()
        self.ms.SetPDConnection()
        self.ms2.SetPDConnection()
        sleep(5)
        self.ms.SendFileViaTPC(100000, 30, async = True)
        resultSecons = self.ms2.SendFileViaTPC(100000, 30)
        self.assertEqual(0, self.check_result(resultsecond, 11.00, 10.00, 100000))
        resultFirst = self.ms.wait()
        self.assertEqual(0, self.check_result(resultFirst, 11.00, 10.00, 100000))
        self.ms.ClosePDConnection()
        self.ms2.ClosePDConnection()
        sleep(5)