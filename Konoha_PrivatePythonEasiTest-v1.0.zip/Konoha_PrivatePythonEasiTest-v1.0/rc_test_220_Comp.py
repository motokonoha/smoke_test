#author Wojciech Chocholowicz (pwjm87)
import argparse, os, shutil, zipfile
import unittest, xmlrunner
import xml.dom
from xml.dom.minidom import parse
from Attachments import ms2_Attachments, ms1_Attachments
from SetupCP import setup_cp
from checklist import ms1_Checklist
from checklist import ms3_Checklist
from DMO import ms1_DMO, ms1_DMO2A, ms1_DMO2B, ms1_DMO2C, ms2_DMO, ms2_DMO2A, ms2_DMO2B, ms2_DMO2C, ms3_DMO, ms3_DMO2A, ms3_DMO2B, ms3_DMO2C
from Gateway import ms1_Gateway, ms1_Gateway_2A, ms1_Gateway_2B, ms1_Gateway_2C, ms2_Gateway, ms2_Gateway_2A, ms2_Gateway_2B, ms2_Gateway_2C
from Repeater import ms1_Repeater, ms1_Repeater_2C, ms3_Repeater, ms3_Repeater_2C
from EmerAlert import ms1_EmerAlert, ms2_EmerAlert
from Repeater_interactive import ms1_Repeater_interactive, ms3_Repeater_interactive, ms1_Repeater_interactive_2C, ms3_Repeater_interactive_2C
from CleanUp import clean_up
import re
from mot_test import get_tests_from_xml

def print_mobiles_versions(junit_name, outsuffix):
    base, ext = os.path.splitext(junit_name)
    filename = base+"-"+outsuffix+ext
    ms1 = ""
    ms2 = ""
    ms3 = ""
    with open(filename, "rb") as f:
        txt = f.read()
        m = re.search(b'ms1\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms1 = m.group(1).decode()
        m = re.search(b'ms2\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms2 = m.group(1).decode()
        m = re.search(b'ms3\:\sRadio\sVersion\:\s(.*?)\s', txt, re.M|re.I)
        if m:
            ms3 = m.group(1).decode()
    print("MS versions: ms1="+ms1+" ms2="+ms2+" ms3="+ms3)

def zipper(dir, zip_file):
    zip = zipfile.ZipFile(zip_file, 'w', compression=zipfile.ZIP_DEFLATED)
    root_len = len(os.path.abspath(dir))
    for root, dirs, files in os.walk(dir):
        archive_root = os.path.abspath(root)[root_len:]
        for f in files:
            fullpath = os.path.join(root, f)
            archive_name = os.path.join(archive_root, f)
            zip.write(fullpath, archive_name, zipfile.ZIP_DEFLATED)
    zip.close()
    return zip_file

if __name__ == "__main__":
    parser = argparse.ArgumentParser()         
    parser.add_argument("-f","--filepath", help="path to the file with testcases", type=str)
    parser.add_argument("-j","--junit", help="name of the file with junit results", type=str)
    parser.add_argument("-o","--outsuffix", help="suffix to name of the file with junit results", type=str)
    parser.add_argument("--cfgs", help="directory where python *.ini files are stored", type=str)
    parser.add_argument("--logs", help="directory where python logs files are stored", type=str)
    arguments = parser.parse_args()

    if arguments.cfgs and os.path.exists(arguments.cfgs):
        os.environ["PYEASITEST_CFGS"] = arguments.cfgs
    if arguments.logs:
        os.environ["PYEASITEST_LOGS"] = arguments.logs
    if arguments.junit:
        junit_name = arguments.junit
    else:
        junit_name = "test-results.xml"
    if arguments.outsuffix:
        outsuffix = arguments.outsuffix
    else:
        outsuffix = "tmp"

    if arguments.filepath == None:
        suite1 = unittest.TestLoader().loadTestsFromTestCase(setup_cp)
        suite2 = unittest.TestLoader().loadTestsFromTestCase(ms1_Checklist)
        suite3 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO)
        suite4 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2A)
        suite5 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2C)
        suite6 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway)
        suite7 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway_2A)
        suite8 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway_2C)
        suite9 = unittest.TestLoader().loadTestsFromTestCase(ms1_Repeater)
        suite19 = unittest.TestLoader().loadTestsFromTestCase(ms1_Repeater_2C)
        suite10 = unittest.TestLoader().loadTestsFromTestCase(ms1_Repeater_interactive)
        suite20 = unittest.TestLoader().loadTestsFromTestCase(ms1_Repeater_interactive_2C)
        suite11 = unittest.TestLoader().loadTestsFromTestCase(ms1_EmerAlert)
        
        suite12 = unittest.TestLoader().loadTestsFromTestCase(ms3_DMO)
        suite13 = unittest.TestLoader().loadTestsFromTestCase(ms3_DMO2A)
        suite14 = unittest.TestLoader().loadTestsFromTestCase(ms3_DMO2B)
        suite15 = unittest.TestLoader().loadTestsFromTestCase(ms3_DMO2C)
        suite16 = unittest.TestLoader().loadTestsFromTestCase(ms3_Checklist)
        suite17 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater)
        suite21 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater_2C)
        suite18 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater_interactive)
        suite22 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater_interactive_2C)
        
        
        suite999 = unittest.TestLoader().loadTestsFromTestCase(clean_up)
        suite = unittest.TestSuite([suite1, suite2, suite3, suite5, suite6, suite7, suite8, suite9, suite19, suite20, suite12, suite15, suite16, suite17,suite21, suite22, suite999])
        #suite = unittest.TestSuite([suite1, suite2, suite3, suite4, suite5, suite6, suite7, suite8, suite9, suite19, suite10,suite20, suite11, suite12, suite13, suite14, suite15, suite16, suite17,suite21, suite18, suite22, suite999])
    else:
        suite = get_tests_from_xml(arguments.filepath)
        #suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromNames(testModules))

    xmlrunner.XMLTestRunner(verbosity=2, per_test_output=True, output=junit_name, outsuffix=outsuffix).run(suite)

    print_mobiles_versions(junit_name, outsuffix)
    zipper("logs/", "logs.zip")
