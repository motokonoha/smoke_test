from ms import create_ms, is_ms_patriot, is_ms_nextgen
import unittest, math, os
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_EmerAlert(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", TG1_DMO = "DTG_H1_1", TG2_DMO = "DTG_H1_2A"):
        super(ms1_EmerAlert, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.TG1_DMO = TG1_DMO
        self.TG2_DMO = TG2_DMO   

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        sleep(30)
        self.ms1.destroy()
        self.ms2.destroy()     

    def connectDMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        self.ms1.ChangeTG(self.TG1_DMO, async = True)
        self.ms2.ChangeTG(self.TG1_DMO)
        self.ms1.wait() 

    def configMStoMSforMS1(self):
        self.ms1.PressAndReleaseKey("SK1")
        sleep(0.5)
        self.ms1.SelectMenuItem("Config")
        sleep(0.5)
        self.ms1.SelectMenuItem("MS - MS")
        sleep(0.5)

    def configMStoMSforMS2(self):
        self.ms2.PressAndReleaseKey("SK1")
        sleep(0.5)
        self.ms2.SelectMenuItem("Config")
        sleep(0.5)
        self.ms2.SelectMenuItem("MS - MS")
        sleep(0.5)

    @launch_during_rerun_if_any_test_failed
    def test_000_EA(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return

        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 1, async = True)
        self.ms2.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 1)
        self.ms1.wait()
        self.ms1.CommitCp(async = True)
        self.ms2.CommitCp()
        self.ms1.wait()

    def test_001_EA_sendAndReceiveEmergencyAlert(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return
        self.connectDMO()
        self.ms1.ChangeTG(self.TG2_DMO)
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms2.EnterEmergencyMode()
        sleep(7)
        self.ms1.IsTextOnScreen(self.ms1.emg_alert, 5, async = True)
        self.ms2.IsTextOnScreen(self.ms2.emg_alert, 5)
        self.ms1.wait()
        self.ms1.IsTextOnScreen("EA_CHNL", 5, async = True)
        self.ms2.IsTextOnScreen("EA_CHNL", 5)
        self.ms1.wait()
        self.ms1.ExitEmergencyMode(async = True)
        self.ms2.ExitEmergencyMode()
        self.ms1.wait()
        
 
    def test_002_EA_lateEntry(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return
        self.connectDMO()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms1.EnterTMO()
        self.ms2.EnterEmergencyMode()
        sleep(7)
        self.ms2.IsTextOnScreen(self.ms2.emg_alert, 5)
        self.ms2.IsTextOnScreen("EA_CHNL", 5)
        self.ms1.EnterDMO()
        #self.ms1.SetConfig("MS - MS")
        self.ms2.HoldPTT()
        sleep(60)
        self.ms2.ReleasePTT()
        sleep(5)
        self.ms1.IsTextOnScreen(self.ms1.emg_alert, 5)
        self.ms1.IsTextOnScreen("EA_CHNL", 5)
        self.ms1.ExitEmergencyMode(async = True)
        self.ms2.ExitEmergencyMode()
        self.ms1.wait()

    def test_003_EA_enterRepeaterMode(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return
        self.connectDMO()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms1.EnterREP()
        self.ms1.IsTextOnScreen("Repeater", 5)
        self.ms2.EnterEmergencyMode()
        sleep(7)
        self.ms2.IsTextOnScreen(self.ms2.emg_alert, 5, async = True)
        self.ms1.IsTextOnScreen("Repeater", 5)
        self.ms2.wait()
        self.ms2.IsTextOnScreen("EA_CHNL", 5)
        self.ms2.ExitEmergencyMode(async = True)
        self.ms1.EnterDMO()
        #self.ms1.SetConfig("MS - MS")
        self.ms2.wait()
        self.ms2.EnterEmergencyMode()
        sleep(7)
        self.ms2.IsTextOnScreen(self.ms2.emg_alert, 5, async = True)
        self.ms1.IsTextOnScreen(self.ms1.emg_alert, 5)
        self.ms2.wait()
        self.ms2.IsTextOnScreen("EA_CHNL", 5, async = True)
        self.ms1.IsTextOnScreen("EA_CHNL", 5)
        self.ms2.wait()
        self.ms2.ExitEmergencyMode(async = True)
        self.ms1.ExitEmergencyMode()
        self.ms2.wait()


    def test_004_EA_radioBusy(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return
        self.connectDMO()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms1.HoldPTT()
        self.ms1.IsTextOnScreen("Group In Use", 5)
        self.ms2.EnterEmergencyMode()
        sleep(7)
        self.ms2.IsTextOnScreen(self.ms2.emg_alert, 5)
        self.ms2.IsTextOnScreen("EA_CHNL", 5, async = True)
        self.ms1.IsTextOnScreen("Group In Use", 5)
        self.ms2.wait()
        self.ms2.ExitEmergencyMode()
        sleep(1)
        self.ms2.IsTextOnScreen("Group In Use", 5)
        self.ms1.ReleasePTT()


    @launch_during_rerun_if_any_test_failed
    def test_999_EA(self):
        if is_ms_patriot(self.ms1_cfg) or is_ms_patriot(self.ms2_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return

        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 0, async = True)
        self.ms2.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 0)
        self.ms1.wait()
        self.ms1.CommitCp(async = True)
        self.ms2.CommitCp()
        self.ms1.wait()

class ms2_EmerAlert(ms1_EmerAlert):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_EmerAlert, self).__init__(testname, ms1_cfg, ms2_cfg)

class ms3_EmerAlert(ms1_EmerAlert):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_EmerAlert, self).__init__(testname, ms1_cfg, ms2_cfg)

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_EmerAlert)
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms2_EmerAlert)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ms3_EmerAlert)
    
    suite = unittest.TestSuite([suite1, suite2])
    unittest.TextTestRunner(verbosity=2).run(suite)                     