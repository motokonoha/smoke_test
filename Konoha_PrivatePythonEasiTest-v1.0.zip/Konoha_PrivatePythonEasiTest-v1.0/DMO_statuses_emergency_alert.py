from ms import create_ms, is_ms_patriot
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class Ms1TxMs2Rx(MotTestCase):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms2", tg = "DTG_H1_2C"):
        super(Ms1TxMs2Rx, self).__init__(testname)
        self.msTX_cfg = msTX_cfg
        self.msRX_cfg = msRX_cfg
        self.tg = tg

    def setUp(self):
        self.msTX = create_ms(self.msTX_cfg)
        self.msRX = create_ms(self.msRX_cfg)

        self.msTX.Connect(async = True)
        self.msRX.Connect()
        self.msTX.wait()

        self.msTX.EnterDMO(async = True)
        self.msRX.EnterDMO()
        self.msTX.wait()

        self.msTX.ChangeTG(self.tg, async = True)
        self.msRX.ChangeTG(self.tg)
        self.msTX.wait()

        self.msTX.ClearInbox(async = True)
        self.msRX.ClearInbox()
        self.msTX.wait()

    def tearDown(self):
        self.msTX.destroy()
        self.msRX.destroy()   
        
    @launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.msTX.Connect()
        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 1)
        self.msTX.CommitCp()

    @launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.msTX.Connect()
        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.emergency_alert', 0)
        self.msTX.CommitCp()

    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_Emergency_Alert_40MHA_41_40T_41
    @unittest.skip
    def test_001_reception_of_emergency_alert(self):
        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        self.msTX.ExitEmergencyMode()

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

class Ms1RxMs2Tx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms2", msRX_cfg = "ms1", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, tg) 
        
class Ms3RxMs1Tx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms3", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, tg)

class Ms3TxMs1Rx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms3", msRX_cfg = "ms1", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, tg)         

if __name__ == "__main__":
    suite = unittest.TestSuite([unittest.TestLoader().loadTestsFromTestCase(Ms1TxMs2Rx),
                                unittest.TestLoader().loadTestsFromTestCase(Ms1RxMs2Tx)])
    unittest.TextTestRunner(verbosity=2).run(suite)                     
