from ms import create_ms, is_ms_frodo
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_Gateway_EC_with_alarm(MotTestCase):
    def __init__(self, testname,msGW_cfg = "ms1", msDMO_cfg = "ms3", msTMO_cfg = "ms2", tgDMO = "DTG_I1_1", tgTMO = "TG1"):
        super(ms1_Gateway_EC_with_alarm, self).__init__(testname)
        self.msGW_cfg = msGW_cfg
        self.msDMO_cfg = msDMO_cfg
        self.msTMO_cfg = msTMO_cfg
        self.tgTMO = tgTMO
        self.DTG = tgDMO

    def setUp(self):
        self.ms1 = create_ms(self.msGW_cfg)
        self.ms2 = create_ms(self.msDMO_cfg)
        self.ms3 = create_ms(self.msTMO_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()  
        
    #@launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.ms2.Connect()
        self.ms2.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)
        self.ms2.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.dev_and_test[0]',1) 
        self.ms2.CommitCp()


    #@launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.ms2.Connect()
        self.ms2.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)
        self.ms2.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.dev_and_test[0]',0) 
        self.ms2.CommitCp()


    def gw_sync(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()        
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterTMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.tgTMO, async = True)
        self.ms2.ChangeTG(self.DTG, async = True)
        self.ms3.ChangeTG(self.tgTMO)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterGW(async = True)       
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyTMOIdle(self.tgTMO)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.DTG)
        self.ms1.VerifyGWIdle(self.tgTMO, self.DTG)
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive only", async = True)
        self.ms2.SetConfig("Gateway")
        self.ms1.wait()
        self.ms2.VerifyDMOIdle(self.DTG)
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.ms2.wait()

    def ms2_GC_via_gw(self):
        self.ms2.MakeGC(self.DTG)
        self.ms1.VerifyIncomingGCasGW(self.ms2, self.tgTMO, self.DTG)
        if self.ms3.isBSI():
            self.ms3.VerifyIncomingGCfromGW(self.ms2, self.tgTMO)
        else:
            self.ms3.VerifyIncomingGC(self.ms1, self.tgTMO)
        
        
    def ms3_GC_via_gw(self):
        self.ms3.MakeGC(self.tgTMO)
        self.ms1.VerifyIncomingGCasGW(self.ms3, self.tgTMO, self.DTG)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        
    def VerifyReservationDmoTmo(self):
        self.ms3.VerifyReservation(self.tgTMO, async = True)
        self.ms1.VerifyReservationAsGW(self.DTG, self.tgTMO, async = True)
        self.ms2.VerifyReservation(self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        
    def VerifyReservationTmoDmo(self):
        self.ms3.VerifyReservation(self.tgTMO, async = True)
        self.ms1.VerifyReservationAsGW(self.tgTMO, self.DTG, async = True)
        self.ms2.VerifyReservation(self.DTG)
        self.ms3.wait()
        self.ms1.wait()        


    def test_001_preemption_of_call_in_TMO_by_synchronized_radio_in_DMO(self):
        if not is_ms_frodo(self.msGW_cfg):
            self.skipTest("Not supporting gateway feature")        
        self.gw_sync()
        self.ms3_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in occupation")
        self.ms2.EnterEmergencyMode()
        self.ms2.IsTextOnScreen("Call Preempted",10)
        self.ms2.IsTextOnScreen("Alarm Sent",10)
        self.ms3.IsTextOnScreen("PTT Denied")
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, self.tgTMO, self.DTG, async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms1, self.tgTMO)
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()
        sleep(3)
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyTMOIdle(self.tgTMO, async = True)
        self.ms1.VerifyGWIdle(self.tgTMO, self.DTG)
        self.ms2.wait()
        self.ms3.wait()
        self.ms3_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in reservation")
        self.ms3.ReleasePTT()
        self.VerifyReservationTmoDmo()
        sleep(1)
        self.ms2.EnterEmergencyMode()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, self.tgTMO, self.DTG, async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms1, self.tgTMO)

        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()
        
        
        
    def test_002_preemption_of_call_in_DMO_by_synchronized_radio_in_TMO(self):
        if not is_ms_frodo(self.msGW_cfg):
            self.skipTest("Not supporting gateway feature")        
        self.gw_sync()
        self.ms2_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in occupation")
        self.ms3.EnterEmergencyMode()        
        self.ms2.IsTextOnScreen("PTT Denied")
        self.ms2.ReleasePTT()
        self.ms3.CheckOngoingEmergencyMicOn(self.tgTMO, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms3, self.tgTMO, self.DTG, async = True)
        self.ms2.CheckIncomingEmergencyCall(self.ms3, self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms3.ExitEmergencyMode()
        sleep(3)
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyTMOIdle(self.tgTMO, async = True)
        self.ms1.VerifyGWIdle(self.tgTMO, self.DTG)
        self.ms2.wait()
        self.ms3.wait()
        self.ms2_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in reservation")
        self.ms2.ReleasePTT()
        self.VerifyReservationTmoDmo()
        sleep(1)
        self.ms3.EnterEmergencyMode()
        self.ms3.CheckOngoingEmergencyMicOn(self.tgTMO, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms3, self.tgTMO, self.DTG, async = True)
        self.ms2.CheckIncomingEmergencyCall(self.ms3, self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms3.ExitEmergencyMode()
        
              
if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway_EC_with_alarm)
    
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)    