#Services to disable: SSDP Discovery, WinHTTP Web Proxy Auto-Discovery Service, Computer Browser, Windows Media Player Network Sharing Service, Function Discovery Provider Host, Function Discovery Resource Publication
#Open browser. Type localhost:1947 and Configuration->Access to Remote License Managers->disable Broadcast Search for Remote Licenses
#Start->gpedit.msc. Local Computer Policy -> Computer Configuration -> Administrative templates -> network -> DNS Client -> Turn off Multicast Name Resolution set to Enabled
from ms import create_ms, is_ms_patriot, is_ms_nextgen
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_SSPD(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", type="SSPD", time = 10000, amount = 10, size = 64):
        super(ms1_SSPD, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 5
        self.type = type;
        self.time = time;
        self.amount = amount;
        self.size = size;

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
 
    def check_results(self, results):
        is_before_call = True
        is_in_call = False
        is_after_call = False
        for result in results:
            if is_before_call and (result.is_dest_unrechable() or result.is_timeout()):
                is_before_call = False
                is_in_call = True
            elif is_in_call and result.is_reply():
                is_in_call = False
                is_after_call = True
            elif is_after_call and not result.is_reply():
                return False
            elif is_in_call and result.is_timeout():
                return False
        if is_after_call:
            return True    
        return False
 
    def connect(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()

    @launch_during_rerun_if_any_test_failed
    def test_000_set_packet_data_codeplug(self):
        self.ms1.Connect()
        self.ms1.SetPDMode(self.type)

    def test_001_pinging_ip_host(self):
        self.connect()
        self.ms1.SetPDConnection()
        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        r1 = self.ms1.ping(0).Send(self.amount, self.size*4, self.time)
        r2 = self.ms1.ping(0).Send(self.amount, self.size*8, self.time*2)
        r3 = self.ms1.ping(0).Send(self.amount, self.size*16, self.time*3)
        r4 = self.ms1.ping(0).Send(self.amount, self.size*32, self.time*5)

        self.ms1.ClosePDConnection()
        self.assertEqual(r1.reply_count, self.amount, "Number of received pings ("+str(self.size*4)+" bytes) doesn't match")
        self.assertEqual(r2.reply_count, self.amount, "Number of received pings ("+str(self.size*8)+" bytes) doesn't match")
        self.assertEqual(r3.reply_count, self.amount, "Number of received pings ("+str(self.size*16)+" bytes) doesn't match")
        self.assertEqual(r4.reply_count, self.amount, "Number of received pings ("+str(self.size*32)+" bytes) doesn't match")
         # print(r)
         # print ("inne info:")
        # print ("1: "+ str(r.reply_count) +" 2: "+ str(r.dest_unrechable_count)+ " 3: "+ str(r.timeout_count))

    def test_002_attach_to_tmo_tg_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")
            return

        self.connect()
        self.ms1.SetPDConnection()
        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*2, self.size, self.time, async = True)

        for i in range (2):
            self.ms1.ChangeTG("TG1")
            self.ms1.ChangeTG("TG2")

        r = self.ms1.ping(0).wait()
        self.ms1.ClosePDConnection()

        self.assertEqual(r.reply_count, self.amount*2, "Number of received pings doesn't match")

        # print ("inne info:")
        # print ("1: "+ str(r.reply_count) +" 2: "+ str(r.dest_unrechable_count)+ " 3: "+ str(r.timeout_count))

    def test_003_incomming_SDS_during_pinging(self):
        self.connect()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()

        self.ms1.SetPDConnection()

        self.ms1.ping(0).Send(self.amount*6, self.size, self.time, async = True)
        for i in range(3):
            self.ms2.SendPrivSDSFromTemplate(self.ms1, "long")
            if not is_ms_patriot(self.ms1_cfg):
                self.ms1.IsTextOnScreen(str(i+1)+" New Message")

        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()
        self.ms1.VerifyNumberOfMsgInInbox(3)

        self.assertEqual(r.reply_count, self.amount*6, "Number of received pings doesn't match")

    def test_004_ongoing_SDS_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox()
        self.ms1.wait()

        self.ms1.SetPDConnection()

        self.ms1.ping(0).Send(self.amount*6, self.size, self.time, async = True)
        for i in range(3):
            self.ms1.SendPrivSDSFromTemplate(self.ms2, "long")
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")

        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()
        self.ms2.VerifyNumberOfMsgInInbox(3)

        self.assertEqual(r.reply_count, self.amount*6, "Number of received pings doesn't match")

    def test_005_ongoing_GC_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.SetPDConnection()

        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*4, self.size, self.time, async = True)
        sleep(10)
        self.ms1.MakeGC("TG1")
        self.ms2.VerifyIncomingGC(self.ms1, "TG1")
        sleep(15)
        self.ms1.ReleasePTT()
        r = self.ms1.ping(0).wait()
        
        self.ms1.ClosePDConnection()
        result = self.check_results(r)
        self.assertEqual(result, True, "Number of received pings doesn't match")
        self.assertGreater(r.dest_unrechable_count, 10, "Too few pings lost")
        
    def test_006_incoming_GC_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.SetPDConnection()

        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*4, self.size, self.time, async = True)
        sleep(10)
        self.ms2.MakeGC("TG1")
        self.ms1.VerifyIncomingGC(self.ms2, "TG1")
        sleep(15)
        self.ms2.ReleasePTT()
        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()

        result = self.check_results(r)
        self.assertEqual(result, True, "Number of received pings doesn't match")
        self.assertGreater(r.dest_unrechable_count, 10, "Too few pings lost")
        
    def test_007_incoming_FDPC_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.SetPDConnection()

        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*4, self.size, self.time, async = True)
        sleep(10)
        self.ms2.MakeFDPC(self.ms1)
        self.ms1.AnswerFDPC(self.ms2)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        sleep(15)
        self.ms2.EndFDPC()
        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()

        result = self.check_results(r)
        self.assertEqual(result, True, "There were pings lost when there was no call")
        self.assertGreater(r.dest_unrechable_count, 6, "Too few pings lost")
        
    def test_008_ongoing_FDPC_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.SetPDConnection()

        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*4, self.size, self.time, async = True)
        sleep(10)
        self.ms1.MakeFDPC(self.ms2)
        self.ms2.AnswerFDPC(self.ms1)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        sleep(15)
        self.ms1.EndFDPC()
        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()

        result = self.check_results(r)
        self.assertEqual(result, True, "Number of received pings doesn't match")
        self.assertGreater(r.dest_unrechable_count, 10, "Too few pings lost")
        
    def test_009_ongoing_EC_during_pinging(self):
        if is_ms_patriot(self.ms1_cfg):
            self.skipTest("Patriot radio is not capable of performing this test.")

        self.connect()
        self.ms1.SetPDConnection()

        # self.ms1.ping(0).Send(3, self.size//2, self.time)
        # sleep(10)

        self.ms1.ping(0).Send(self.amount*4, self.size, self.time, async = True)
        sleep(10)
        self.ms1.EnterEmergencyMode()
        self.ms1.CheckOngoingEmergencyMicOn("TG1")
        self.ms2.CheckIncomingEmergencyCall(self.ms1, "TG1")
        sleep(18)
        self.ms1.ExitEmergencyMode()
        r = self.ms1.ping(0).wait()

        self.ms1.ClosePDConnection()

        result = self.check_results(r)
        self.assertEqual(result, True, "Number of received pings doesn't match")
        self.assertGreater(r.dest_unrechable_count, 10, "Too few pings lost")

    def atest_010_registation_to_packet_data(self):
        self.connect()
        for i in range(2):
            self.ms1.SetPDConnection()
            sleep(5)
            self.ms1.ClosePDConnection()
        #if(is_ms_patriot(self.ms1_cfg)):
         #   self.ms1.SetPDConnection() # add specially for partiot !!


class ms2_SSPD(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",type="SSPD", time = 10000, amount =10, size=64 ):
        super(ms2_SSPD, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms3_SSPD(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",type="SSPD", time = 10000, amount =10, size=64 ):
        super(ms3_SSPD, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms1_MSPD(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2",type="MSPD", time = 5000, amount =10, size=64 ):
        super(ms1_MSPD, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms2_MSPD(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",type="MSPD", time = 5000, amount =10, size=64 ):
        super(ms2_MSPD, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms3_MSPD(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",type="MSPD", time = 5000, amount =10, size=64 ):
        super(ms3_MSPD, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms1_QAM(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2",type="QAM", time = 2000, amount =10, size=64 ):
        super(ms1_QAM, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms2_QAM(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",type="QAM", time = 2000, amount =10, size=64 ):
        super(ms2_QAM, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

class ms3_QAM(ms1_SSPD):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",type="QAM", time = 2000, amount =10, size=64 ):
        super(ms3_QAM, self).__init__(testname, ms1_cfg, ms2_cfg, type, time, amount, size)

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_SSPD)
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms2_SSPD)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ms3_SSPD)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(ms1_MSPD)
    suite5 = unittest.TestLoader().loadTestsFromTestCase(ms2_MSPD)
    suite6 = unittest.TestLoader().loadTestsFromTestCase(ms3_MSPD)
    suite7 = unittest.TestLoader().loadTestsFromTestCase(ms1_QAM)
    suite8 = unittest.TestLoader().loadTestsFromTestCase(ms2_QAM)
    suite9 = unittest.TestLoader().loadTestsFromTestCase(ms3_QAM)
    suite = unittest.TestSuite([suite1,suite2,suite3,suite4,suite5,suite6, suite7,suite8,suite9])
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)