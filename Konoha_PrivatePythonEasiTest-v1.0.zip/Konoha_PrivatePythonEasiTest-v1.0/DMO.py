from ms import create_ms, is_ms_aragorn, RCException
import unittest, math, os
from time import sleep
from mot_test import MotTestCase

class ms1_DMO(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", TG = "DTG_H1_1", TG2 = "DTG_H1_2A"):
        super(ms1_DMO, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 2
        self.TG = TG
        self.TG2 = TG2

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()   
        
    
    def __ms1_GC(self):
        self.ms1.MakeGC(self.TG)
        sleep(1)
        self.ms2.VerifyIncomingGC(self.ms1, self.TG)
        self.ms2.VerifyOngoingGC(self.TG, async = True)       
        self.ms1.ReleasePTT()
        self.ms2.wait()
    
    def __ms2_GC(self):
        self.ms2.MakeGC(self.TG)
        sleep(1)
        self.ms1.VerifyIncomingGC(self.ms2, self.TG)
        self.ms1.VerifyOngoingGC(self.TG, async = True)
        self.ms2.ReleasePTT()
        self.ms1.wait()

    def __ms1_emgcy_call(self):
        self.ms1.HoldPTT()
        sleep(1)
        self.ms2.CheckIncomingEmergencyCall(self.ms1,self.TG)
        self.ms1.CheckOngoingEmergencyCall(self.TG)
        self.ms1.ReleasePTT()
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        sleep(0.5)

    
    def __ms2_emgcy_call(self):
        self.ms2.HoldPTT()
        sleep(1)
        self.ms1.CheckIncomingEmergencyCall(self.ms2, self.TG)
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        self.ms2.ReleasePTT()
        self.ms1.CheckOngoingEmergencyCall(self.TG)
        sleep(0.5)


    def __ms1_PCHD(self):
        sleep(1)  
        self.ms1.HoldPTT()
        sleep(2)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.ReleasePTT()
    
    def __ms2_PCHD(self):
        sleep(1)
        self.ms2.HoldPTT()
        sleep(2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        self.ms2.ReleasePTT()        
        
    def connectDMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        self.ms1.ChangeTG(self.TG, async = True)
        self.ms2.ChangeTG(self.TG)
        self.ms1.wait()

    def test_001_GC_preeemptionGC(self):
        self.connectDMO()
        self.ms1.MakeGC(self.TG)
        self.ms2.VerifyIncomingGC(self.ms1, self.TG)
        self.ms2.EnterEmergencyMode()
        self.ms1.IsTextOnScreen("Call Preempted", 5)
        self.ms1.IsTextOnScreen("PTT Denied", 5)
        self.ms1.ReleasePTT()
        self.ms2.ClickPTT()
        self.ms2.IsTextOnScreen("Emgcy Mic Ended")
      
        for i in range(self.loop):
            self.__ms1_emgcy_call()
            self.__ms2_emgcy_call()

        for i in range(self.loop):
            self.__ms1_emgcy_call()

        for i in range(self.loop):
            self.__ms2_emgcy_call()

        self.ms2.IsTextOnScreen("Emergency")
        self.ms2.ExitEmergencyMode()

    def test_002_GC_preeemptionSDS(self):
        #~ if is_ms_aragorn(self.ms1_cfg):
            #~ self.skipTest("Aragorn radio has issues with SDS preemption - CCMPD01787320, CCMPD01893581")
            #~ return

        self.connectDMO()
        self.ms2.EnterEmergencyMode()
        self.ms2.PressAndReleaseKey("SK2")
        sleep(10)
        for i in range(1, 6):
            self.logger.info("#"+str(i)+" try of SDS preemption")
            self.ms1.PressAndReleaseKey("MENU")
            self.ms1.SelectMenuItem("Messages")
            self.ms1.SelectMenuItem("Templates")
            self.ms1.SelectMenuItem("vlong")
            self.ms1.SelectMenuItem("Group")
            self.ms1.PressAndReleaseKey("SK1", async=True)
            sleep(0.25)
            if self.ms1.isBSI():
                sleep(0.15) # for BSI radios we need to include some extra time for SIM to encrypt SDS. SDS-es are send a little later than without BSI
            self.ms2.ClickPTT()
            self.ms1.wait()
            try:
                self.ms1.IsTextOnScreen("Message Failed", 5)
                break
            except RCException as e:
                if "TEXT_NOT_FOUND" in str(e):
                    if i == 5:
                        raise Exception("SDS wasn't successfully preempted in 5 tries")
                else:
                    raise

        self.ms2.ExitEmergencyMode()

    def test_003_ms_start_GC(self):
        self.connectDMO()
        self.ms1.MakeGC(self.TG)
        self.ms2.VerifyIncomingGC(self.ms1, self.TG)
        self.ms1.ReleasePTT()

        for i in range(2*self.loop):
            self.__ms1_GC()
            self.__ms2_GC()

    def test_004_ms_start_HDPC(self):
        self.connectDMO()
        #~ self.ms1.EnterNumber(1000)
        #~ self.ms1.PressAndHoldKey("PTT")
        #~ self.ms1.IsTextOnScreen("Party Not Available")
        #~ self.ms1.ReleasePTT()
        #~ self.ms1.PressAndReleaseKey("END")
        #~ sleep(1)
        self.ms1.MakeHDPC_DMO(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.ReleasePTT()
        sleep(0.2)

        for i in range(self.loop*2):
            self.__ms1_PCHD()
            self.__ms2_PCHD()

    def test_005_ms_send_group_sds(self):
        self.connectDMO()       
        self.ms2.ClearInbox()
        for i in range(3):
            self.ms1.SendGroupSDSFromTemplate("vlong")
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")
        sleep(10)
        self.ms2.VerifyNumberOfMsgInInbox(3)
        self.ms2.ClearInbox()
        
        for i in range(3):
            self.ms1.PressAndReleaseKey("MENU")
            sleep(0.5)
            self.ms1.SelectMenuItem("Messages")
            sleep(0.5)
            self.ms1.SelectMenuItem("Send Status")
            sleep(0.5)
            #self.ms1.SelectMenuItem("Available")
            self.ms1.PressAndReleaseKey("SK1")
            sleep(0.5)
            self.ms1.SelectMenuItem("Group")
            sleep(0.5)
            self.ms1.SelectMenuItem(self.ms1.tgs[self.TG][1])
            self.ms1.IsTextOnScreen("Status Sent", 0, 10)
            
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")
        sleep(10)
        self.ms2.VerifyNumberOfMsgInInbox(3)    
        return True
        
    def test_006_switching_between_DMO_TG(self):
        self.connectDMO()
        
        for i in range(self.loop*2):

            self.ms1.MakeGC(self.TG)
            self.ms2.VerifyIncomingGC(self.ms1,self.TG,1)
            self.ms1.ReleasePTT()
            self.ms2.VerifyOngoingGC(self.TG)

            self.ms1.ChangeTG(self.TG2, async = True)
            self.ms2.ChangeTG(self.TG2)
            self.ms1.wait()

            self.ms2.MakeGC(self.TG2)
            self.ms1.VerifyIncomingGC(self.ms2,self.TG2,1)
            self.ms2.ReleasePTT()
            self.ms1.VerifyOngoingGC(self.TG2)
            
            self.ms1.ChangeTG(self.TG, async = True)
            self.ms2.ChangeTG(self.TG)
            self.ms1.wait()
 
            
class ms1_DMO2A(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", TG = "DTG_H1_2A", TG2 = "DTG_H1_2C"):
        super(ms1_DMO2A, self).__init__(testname, ms1_cfg, ms2_cfg, TG)           

class ms1_DMO2B(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", TG = "DTG_H1_2B", TG2 = "DTG_H1_1"):
        super(ms1_DMO2B, self).__init__(testname, ms1_cfg, ms2_cfg, TG)  

class ms1_DMO2C(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", TG = "DTG_H1_2C", TG2 = "DTG_H1_1"):
        super(ms1_DMO2C, self).__init__(testname, ms1_cfg, ms2_cfg, TG)  
        
                        
class ms2_DMO(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_DMO, self).__init__(testname, ms1_cfg, ms2_cfg)
        
class ms2_DMO2A(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",TG = "DTG_H1_2A"):
        super(ms2_DMO2A, self).__init__(testname, ms1_cfg, ms2_cfg, TG)

class ms2_DMO2B(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",TG = "DTG_H1_2B"):
        super(ms2_DMO2B, self).__init__(testname, ms1_cfg, ms2_cfg, TG)        

class ms2_DMO2C(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1",TG = "DTG_H1_2C"):
        super(ms2_DMO2C, self).__init__(testname, ms1_cfg, ms2_cfg, TG)   
        
        
class ms3_DMO(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_DMO, self).__init__(testname, ms1_cfg, ms2_cfg)
        
class ms3_DMO2A(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",TG = "DTG_H1_2A"):
        super(ms3_DMO2A, self).__init__(testname, ms1_cfg, ms2_cfg, TG)

class ms3_DMO2B(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",TG = "DTG_H1_2B"):
        super(ms3_DMO2B, self).__init__(testname, ms1_cfg, ms2_cfg, TG)        

class ms3_DMO2C(ms1_DMO):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1",TG = "DTG_H1_2C"):
        super(ms3_DMO2C, self).__init__(testname, ms1_cfg, ms2_cfg, TG)   


if __name__ == "__main__":
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2A)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2B)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2C)
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO)
    
    suite6 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2A)
    suite7 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2B)
    suite8 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2C)
    suite5 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO)

    suite10 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2A)
    suite11 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2B)
    suite12 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO2C)
    suite9 = unittest.TestLoader().loadTestsFromTestCase(ms1_DMO)
    
    suite = unittest.TestSuite([suite1,suite2,suite3,suite4,suite5,suite6,suite7,suite8,suite9,suite10,suite11,suite12])
    unittest.TextTestRunner(verbosity=2).run(suite)                     