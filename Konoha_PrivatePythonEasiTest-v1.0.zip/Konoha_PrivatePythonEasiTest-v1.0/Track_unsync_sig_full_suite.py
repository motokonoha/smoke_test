__author__ = 'THCQ86'
from ms import create_ms, is_ms_frodo
import unittest, math, os
from time import sleep as real_sleep, localtime, strftime
from mot_test import MotTestCase


def sleep(duration):
    print("%s sleep(%s)" % (strftime("%H:%M:%S", localtime()), duration))
    real_sleep(duration)


class Unsync_ms2_H1_1(MotTestCase):
    def __init__(self, testname, ms1_cfg="ms1", ms2_cfg="ms2", ms3_cfg="ms3", DTG="DTG_H1_1"):
        super().__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.full_setup = True
        self.loop = 2
        self.DTG = DTG

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()

    def connectDMO(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.DTG)
        self.ms1.wait()

    def gw_sync_dmo_ms_ms(self):
        self.ms1.EnterTMO(async=True)
        self.ms2.EnterDMO(async=True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        sleep(3)
        self.ms1.ChangeTG("TG1", async=True)
        self.ms2.ChangeTG(self.DTG, async=True)
        self.ms3.ChangeTG(self.DTG)
        self.ms1.wait()
        self.ms2.wait()
        sleep(3)
        self.ms1.EnterGW(async=True)
        self.ms2.VerifyDMOIdle(self.DTG, async=True)
        self.ms3.VerifyDMOIdle(self.DTG)
        self.ms1.wait()
        self.ms2.wait()
        sleep(3)
        self.ms1.ChangeTG(self.DTG)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive only", async=True)
        self.ms2.SetConfig("MS - MS", async=True)
        self.ms3.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms2.wait()
        sleep(3)
        self.ms2.VerifyDMOIdle(self.DTG, async=True)
        self.ms3.VerifyDMOIdle(self.DTG)
        self.ms2.wait()

        sleep(3)

    def enter_data_only(self, radio):
        radio.PressAndReleaseKey("MENU")
        radio.SelectMenuItem("Setup")
        radio.SelectMenuItem("Data Setup")
        radio.SelectMenuItem("Data Only")
        radio.IsTextOnScreen("Data Only Selected")

    def set_monitor_timer(self, radio, duration):
        radio.SetCpValue('cp_all_t.cp_dll_block.dll_data.dm_gw.monitor_timer', duration)
        radio.CommitCp()

    def test_001_GW_standby_because_of_MS_MS(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")

        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(5)
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_002_GW_standby_because_of_TXI(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms1.EnterTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.ExitTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(5)
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_003_GW_standby_because_of_alien_and_TXI_1(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.EnterTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.ExitTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_004_GW_standby_because_of_alien_and_TXI_2(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms1.EnterTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.ExitTXI()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_005_GW_standby_because_of_alien_and_TXI_2(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms1.EnterTXI()
            self.ms1.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.enter_data_only(self.ms1)
            self.ms1.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.ExitTXI()
            self.ms1.PressAndReleaseKey("END")

            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            self.ms1.EnterVoiceAndData()
            self.ms1.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_006(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")

        self.connectDMO()
        self.set_monitor_timer(self.ms1, 30)

        self.ms1.EnterGW(async=True)
        sleep(3)
        self.ms2.HoldPTT()
        self.ms1.wait()
        self.ms1.IsTextOnScreen("Gateway monitor")
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        sleep(30)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        sleep(1)
        self.ms2.ReleasePTT()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        self.set_monitor_timer(self.ms1, 10)

    def test_007(self):
        self.connectDMO()
        self.set_monitor_timer(self.ms1, 30)

        self.ms1.EnterGW(async=True)
        sleep(10)
        self.ms1.PressAndReleaseKey("END")

        self.ms1.EnterTXI()
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 1000)
        sleep(30)  # make sure that 30 seconds for monitoring is over
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 1000)

        self.ms1.ExitTXI()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 5000)
        self.set_monitor_timer(self.ms1, 10)

    def test_008_GW_standby_because_of_alien_SDS(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()

        for i in range(1):
            self.ms3.ClearInbox()

            self.ms2.PowerOff(async=True)
            self.ms3.PowerOff()
            self.ms2.wait()
            self.ms2.PowerOn(async=True)
            self.ms3.PowerOn()
            self.ms2.wait()

            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.PressAndReleaseKey("MENU")
            self.ms2.SelectMenuItem("Messages")
            sleep(0.5)
            self.ms2.SelectMenuItem("Templates")
            sleep(0.5)
            self.ms2.SelectMenuItem("vlong")
            sleep(0.5)
            self.ms2.SelectMenuItem("Group")
            sleep(0.5)
            self.ms2.PressAndReleaseKey("SK1")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000, async=True)
            self.ms2.IsTextOnScreen("Message Sent", 0, 10, async=True)
            self.ms3.IsTextOnScreen("1 New Message", async=True)

            self.ms1.wait()
            self.ms2.wait()
            self.ms3.wait()

            self.ms2.PressAndReleaseKey("END")
            self.ms3.PressAndReleaseKey("END")

            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)
            self.ms3.ClearInbox()

    def test_009_GW_standby_because_of_alien_status(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        self.gw_sync_dmo_ms_ms()

        for i in range(2):
            self.ms3.ClearInbox()

            self.ms2.PowerOff(async=True)
            self.ms3.PowerOff()
            self.ms2.wait()
            self.ms2.PowerOn(async=True)
            self.ms3.PowerOn()
            self.ms2.wait()

            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 3000)
            self.ms2.PressAndHoldKey("4")
            self.ms2.IsTextOnScreen("Status Sent")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000, async=True)
            self.ms2.ReleaseKey("4")
            self.ms3.IsTextOnScreen("1 New Message")
            sleep(2)
            self.ms1.wait()
            self.ms2.PressAndReleaseKey("END")
            self.ms3.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 3000)
            self.ms3.ClearInbox()

    @unittest.skip("fast switching gw-rep-ge")
    def test_010(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.DTG)
        self.ms1.wait()

        self.set_monitor_timer(self.ms1, 120)

        self.ms2.EnterTMO()
        self.ms2.ChangeTG("TG1")

        self.ms1.EnterGW()

        self.ms1.PressAndReleaseKey("END")

        self.ms1.EnterREP()

        self.ms2.MakeGC("TG1")
        self.ms1.VerifyIncomingGCasREP(self.ms2, self.DTG)

        self.ms1.EnterGW()

        self.ms2.MakeGC("TG1")
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG)

        self.set_monitor_timer(self.ms1, 10)

    def test_011(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()

        self.ms2.SetConfig("Gateway")

        first_dtg = "DTG_H1_1"
        second_dtg = "DTG_H2_1"

        self.ms1.ChangeTG(first_dtg, async=True)
        self.ms2.ChangeTG(first_dtg)
        self.ms1.wait()

        self.set_monitor_timer(self.ms1, 30)
        self.ms1.EnterGW()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)

        self.ms1.ChangeTG(second_dtg, async=True)
        self.ms2.ChangeTG(second_dtg)
        self.ms1.wait()

        sleep(30)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        self.ms2.HoldPTT()
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", second_dtg)

        self.ms2.ReleasePTT()

        self.ms1.ChangeTG(first_dtg, async=True)
        self.ms2.ChangeTG(first_dtg)
        self.ms1.wait()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.set_monitor_timer(self.ms1, 10)

    def test_012_GW_unsync_alien_end_on_occupation(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.PowerOff()
            self.ms2.PowerOn()
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(3)
            self.ms2.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_013_GW_unsync_alien_end_on_reservation(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")

        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 3000)
            self.ms2.PowerOff()
            self.ms2.PowerOn()
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(3)
            self.ms2.ReleasePTT()
            sleep(1)
            self.ms2.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 3000)
            sleep(3)

    def test_014_GW_unsync_alien_release(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")

        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 3000)
            self.ms3.PowerOff()
            self.ms3.PowerOn()
            self.ms3.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 3000)
            sleep(3)
            self.ms3.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_015_GW_unsync_alien_rumble(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")

        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        if self.full_setup:
            self.gw_sync_dmo_ms_ms()
            self.set_monitor_timer(self.ms1, 10)

        for i in range(2):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.PowerOff(async=True)
            self.ms3.PowerOff(async=True)
            self.ms2.wait()
            self.ms3.wait()
            self.ms2.PowerOn(async=True)
            self.ms3.PowerOn(async=True)
            self.ms2.wait()

            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
            sleep(2)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

            self.ms3.wait()
            self.ms3.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
            sleep(2)
            self.ms3.ReleasePTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

            for n in range(2):
                self.ms3.HoldPTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
                sleep(2)
                self.ms2.ReleasePTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

            for n in range(2):
                self.ms3.HoldPTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
                sleep(2)
                self.ms2.ReleasePTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

                self.ms3.HoldPTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
                sleep(2)
                self.ms3.ReleasePTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

            self.ms2.EnterEmergencyMode()
            self.ms2.PressAndReleaseKey("SK2")

            for n in range(2):
                self.ms3.HoldPTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)
                sleep(2)
                self.ms2.ReleasePTT()
                self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 10000)

            self.ms2.ExitEmergencyMode()

            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 60000)
            sleep(3)


class Unsync_ms3_H1_2A(Unsync_ms2_H1_1):
    def __init__(self, testname, ms1_cfg="ms1", ms2_cfg="ms3", ms3_cfg="ms2", DTG="DTG_H1_2A"):
        super(Unsync_ms3_H1_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)


class Unsync_ms2_H1_2B(Unsync_ms2_H1_1):
    def __init__(self, testname, ms1_cfg="ms1", ms2_cfg="ms2", ms3_cfg="ms3", DTG="DTG_H1_2B"):
        super(Unsync_ms2_H1_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)


class Unsync_ms3_H1_2C(Unsync_ms2_H1_1):
    def __init__(self, testname, ms1_cfg="ms1", ms2_cfg="ms3", ms3_cfg="ms2", DTG="DTG_H1_2C"):
        super(Unsync_ms3_H1_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)


if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(Unsync_ms2_H1_1)
    suite2 = unittest.TestLoader().loadTestsFromTestCase(Unsync_ms3_H1_2A)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(Unsync_ms2_H1_2B)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(Unsync_ms3_H1_2C)
    suite = unittest.TestSuite([suite1, suite2, suite3, suite4])

    unittest.TextTestRunner(verbosity=2).run(suite)