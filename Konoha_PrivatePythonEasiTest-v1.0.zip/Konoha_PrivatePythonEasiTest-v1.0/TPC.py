#Services to disable: SSDP Discovery, WinHTTP Web Proxy Auto-Discovery Service, Computer Browser, Windows Media Player Network Sharing Service, Function Discovery Provider Host, Function Discovery Resource Publication
#Open browser. Type localhost:1947 and Configuration->Access to Remote License Managers->disable Broadcast Search for Remote Licenses
#Start->gpedit.msc. Local Computer Policy -> Computer Configuration -> Administrative templates -> network -> DNS Client -> Turn off Multicast Name Resolution set to Enabled
from ms import create_ms, is_ms_patriot, is_ms_nextgen
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_TPC(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", type="QAM"):
        super(ms1_TPC, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.type = type;
        
    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)

    def tearDown(self):
        self.ms1.destroy()
 
    def check_results(self, results, size, number_of_transmissions, good_rate, perfect_rate):
        perfect_time = 0
        good_time = 0
        bad_time = 0
        for result in results:
            if result.error != False:
                self.fail("Error in transmission")
            if result.size !=  size:
                self.fail("Bad size of transmit package")
            if result.time <= 10:
                perfect_time = perfect_time + 1
            elif result.time > 11:
                bad_time = bad_time + 1
            else:
                good_time = good_time+1
        if perfect_time < int(number_of_transmissions*perfect_rate):
            self.fail("too few perfect transmissions")
        if good_time + perfect_time < int(number_of_transmissions*good_rate):
            self.fail("too_few good transmissions")
        return 0
        
 
    def connect(self):
        self.ms1.Connect()
        self.ms1.EnterTMO()
        self.ms1.ChangeTG("TG1")
        
    @launch_during_rerun_if_any_test_failed
    def test_000_set_packet_data_codeplug(self):
        self.ms1.Connect()
        self.ms1.SetPDMode(self.type)

    def test_001_send_100KB_to_server(self):
        results = []
        self.connect()
        self.ms1.SetPDConnection()
        sleep(2)
        for i in range(20):
            r = self.ms1.tpc(0).TPCSendFile(100000, 30)
            results.append(r)
        self.ms1.ClosePDConnection()
        result = self.check_results(results,100000, 20, 0.8, 0.95)
        self.assertEqual(result, 0)
       
    
    def test_002_receive_100KB_to_server(self):
        results = []
        self.connect()
        self.ms1.SetPDConnection()
        sleep(2)
        for i in range(20):
            r = self.ms1.tpc(0).TPCReceiveFile(100000, 30)
            results.append(r)
        self.ms1.ClosePDConnection()
        result = self.check_results(results,100000, 20, 0.8, 0.95)
        self.assertEqual(result, 0)
        
    def test_003_send_1MB_to_server(self):
        self.connect()
        self.ms1.SetPDConnection()
        sleep(2)
        r = self.ms1.tpc(0).TPCSendFile(1024000, 3000)

        self.ms1.ClosePDConnection()
        self.assertEqual(r.error, False, "error in transmission")
       
    
    def test_004_receive_1MB_to_server(self):
        self.connect()
        self.ms1.SetPDConnection()
        sleep(2)
        r = self.ms1.tpc(0).TPCReceiveFile(1024000, 3000)

        self.ms1.ClosePDConnection()
        self.assertEqual(r.error, False, "error in transmission")

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_TPC)
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)