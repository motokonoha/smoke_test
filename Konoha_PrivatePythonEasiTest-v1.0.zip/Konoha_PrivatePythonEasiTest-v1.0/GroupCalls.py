from ms import create_ms
import unittest
from time import sleep
from mot_test import MotTestCase

class ms1_GroupCalls(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2"):
        super(ms1_GroupCalls, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 5

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
    
    def connect(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
    
    def ms1_emgcy_call(self):
        self.ms1.HoldPTT()
        sleep(1)
        self.ms2.CheckIncomingEmergencyCall(self.ms1,"TG1")
        self.ms1.CheckOngoingEmergencyCall("TG1")
        self.ms1.ReleasePTT()
        self.ms2.CheckOngoingEmergencyCall("TG1")
        sleep(0.5)

    
    def ms2_emgcy_call(self):
        self.ms2.HoldPTT()
        sleep(1)
        self.ms1.CheckIncomingEmergencyCall(self.ms2, "TG1")
        self.ms2.CheckOngoingEmergencyCall("TG1")
        self.ms2.ReleasePTT()
        self.ms1.CheckOngoingEmergencyCall("TG1")
        sleep(0.5)
    
    def ms1_GC(self):
        self.ms1.MakeGC('TG1')
        sleep(1)
        self.ms2.VerifyIncomingGC(self.ms1, 'TG1')
        self.ms2.VerifyOngoingGC('TG1', async = True)       
        self.ms1.ReleasePTT()
        self.ms2.wait()
    
    def ms2_GC(self):
        self.ms2.MakeGC('TG1')
        sleep(1)
        self.ms1.VerifyIncomingGC(self.ms2, 'TG1')
        self.ms1.VerifyOngoingGC('TG1', async = True)
        self.ms2.ReleasePTT()
        self.ms1.wait()
        
    def test_001_ms1_enters_TXI_mode(self):
        self.connect()
        self.ms1.EnterTXI()
        self.ms1.ClickPTT()
        self.ms1.IsTextOnScreen("Not Allowed In TXI Mode")
        self.ms2.MakeGC('TG1')
        self.ms1.VerifyIncomingGC(self.ms2, "TG1")
        self.ms2.ReleasePTT()
        self.ms1.VerifyOngoingGC('TG1')
        self.ms1.ClickPTT()
        self.ms1.IsTextOnScreen("Not Allowed In TXI Mode")
        self.ms1.ExitTXI()
        self.ms1.MakeGC('TG1')
        self.ms2.VerifyIncomingGC(self.ms1, "TG1")
        self.ms1.ReleasePTT()
        self.ms2.VerifyOngoingGC("TG1")
        self.ms1.EnterTXI()
        self.ms1.EnterEmergencyMode()
        self.ms1.CheckOngoingEmergencyMicOn("TG1")
        self.ms2.CheckIncomingEmergencyCall(self.ms1, "TG1")
        
        self.ms1.ReleasePTT()     
        self.ms1.ExitEmergencyMode()
        self.ms2.PressAndReleaseKey("END")
                
 
    
    def test_002_ms1_starts_preemption(self):
        self.connect()
        self.ms1.EnterEmergencyMode()
        self.ms1.CheckOngoingEmergencyMicOn("TG1")
        self.ms2.CheckIncomingEmergencyCall(self.ms1, "TG1")
        self.ms1.PressAndReleaseKey("END")
        self.ms1.PressAndReleaseKey("END")
        sleep(30)
        self.ms2.MakeGC('TG1')
        self.ms1.PressAndHoldKey("PTT")
        self.ms2.IsTextOnScreen("Call Preempted")
        self.ms2.IsTextOnScreen("PTT Denied")
        self.ms2.ReleasePTT()
        self.ms1.ReleasePTT()
        sleep(5)
        for i in range(self.loop):
            self.ms1_emgcy_call()
            self.ms2_emgcy_call()

        for i in range(self.loop):
            self.ms1_emgcy_call()

        for i in range(self.loop):
            self.ms2_emgcy_call()

        
        self.ms1_emgcy_call()
        self.ms1.PressAndReleaseKey("END")
        self.ms1.IsTextOnScreen("Emergency")
        self.ms1.ExitEmergencyMode()

    def test_003_ms1_starts_preemption_hotmic_alarm(self):
        self.connect()
        self.ms2.MakeGC('TG1')
        self.ms1.VerifyIncomingGC(self.ms2, 'TG1')
        self.ms1.EnterEmergencyMode()
        self.ms2.IsTextOnScreen("Call Preempted", 5)
        self.ms2.IsTextOnScreen("PTT Denied", 5)
        self.ms2.ReleasePTT()
        self.ms1.ClickPTT()
        self.ms1.IsTextOnScreen("Emgcy Mic Ended")
      
        for i in range(self.loop):
            self.ms1_emgcy_call()
            self.ms2_emgcy_call()

        for i in range(self.loop):
            self.ms1_emgcy_call()

        for i in range(self.loop):
            self.ms2_emgcy_call()

        self.ms1.IsTextOnScreen("Emergency")
        self.ms1.ExitEmergencyMode()

    def test_004_ms1_starts_GC(self):
        self.connect()
        self.ms1.MakeGC('TG1')
        self.ms2.VerifyIncomingGC(self.ms1, 'TG1')
        self.ms1.ReleasePTT()

        for i in range(2*self.loop):
            self.ms1_GC()
            self.ms2_GC()
            

        for i in range(self.loop):
            self.ms1_GC()

        for i in range(self.loop):
            self.ms2_GC()


class ms2_GroupCalls(ms1_GroupCalls):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_GroupCalls, self).__init__(testname, ms1_cfg, ms2_cfg)
        
class ms3_GroupCalls(ms1_GroupCalls):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_GroupCalls, self).__init__(testname, ms1_cfg, ms2_cfg)          
        
if __name__ == "__main__":
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms2_GroupCalls)
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_GroupCalls)
    suite = unittest.TestSuite([suite1, suite2])
    unittest.TextTestRunner(verbosity=2).run(suite)
        