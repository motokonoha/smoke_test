from ms import create_ms
import unittest
import math
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_Repeater_interactive(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_1"):
        super(ms1_Repeater_interactive, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 3
        self.TG = TG

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()
    
    def connect_repeater_sync(self):
        self.ms1.Connect(async=True)        
        self.ms2.Connect(async=True)
        self.ms3.Connect()       
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterDMO()
        self.ms1.EnterREP(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.TG, async = True)
        self.ms2.ChangeTG(self.TG, async = True)
        self.ms3.ChangeTG(self.TG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyREPIdle(self.TG, async = True)
        self.ms2.VerifyDMOIdle(self.TG, async = True)
        self.ms3.VerifyDMOIdle(self.TG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms3.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive&Transmit", async = True)
        self.ms2.SetConfig("Repeater", async = True)
        self.ms3.SetConfig("Repeater")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
        self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)

    def ms1_GC_interactive_Repeater(self, TG):
        self.ms1.MakeGCasREP(TG)
        sleep(1)
        self.ms2.VerifyIncomingGC(self.ms1, TG)
        self.ms3.VerifyIncomingGC(self.ms1, TG)
        self.ms2.VerifyOngoingGC(TG, async = True) 
        self.ms3.VerifyOngoingGC(TG, async = True)
        self.ms1.ReleasePTT()
        self.ms2.wait()
        self.ms3.wait()
        
    def ms2_GC_via_ms1_Repeater(self, TG):
        self.ms2.MakeGC(TG)
        sleep(1)
        self.ms1.VerifyIncomingGCasREP(self.ms2, TG)
        self.ms3.VerifyIncomingGC(self.ms2, TG)
        self.ms1.VerifyOngoingGCasREP(TG, async = True)
        self.ms3.VerifyOngoingGC(TG, async = True)               
        self.ms2.ReleasePTT()
        self.ms1.wait()
        self.ms3.wait()      

    def ms1_HDPC_interactive_Repeater(self):
        sleep(1)  
        self.ms1.HoldPTT()
        sleep(2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.ReleasePTT()        

    def ms2_HDPC_to_ms1_Repeater(self):
        sleep(1)  
        self.ms2.HoldPTT()
        sleep(2)
        self.ms1.IsPrivateCallOngoingasREP(self.ms2)
        self.ms2.ReleasePTT()
        

    def ms1_emgcy_call_interactive_Repeater(self):
        self.ms1.HoldPTT()
        sleep(1)
        self.ms1.VerifyOngoingGCasREP(self.TG)
        self.ms2.CheckIncomingEmergencyCall(self.ms1,self.TG)
        self.ms3.CheckIncomingEmergencyCall(self.ms1,self.TG)
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000, async = True)
        self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms3.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ReleasePTT()
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        self.ms3.CheckOngoingEmergencyCall(self.TG)
        sleep(1)
        
    def ms2_emgcy_call_via_ms1_Repeater(self):
        self.ms2.HoldPTT()
        sleep(1)
        self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)   
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000, async = True)
        self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms3.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
        self.ms1.wait()
        self.ms2.wait()
        self.ms3.CheckIncomingEmergencyCall(self.ms2, self.TG)
        self.ms2.ReleasePTT()
        sleep(1)

    def ms1_emgcy_call_changeover_interactive_Repeater(self):
        self.ms1.HoldPTT()
        sleep(1)
        self.ms1.VerifyOngoingGCasREP(self.TG)
        self.ms2.CheckIncomingEmergencyCall(self.ms1,self.TG)
        self.ms3.CheckIncomingEmergencyCall(self.ms1,self.TG)
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms3.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ReleasePTT()
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        self.ms3.CheckOngoingEmergencyCall(self.TG)
        sleep(1)
        
    def ms3_emgcy_call_via_ms1_Repeater(self):
        self.ms3.HoldPTT()
        sleep(1)
        self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG) 
        self.ms2.CheckIncomingEmergencyCall(self.ms3, self.TG)
        self.ms3.CheckOngoingEmergencyCall(self.TG)        
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
        self.ms3.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000)
        self.ms1.wait()
        self.ms2.wait()
        self.ms3.ReleasePTT()
        sleep(1)        
    
   
    def test_001_GC_interactive_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2_GC_via_ms1_Repeater(self.TG)
            sleep(1)
            
            for i in range(self.loop):
                self.ms1_GC_interactive_Repeater(self.TG)
                sleep(1)
                self.ms2_GC_via_ms1_Repeater(self.TG)            
                sleep(1)

            self.ms1.VerifyREPIdle(self.TG)
            self.ms1_GC_interactive_Repeater(self.TG)
            sleep(1)

            for i in range(self.loop):
                self.ms2_GC_via_ms1_Repeater(self.TG)
                sleep(1)
                self.ms1_GC_interactive_Repeater(self.TG)
                sleep(1)

            for i in range(self.loop):
                self.ms1_GC_interactive_Repeater(self.TG)
                sleep(1)

            for i in range(self.loop):
                self.ms2_GC_via_ms1_Repeater(self.TG)
                sleep(1)

        else:
            self.skipTest("Not supporting repeater feature")


    def test_002_HDPC_interactive_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeHDPC_DMO(self.ms1)
            self.ms1.IsPrivateCallOngoingasREP(self.ms2)
            self.ms2.ReleasePTT()
            sleep(1)

            for i in range(self.loop):
                self.ms1_HDPC_interactive_Repeater()    
                self.ms2_HDPC_to_ms1_Repeater()                                       

            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.MakeHDPC_DMOasREP(self.ms2)
            self.ms2.IsPrivateCallOngoing(self.ms1)
            self.ms1.ReleasePTT()
            sleep(1)

            for i in range(self.loop):
                self.ms2_HDPC_to_ms1_Repeater()
                self.ms1_HDPC_interactive_Repeater()                             
                                               
            for i in range(self.loop):
                self.ms1_HDPC_interactive_Repeater()

            for i in range(self.loop):
                self.ms2_HDPC_to_ms1_Repeater()
            
        else:
            self.skipTest("Not supporting repeater feature")

    def test_003_call_to_dummy_ms_interactive_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            #~ self.ms1.EnterNumber(100100)
            #~ self.ms1.PressAndHoldKey("PTT")     
            #~ self.ms1.IsTextOnScreen("Party Not Available")
            #~ self.ms1.ReleasePTT()
            
            self.ms1.VerifyREPIdle(self.TG)
            self.ms3.EnterEmergencyMode()
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms3.HoldPTT()
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms3.ExitEmergencyMode()

            self.ms1.VerifyREPIdle(self.TG)
            #~ self.ms1.EnterNumber(100100)
            #~ self.ms1.PressAndHoldKey("PTT")     
            #~ self.ms1.IsTextOnScreen("Party Not Available")
            #~ self.ms1.ReleasePTT()
            
            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.MakeHDPC_DMOasREP(self.ms2)
            self.ms2.IsPrivateCallOngoing(self.ms1)
            self.ms1.ReleasePTT()
        
        else:
            self.skipTest("Not supporting repeater feature") 
            
    def test_004_SDS_interactive_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms1.ClearInbox(async = True)
            self.ms2.ClearInbox()
            self.ms1.wait()
            sleep(1)
            for i in range(3):
                self.ms2.IsTextOnScreen(str(i+1)+" New Message", async = True)
                self.ms1.SendPrivSDSFromTemplate(self.ms2, "long")
                self.ms2.wait()
                sleep(10)
            self.ms2.VerifyNumberOfMsgInInbox(3)           
            self.ms1.ClearInbox(async = True)
            self.ms2.ClearInbox(async = True)
            self.ms3.ClearInbox()
            self.ms1.wait()
            self.ms2.wait()
            
            for j in range(3):
                self.ms2.IsTextOnScreen(str(j+1)+" New Message", async = True)
                self.ms3.IsTextOnScreen(str(j+1)+" New Message", async = True)
                self.ms1.SendGroupSDSFromTemplate("long")
                self.ms2.wait()
                self.ms3.wait()
                sleep(10)
            self.ms2.VerifyNumberOfMsgInInbox(3)
            self.ms3.VerifyNumberOfMsgInInbox(3)
            
        else:
            self.skipTest("Not supporting repeater feature")

    def test_005_ms_ms_GC_PC_interactive_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.SetConfig("MS - MS")
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms2.MakeGC(self.TG)
            sleep(1)
            self.ms1.VerifyIncomingGC(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)
            self.ms1.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000, async = True)
            self.ms3.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms1.wait()
            self.ms1.VerifyOngoingGC(self.TG, async = True)
            self.ms3.VerifyOngoingGC(self.TG, async = True)               
            self.ms2.ReleasePTT()
            self.ms1.wait()
            self.ms3.wait()
            sleep(2)
            self.ms1.MakeGC(self.TG)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000, async = True)
            self.ms3.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms2.wait()
            self.ms2.VerifyOngoingGC(self.TG, async = True)
            self.ms3.VerifyOngoingGC(self.TG, async = True)
            self.ms1.ReleasePTT()
            self.ms2.wait()
            self.ms3.wait()
            
            self.ms1.VerifyREPIdle(self.TG)            
            self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 5000, async = True)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000, async = True)
            self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 5000)
            self.ms1.wait()
            self.ms2.wait()
            
            self.ms2.MakeHDPC_DMO(self.ms1)
            self.ms1.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms1.IsPrivateCallOngoing(self.ms2)
            self.ms2.ReleasePTT()
            sleep(2)
            self.ms1.HoldPTT()
            self.ms1.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000, async = True)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms1.wait()
            self.ms2.IsPrivateCallOngoing(self.ms1)
            self.ms1.ReleasePTT()
            
            self.ms1.VerifyREPIdle(self.TG) 
            self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 5000, async = True) 
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000, async = True)
            self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 5000)
            self.ms1.wait()
            self.ms2.wait()           
        else:
            self.skipTest("Not supporting repeater feature")
    
    def test_006_ms_ms_HDPC_GC_preemption_interactive_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.SetConfig("MS - MS")
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)
            self.ms2.MakeHDPC_DMO(self.ms1)
            self.ms1.IsPrivateCallOngoing(self.ms2)
            self.ms1.VerifyIcon("DIRECT_MODE", "DMO_ON", 5000)

            self.ms1.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted", 5)
            self.ms2.IsTextOnScreen("PTT Denied", 5)
            self.ms2.ReleasePTT()
            
            self.ms1.PressAndHoldKey("PTT")
            self.ms1.IsTextOnScreen("Emgcy Mic Ended", 5)
            #self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 5000, async = True) #there is icon "repeater on", should be "repeater mode" old SR 
            self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 5000, async = True)
            self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 5000)
            self.ms2.wait()        
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000, async = True)
            self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000, async = True)
            self.ms3.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms1.wait()
            self.ms2.wait()
            self.ms1.ReleasePTT()
            self.ms2.CheckOngoingEmergencyCall(self.TG)
            self.ms3.CheckOngoingEmergencyCall(self.TG)
            self.ms1.ExitEmergencyMode()
            
        else:
            self.skipTest("Not supporting repeater feature") 
            
    def test_007_GC_with_preemption_interactive_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeGC(self.TG)
            self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)
            self.ms1.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted", 5)
            self.ms2.IsTextOnScreen("PTT Denied", 5)
            self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)    
            self.ms1.CheckOngoingEmergencyMicOn(self.TG)                  
            self.ms2.ReleasePTT()
            self.ms1.ClickPTT()
            self.ms1.IsTextOnScreen("Emgcy Mic Ended", 5)
            
            for i in range(self.loop):
                self.ms1_emgcy_call_interactive_Repeater()
                self.ms2_emgcy_call_via_ms1_Repeater()
                
            self.ms1.IsTextOnScreen("Emergency")
            self.ms2.VerifyDMOIdle(self.TG)
            self.ms3.VerifyDMOIdle(self.TG)
            self.ms1.ExitEmergencyMode()
            sleep(2)
                    
            self.ms1.MakeGCasREP(self.TG)
            self.ms2.VerifyIncomingGC(self.ms1, self.TG)
            self.ms3.VerifyIncomingGC(self.ms1, self.TG)
            self.ms3.EnterEmergencyMode()
            self.ms1.IsTextOnScreen("Call Preempted", 5)
            self.ms1.IsTextOnScreen("PTT Denied", 5)
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms1.ReleasePTT()
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms3.ClickPTT()
            self.ms3.IsTextOnScreen("Emgcy Mic Ended", 5)

            for i in range(self.loop):
                self.ms1_emgcy_call_changeover_interactive_Repeater()
                self.ms3_emgcy_call_via_ms1_Repeater()               

            for i in range(self.loop):
                self.ms3_emgcy_call_via_ms1_Repeater()

            for i in range(self.loop):
                self.ms1_emgcy_call_changeover_interactive_Repeater()            

            self.ms3.IsTextOnScreen("Emergency")
            sleep(5)
            self.ms1.VerifyREPIdle(self.TG)
            self.ms2.VerifyDMOIdle(self.TG)
            self.ms3.ExitEmergencyMode()
            
        else:
            self.skipTest("Not supporting repeater feature")        
        
    def test_008_GC_with_preemption_reservation_interactive_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeGC(self.TG)
            self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)
            self.ms2.ReleasePTT()
            self.ms1.VerifyOngoingGCasREP(self.TG, async = True)
            self.ms3.VerifyOngoingGC(self.TG)
            self.ms1.wait()           
            self.ms1.EnterEmergencyMode()
            self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)    
            self.ms1.CheckOngoingEmergencyMicOn(self.TG, async = True)
            self.ms2.CheckOngoingEmergencyCall(self.TG)
            self.ms1.wait()                  
            self.ms1.ExitEmergencyMode()
            
            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.MakeGCasREP(self.TG)
            self.ms2.VerifyIncomingGC(self.ms1, self.TG)
            self.ms3.VerifyIncomingGC(self.ms1, self.TG)
            self.ms1.ReleasePTT()
            self.ms2.VerifyOngoingGC(self.TG, async = True)
            self.ms3.VerifyOngoingGC(self.TG)
            self.ms2.wait()
            self.ms3.EnterEmergencyMode()
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms3.ExitEmergencyMode()            
            
        else:
            self.skipTest("Not supporting repeater feature")        
                        
    def test_009_HDPC_with_preemption_interactive_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeHDPC_DMO(self.ms3)
            self.ms1.VerifyOngoingPCasREP(self.ms2, self.ms3)
            self.ms1.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted",5)
            self.ms2.IsTextOnScreen("PTT Denied", 5)
            self.ms1.CheckOngoingEmergencyMicOn(self.TG)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_ON", 3000)
            self.ms1.HoldPTT()
            self.ms1.IsTextOnScreen("Emgcy Mic Ended", 5)
            self.ms1.VerifyOngoingGCasREP(self.TG)
            self.ms2.CheckIncomingEmergencyCall(self.ms1, self.TG)
            self.ms3.CheckIncomingEmergencyCall(self.ms1, self.TG)
            self.ms1.ReleasePTT();
            self.ms1.ExitEmergencyMode()         
            
            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.MakeHDPC_DMOasREP(self.ms2)
            self.ms2.EnterEmergencyMode()
            self.ms1.IsTextOnScreen("Call Preempted",5)
            self.ms1.IsTextOnScreen("PTT Denied", 5)
            self.ms2.CheckOngoingEmergencyMicOn(self.TG) 
            self.ms1.ReleasePTT()
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms2.HoldPTT()
            self.ms2.IsTextOnScreen("Emgcy Mic Ended", 5)
            self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
            self.ms2.CheckOngoingEmergencyCall(self.TG)
            self.ms3.CheckIncomingEmergencyCall(self.ms2, self.TG)
            self.ms2.ReleasePTT();
            self.ms2.ExitEmergencyMode()
            
        else:
            self.skipTest("Not supporting repeater feature")    
    
    def test_010_HDPC_with_preemption_reservation_interactive_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeHDPC_DMO(self.ms1)
            self.ms1.IsPrivateCallOngoingasREP(self.ms2)
            self.ms2.ReleasePTT()
            sleep(1)           
            self.ms1.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted",5)
            self.ms2.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)    
            self.ms1.CheckOngoingEmergencyMicOn(self.TG, async = True)
            self.ms2.CheckOngoingEmergencyCall(self.TG)
            self.ms1.wait()                  
            self.ms1.ExitEmergencyMode()
            
            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.MakeHDPC_DMOasREP(self.ms2)
            self.ms2.IsPrivateCallOngoing(self.ms1)
            self.ms1.ReleasePTT()
            sleep(1)
            self.ms3.EnterEmergencyMode()
            self.ms1.IsTextOnScreen("Call Preempted",5)
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms3.ExitEmergencyMode()            
            
        else:
            self.skipTest("Not supporting repeater feature")
            
    @launch_during_rerun_if_any_test_failed
    def test_999_enter_DMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS", async = True)
        self.ms3.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms2.wait()
            
            
class ms2_Repeater_interactive(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_1"):
        super(ms2_Repeater_interactive, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)     

class ms3_Repeater_interactive(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_1"):
        super(ms3_Repeater_interactive, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms1_Repeater_interactive_2A(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2A"):
        super(ms1_Repeater_interactive_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms2_Repeater_interactive_2A(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2A"):
        super(ms2_Repeater_interactive_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)  

class ms3_Repeater_interactive_2A(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_2A"):
        super(ms3_Repeater_interactive_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)     
        
class ms1_Repeater_interactive_2B(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2B"):
        super(ms1_Repeater_interactive_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms2_Repeater_interactive_2B(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2B"):
        super(ms2_Repeater_interactive_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)     

class ms3_Repeater_interactive_2B(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_2B"):
        super(ms3_Repeater_interactive_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms1_Repeater_interactive_2C(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2C"):
        super(ms1_Repeater_interactive_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)  

class ms2_Repeater_interactive_2C(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2C"):
        super(ms2_Repeater_interactive_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)      

class ms3_Repeater_interactive_2C(ms1_Repeater_interactive):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_2C"):
        super(ms3_Repeater_interactive_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)          

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater_interactive_2C)
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)                   
                