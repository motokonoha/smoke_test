import unittest, math, os, re

from ms import create_ms, is_ms_frodo, RCException
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

def ensure_frodo_will_act_as_gtwy(f):
    def decorator(self):
        if is_ms_frodo(self.Gtwy_cfg):
            f(self)
        else:
            self.skipTest("Not supporting gateway feature")
    return decorator

class Gateway_SDSes_statuses_from_DMO(MotTestCase):
    def __init__(self, testname, Gtwy_cfg = "ms1", msDMO_cfg = "ms2", msTMO_cfg = "ms3", DTG = "DTG_H1_1", tmo_tg = "TG1"):
        super().__init__(testname)
        self.Gtwy_cfg = Gtwy_cfg
        self.msDMO_cfg = msDMO_cfg
        self.msTMO_cfg = msTMO_cfg
        self.loop = 2
        self.DTG = DTG
        self.tmo_tg = tmo_tg

    def setUp(self):
        self.Gtwy = create_ms(self.Gtwy_cfg)
        self.msDMO = create_ms(self.msDMO_cfg)
        self.msTMO = create_ms(self.msTMO_cfg)

        self.Gtwy.Connect(async = True)
        self.msDMO.Connect(async = True)
        self.msTMO.Connect()        
        self.Gtwy.wait()
        self.msDMO.wait()

        self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

    def tearDown(self):
        self.Gtwy.destroy()
        self.msDMO.destroy()
        self.msTMO.destroy()
    
    def gw_sync(self):

        self.Gtwy.EnterTMO(async = True)
        self.msDMO.EnterDMO(async = True)
        self.msTMO.EnterTMO()
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.ChangeTG(self.tmo_tg, async = True)
        self.msDMO.ChangeTG(self.DTG, async = True)
        self.msTMO.ChangeTG(self.tmo_tg)
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.EnterGW(async = True)       
        self.msDMO.VerifyDMOIdle(self.DTG, async = True)
        self.msTMO.VerifyTMOIdle(self.tmo_tg)
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.ChangeTG(self.DTG)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, self.DTG)
        self.Gtwy.PressAndReleaseKey("END")
        self.msDMO.PressAndReleaseKey("END")
        self.Gtwy.SetMonitor("Receive only", async = True)
        self.msDMO.SetConfig("Gateway")
        self.Gtwy.wait()

        self.msDMO.VerifyDMOIdle(self.DTG)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.wait()

    @launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msDMO.CommitCp()

    @launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msDMO.CommitCp()

    def sendStatus(self, srcMs):
        srcMs.PressAndHoldKey("4")
        srcMs.IsTextOnScreen("Status Sent")
        sleep(2)
        srcMs.ReleaseKey("4")

    def verify_number_of_messages_is_in_range(self, ms, acceptable_range):
        try:
            ms.PressAndReleaseKey("END")
            ms.VerifyNumberOfMsgInInbox(max(acceptable_range))
        except RCException as rcErr:
            num_of_msgs_in_inbox = sum((int(x) for x in re.search("Inbox\|(\d+)/(\d+)", rcErr.rc_status_message).groups()))
            if num_of_msgs_in_inbox not in acceptable_range:
                raise RCException("Number of messages in Inbox ({})out of acceptable range ({})".format(num_of_msgs_in_inbox, str(acceptable_range)),
                                  rcErr.rc_return_value,
                                  rcErr.rc_status_message)

    def clear_inbox_for(self, mses):
        for ms in mses:
            ms.ClearInbox(async = True)
        for ms in mses:
            ms.wait()

    def sendPrivateSds(self, srcMs, dstMs):
        #srcMs.SendPrivSDSFromTemplate(dstMs, "vlong") # TODO: after implementing GTWY SDS delivery acknoledgments we should use ms.SendPrivSDSFromTemplate(...) method
        srcMs.PressAndReleaseKey("MENU")               # so sending radio can then receive and validate acknowledgment
        srcMs.SelectMenuItem("Messages")
        sleep(0.5)
        srcMs.SelectMenuItem("Templates")
        sleep(0.5)
        srcMs.SelectMenuItem("vlong")
        sleep(0.5)
        srcMs.SelectMenuItem("Private")
        sleep(0.5)
        srcMs.EnterNumber(dstMs.issi)
        sleep(0.5)
        srcMs.PressAndReleaseKey("SK1")
        srcMs.IsTextOnScreen("Message Failed", 0)
        sleep(5)

    def verify_if_gtwy_is_not_bricked(self):
        self.Gtwy.ChangeTG(self.DTG, async = True)
        self.msDMO.ChangeTG(self.DTG)
        self.Gtwy.wait()
        sleep(10)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, self.DTG)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.VerifyDMOIdle(self.DTG)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)

        self.msDMO.MakeGC(self.DTG)
        sleep(5)
        self.msDMO.VerifyOngoingGC(self.DTG)       
        self.msTMO.VerifyIncomingGC(self.Gtwy, self.tmo_tg)

        self.msDMO.ReleasePTT()

    # Not testable:
    # - GW_STATUS_DMO_TMO_T_001: 1) we cannot use TMO radio to verify since on Dimetra statuses are not forwarded back to TMO MSes attached to TG to which status was sent
    #                            2) we cannot use GTWY MMI since status according to requirements will not be shown in GTWY MMI nor in GTWY inbox
    # GW_SDS_DMO_TMO_T_001
    # GW_SDS_DMO_TMO_T_004
    # GW_SDS_DMO_TMO_T_006
    # GW_SDS_DMO_TMO_T_012
    @ensure_frodo_will_act_as_gtwy
    def test_001_send_dmo_group_sds_via_gtwy(self):
        self.gw_sync()

        talkgroups = ["DTG_H1_1", "DTG_H1_2A", "DTG_H1_2B", "DTG_H1_2C", "DTG_OG"]

        for tg in talkgroups:

            self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

            self.msDMO.ChangeTG(tg, async = True)
            self.Gtwy.ChangeTG(tg)
            self.msDMO.wait()
            self.msDMO.SetConfig("Gateway")
            sleep(10)
            self.msDMO.VerifyDMOIdle(tg)
            self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)
            self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

            num_of_repeats = 5
            for repeat in range(1, num_of_repeats+1):
                self.logger.info("Sending SDS {}/{}".format(repeat, num_of_repeats))
                self.msDMO.PressAndReleaseKey("END")
                self.msDMO.SendGroupSDSFromTemplate("vlong")
                sleep(20)

            self.msTMO.PressAndReleaseKey("END")
            self.msTMO.VerifyNumberOfMsgInInbox(num_of_repeats)

    # GW_SDS_DMO_TMO_T_002: Target test. Modification of [GW_SDS_DMO_TMO_T_001]. Send 100 SDSes. Lowest FCD = 2. Lowest Repeats = 1
    @ensure_frodo_will_act_as_gtwy
    def test_002_send_dmo_group_sds_via_gtwy_stress_test(self):

        self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msDMO.CommitCp()

        self.gw_sync()

        num_of_repeats = 100
        for repeat in range(1, num_of_repeats+1):
            self.logger.info("Sending SDS {}/{}".format(repeat, num_of_repeats))
            self.msDMO.PressAndReleaseKey("END")
            self.msDMO.SendGroupSDSFromTemplate("medium")
            sleep(10)

        acceptable_range = range(90, 100+1)
        self.verify_number_of_messages_is_in_range(self.msTMO, acceptable_range)

        self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msDMO.CommitCp()

    # GW_SDS_DMO_TMO_T_003
    # GW_SDS_DMO_TMO_T_005
    @ensure_frodo_will_act_as_gtwy
    def test_003_send_dmo_private_sds_via_gtwy(self):
        self.gw_sync()

        outgoing_security_class = {"clear" : 0, 
                                   "2a" : 2,
                                   "2b" : 3,
                                   "2c" : 1}

        for (sec_label, cp_sec_val) in outgoing_security_class.items():
            self.msDMO.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', cp_sec_val)
            self.msDMO.CommitCp()

            self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

            num_of_repeats = 5
            for repeat in range(1, num_of_repeats+1):
                self.logger.info("Sending SDS {}/{} using SC {}".format(repeat, num_of_repeats, sec_label))
                self.msDMO.PressAndReleaseKey("END")
                self.sendPrivateSds(self.msDMO, self.msTMO)
                sleep(5)

            self.msTMO.PressAndReleaseKey("END")
            self.msTMO.VerifyNumberOfMsgInInbox(num_of_repeats)

        self.msDMO.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', outgoing_security_class["clear"])
        self.msDMO.CommitCp()

    # GW_SDS_DMO_TMO_T_007
    @ensure_frodo_will_act_as_gtwy
    def test_004_send_dmo_group_sds_via_gtwy_while_gtwy_is_attached_to_different_dmo_tg(self):
        self.gw_sync()

        tg1 = "DTG_H1_1"
        tg2 = "DTG_H2_1"

        self.Gtwy.ChangeTG(tg1)
        self.msDMO.ChangeTG(tg2)
        sleep(10)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, tg1)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.VerifyDMOIdle(tg2)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)

        self.msDMO.PressAndReleaseKey("END")
        self.msDMO.SendGroupSDSFromTemplate("vlong")
        sleep(20)

        self.msTMO.PressAndReleaseKey("END")
        self.msTMO.VerifyNumberOfMsgInInbox(0)

        self.verify_if_gtwy_is_not_bricked()

    # GW_SDS_DMO_TMO_T_008
    @ensure_frodo_will_act_as_gtwy
    def test_005_send_dmo_group_sds_via_gtwy_while_gtwy_is_attached_to_tg_with_different_mni(self):
        self.gw_sync()

        home_tg = "DTG_H1_1"
        foreign_tg = "DTG_I1_1"

        self.Gtwy.ChangeTG(foreign_tg)
        self.msDMO.ChangeTG(home_tg)
        sleep(10)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, foreign_tg)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.VerifyDMOIdle(home_tg)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)

        self.msDMO.PressAndReleaseKey("END")
        self.msDMO.SendGroupSDSFromTemplate("vlong")
        sleep(20)

        self.msTMO.PressAndReleaseKey("END")
        self.msTMO.VerifyNumberOfMsgInInbox(0)

        self.verify_if_gtwy_is_not_bricked()

    # GW_SDS_DMO_TMO_T_014
    def test_006_send_dmo_private_sds_via_gtwy_to_gtwy(self):
        self.gw_sync()

        self.sendPrivateSds(self.msDMO, self.Gtwy)
        sleep(15)

        self.Gtwy.PressAndReleaseKey("END")
        self.Gtwy.VerifyNumberOfMsgInInbox(1)
        sleep(5)

        self.verify_if_gtwy_is_not_bricked()

    # GW_SDS_DMO_TMO_T_014
    def test_007_send_dmo_private_sds_using_msms_mode_to_gtwy(self):
        self.gw_sync()

        self.msDMO.SetConfig("MS - MS")
        self.sendPrivateSds(self.msDMO, self.Gtwy)
        sleep(15)

        self.Gtwy.PressAndReleaseKey("END")
        self.Gtwy.VerifyNumberOfMsgInInbox(0)
        sleep(5)

        self.msDMO.SetConfig("Gateway")
        self.verify_if_gtwy_is_not_bricked()
        
        
        
        
        
        
        
        
        
class Gateway_SDSes_statuses_from_TMO(MotTestCase):
    def __init__(self, testname, Gtwy_cfg = "ms1", msDMO_cfg = "ms2", msTMO_cfg = "ms3", DTG = "DTG_H1_1", tmo_tg = "TG1"):
        super().__init__(testname)
        self.Gtwy_cfg = Gtwy_cfg
        self.msDMO_cfg = msDMO_cfg
        self.msTMO_cfg = msTMO_cfg
        self.loop = 2
        self.DTG = DTG
        self.tmo_tg = tmo_tg

    def setUp(self):
        self.Gtwy = create_ms(self.Gtwy_cfg)
        self.msDMO = create_ms(self.msDMO_cfg)
        self.msTMO = create_ms(self.msTMO_cfg)

        self.Gtwy.Connect(async = True)
        self.msDMO.Connect(async = True)
        self.msTMO.Connect()        
        self.Gtwy.wait()
        self.msDMO.wait()

        self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

    def tearDown(self):
        self.Gtwy.destroy()
        self.msDMO.destroy()
        self.msTMO.destroy()
    
    def gw_sync(self):

        self.Gtwy.EnterTMO(async = True)
        self.msDMO.EnterDMO(async = True)
        self.msTMO.EnterTMO()
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.ChangeTG(self.tmo_tg, async = True)
        self.msDMO.ChangeTG(self.DTG, async = True)
        self.msTMO.ChangeTG(self.tmo_tg)
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.EnterGW(async = True)       
        self.msDMO.VerifyDMOIdle(self.DTG, async = True)
        self.msTMO.VerifyTMOIdle(self.tmo_tg)
        self.Gtwy.wait()
        self.msDMO.wait()
        self.Gtwy.ChangeTG(self.DTG)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, self.DTG)
        self.Gtwy.PressAndReleaseKey("END")
        self.msDMO.PressAndReleaseKey("END")
        self.Gtwy.SetMonitor("Receive only", async = True)
        self.msDMO.SetConfig("Gateway")
        self.Gtwy.wait()

        self.msDMO.VerifyDMOIdle(self.DTG)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.wait()

#     @launch_during_rerun_if_any_test_failed
#     def test_000_setup(self):
#         self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
#         self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
#         self.msDMO.CommitCp()
# 
#     @launch_during_rerun_if_any_test_failed
#     def test_999_teardown(self):
#         self.msDMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
#         self.msDMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
#         self.msDMO.CommitCp()

    def sendStatus(self, srcMs):
        srcMs.PressAndHoldKey("4")
        srcMs.IsTextOnScreen("Status Sent")
        sleep(2)
        srcMs.ReleaseKey("4")

    def verify_number_of_messages_is_in_range(self, ms, acceptable_range):
        try:
            ms.PressAndReleaseKey("END")
            ms.VerifyNumberOfMsgInInbox(max(acceptable_range))
        except RCException as rcErr:
            num_of_msgs_in_inbox = sum((int(x) for x in re.search("Inbox\|(\d+)/(\d+)", rcErr.rc_status_message).groups()))
            if num_of_msgs_in_inbox not in acceptable_range:
                raise RCException("Number of messages in Inbox ({})out of acceptable range ({})".format(num_of_msgs_in_inbox, str(acceptable_range)),
                                  rcErr.rc_return_value,
                                  rcErr.rc_status_message)

    def clear_inbox_for(self, mses):
        for ms in mses:
            ms.ClearInbox(async = True)
        for ms in mses:
            ms.wait()


    def verify_if_gtwy_is_not_bricked(self):
        self.Gtwy.ChangeTG(self.DTG, async = True)
        self.msDMO.ChangeTG(self.DTG)
        self.Gtwy.wait()
        sleep(10)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, self.DTG)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.VerifyDMOIdle(self.DTG)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)

        self.msDMO.MakeGC(self.DTG)
        sleep(5)
        self.msDMO.VerifyOngoingGC(self.DTG)       
        self.msTMO.VerifyIncomingGC(self.Gtwy, self.tmo_tg)

        self.msDMO.ReleasePTT()


    @ensure_frodo_will_act_as_gtwy
    def test_001_send_TMO_group_status_via_gtwy(self):
        self.gw_sync()

        talkgroups = ["TG1", "TG2"]

        for tg in talkgroups:

            self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

            self.msTMO.ChangeTG(tg, async = True)
            self.Gtwy.ChangeTG(tg)
            self.msTMO.wait()
            sleep(10)
            self.msTMO.VerifyDMOIdle(tg)
            self.msTMO.VerifyIcon("TOWER", "TOWER_ON", 30000)
            self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

            num_of_repeats = 5
            for repeat in range(1, num_of_repeats+1):
                self.logger.info("Sending status {}/{}".format(repeat, num_of_repeats))
                self.msTMO.PressAndReleaseKey("END")
                self.sendStatus(self.msTMO)
                sleep(10)

            self.msDMO.PressAndReleaseKey("END")
            self.msDMO.VerifyNumberOfMsgInInbox(num_of_repeats)

    # GW_SDS_DMO_TMO_T_002: Target test. Modification of [GW_SDS_DMO_TMO_T_001]. Send 100 SDSes. Lowest FCD = 2. Lowest Repeats = 1
    @ensure_frodo_will_act_as_gtwy
    def test_002_send_dmo_group_sds_via_gtwy_stress_test(self):

        self.msTMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msTMO.CommitCp()

        self.gw_sync()

        num_of_repeats = 100
        for repeat in range(1, num_of_repeats+1):
            self.logger.info("Sending status {}/{}".format(repeat, num_of_repeats))
            self.msTMO.PressAndReleaseKey("END")
            self.sendStatus(self.msTMO)
            sleep(5)

        acceptable_range = range(75, 100+1)
        self.verify_number_of_messages_is_in_range(self.msDMO, acceptable_range)

        self.msTMO.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTMO.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTMO.CommitCp()

    # GW_SDS_DMO_TMO_T_003
    # GW_SDS_DMO_TMO_T_005
    @ensure_frodo_will_act_as_gtwy
    # tutaj cos zmienic !!!!
    def test_003_send_tmo_private_sds_via_gtwy(self):
        self.gw_sync()

        outgoing_security_class = {"clear" : 0, 
                                   "2a" : 2,
                                   "2b" : 3,
                                   "2c" : 1}

        for (sec_label, cp_sec_val) in outgoing_security_class.items():
            self.msDMO.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', cp_sec_val)
            self.msDMO.CommitCp()

            self.clear_inbox_for([self.Gtwy, self.msDMO, self.msTMO])

            num_of_repeats = 5
            for repeat in range(1, num_of_repeats+1):
                self.logger.info("Sending SDS {}/{} using SC {}".format(repeat, num_of_repeats, sec_label))
                self.msDMO.PressAndReleaseKey("END")
                self.sendPrivateSds(self.msDMO, self.msTMO)
                sleep(5)

            self.msTMO.PressAndReleaseKey("END")
            self.msTMO.VerifyNumberOfMsgInInbox(num_of_repeats)

        self.msDMO.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', outgoing_security_class["clear"])
        self.msDMO.CommitCp()

    # GW_SDS_DMO_TMO_T_007
    @ensure_frodo_will_act_as_gtwy
    def test_004_send_tmo_group_sds_via_gtwy_while_gtwy_is_attached_to_different_tmo_tg(self):
        self.gw_sync()

        tg1 = "DTG_H1_1"
        tg2 = "DTG_H2_1"

        self.Gtwy.ChangeTG(tg1)
        self.msDMO.ChangeTG(tg2)
        sleep(10)
        self.Gtwy.VerifyGWIdle(self.tmo_tg, tg1)
        self.Gtwy.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msDMO.VerifyDMOIdle(tg2)
        self.msDMO.VerifyIcon("TOWER", "TOWER_ON", 30000)

        self.msDMO.PressAndReleaseKey("END")
        self.msDMO.SendGroupSDSFromTemplate("vlong")
        sleep(20)

        self.msTMO.PressAndReleaseKey("END")
        self.msTMO.VerifyNumberOfMsgInInbox(0)

        self.verify_if_gtwy_is_not_bricked()


    # GW_SDS_DMO_TMO_T_014
    #zmienic send status private !!!!
    def test_005_send_tmo_private_status_via_gtwy_to_gtwy(self):
        self.gw_sync()

        self.sendPrivateSds(self.msDMO, self.Gtwy)
        sleep(15)

        self.Gtwy.PressAndReleaseKey("END")
        self.Gtwy.VerifyNumberOfMsgInInbox(1)
        sleep(5)

        self.verify_if_gtwy_is_not_bricked()
      

    # GW_SDS_DMO_TMO_T_015
    def test_008_send_dmo_group_sds_using_msms_mode_to_gtwy(self):
        self.gw_sync()

        self.msDMO.SetConfig("MS - MS")
        #self.sendPrivateSds(self.msDMO, self.Gtwy)
        self.msDMO.SendGroupSDSFromTemplate("vlong")
        sleep(15)

        self.Gtwy.PressAndReleaseKey("END")
        self.Gtwy.VerifyNumberOfMsgInInbox(0)
        sleep(5)

        self.msDMO.SetConfig("Gateway")
        self.verify_if_gtwy_is_not_bricked()

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(Gateway_SDSes_statuses_from_DMO)
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)                     
