from ms import create_ms
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class Ms1TxMs2Rx(MotTestCase):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms2", msAlien_cfg = "ms3", tg = "DTG_H1_2C", tg_alien = "DTG_H2_2C", tg_clean = "DTG_H1_1"):
        super(Ms1TxMs2Rx, self).__init__(testname)
        self.msTX_cfg = msTX_cfg
        self.msRX_cfg = msRX_cfg
        self.msAlien_cfg = msAlien_cfg
        self.tg = tg
        self.tg_alien = tg_alien
        self.tg_clean = tg_clean

    def setUp(self):
        self.msTX = create_ms(self.msTX_cfg)
        self.msRX = create_ms(self.msRX_cfg)
        self.msAlien = create_ms(self.msAlien_cfg)

    def tearDown(self):
        self.msTX.destroy()
        self.msRX.destroy()   
        self.msAlien.destroy()
        
    def connectDMO(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msAlien.Connect()
        self.msTX.wait()
        self.msRX.wait()
        
        self.msTX.EnterDMO(async = True)
        self.msRX.EnterDMO(async = True)
        self.msAlien.EnterDMO()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.ChangeTG(self.tg, async = True)
        self.msRX.ChangeTG(self.tg, async = True)
        self.msAlien.ChangeTG(self.tg_alien)
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.ClearInbox(async = True)
        self.msRX.ClearInbox(async = True)
        self.msAlien.ClearInbox()
        self.msTX.wait()
        self.msRX.wait()

    def sendStatus(self, srcMs):
        srcMs.PressAndHoldKey("4")
        srcMs.IsTextOnScreen("Status Sent")
        sleep(2)
        srcMs.ReleaseKey("4")

    @launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.msTX.Connect(async = True)
        self.msAlien.Connect()
        self.msTX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1, async = True)
        self.msAlien.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)
        self.msTX.wait()

        self.msTX.CommitCp(async = True)
        self.msAlien.CommitCp()
        self.msTX.wait()

    @launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msAlien.Connect()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0, async = True)
        self.msRX.SetCpValue('cp_all_t.cp_dll_block.dll_data.dev_and_test[31]', 0, async = True)
        self.msAlien.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.CommitCp(async = True)
        self.msRX.CommitCp(async = True)
        self.msAlien.CommitCp()
        self.msTX.wait()
        self.msRX.wait()

    # TX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_in_IDLE_40T_41
    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_in_IDLE_40T_41
    def test_001_send_and_receive_status_in_idle(self):
        self.connectDMO()

        self.sendStatus(self.msTX)

        sleep(2)
        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

    # http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_emergency_in_IDLE_40T_41
    # http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_emergency_in_IDLE_40T_41
    def test_002_send_and_receive_alarm_status_for_egc_started_in_idle(self):
        self.connectDMO()

        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        sleep(1)
        self.msTX.ExitEmergencyMode()

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

    # TX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_in_OCCUPATION_40T_41
    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_in_OCCUPATION_40T_41
    def test_003_send_and_receive_alarm_status_for_egc_preemption_in_occupation(self):
        self.connectDMO()

        self.msRX.MakeGC(self.tg)
        sleep(1)
        self.msTX.VerifyIncomingGC(self.msRX, self.tg)
        self.msRX.VerifyOngoingGC(self.tg)       

        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        self.msTX.ExitEmergencyMode()
        self.msRX.ReleasePTT()

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

    # TX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_in_RESERVATION_40T_41
    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_in_RESERVATION_40T_41
    def test_004_send_and_receive_alarm_status_for_egc_preemption_in_reservation(self):
        self.connectDMO()

        self.msRX.MakeGC(self.tg)
        sleep(1)
        self.msTX.VerifyIncomingGC(self.msRX, self.tg)
        self.msRX.VerifyOngoingGC(self.tg)       
        self.msRX.ReleasePTT()
        sleep(2)

        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        self.msTX.ExitEmergencyMode()

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

    # TX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_of_alien_call_in_OCCUPATION_40T_41
    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_of_alien_call_in_OCCUPATION_40T_41
    def test_005_send_and_receive_alarm_status_for_egc_preemption_of_alien_call_in_occupation(self):
        self.connectDMO()

        self.msAlien.MakeGC(self.tg_alien)
        sleep(1)
        self.msAlien.VerifyOngoingGC(self.tg_alien)
        sleep(2)

        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        self.msTX.ExitEmergencyMode()
        self.msAlien.ReleasePTT()
        sleep(2)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

    # TX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusTx#Sending_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_of_alien_call_in_RESERVATION_40T_41
    # RX TC: http://tetrawiki.mot-solutions.com/twiki/bin/view/MSSW/ConfTestPlanForDllScStatusRx#Reception_of_status_accompanying_EGC_40status_sent_before_call_setup_41_after_preemption_of_alien_call_in_RESERVATION_40T_41
    def test_006_send_and_receive_alarm_status_for_egc_preemption_of_alien_call_in_reservation(self):
        self.connectDMO()

        self.msAlien.MakeGC(self.tg_alien)
        sleep(1)
        self.msAlien.VerifyOngoingGC(self.tg_alien)
        self.msAlien.ReleasePTT()
        sleep(2)

        self.msTX.EnterEmergencyMode()
        self.msTX.IsTextOnScreen("Alarm Sent")
        self.msTX.ExitEmergencyMode()
        sleep(2)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(1)

class Ms1RxMs2Tx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms2", msRX_cfg = "ms1", msAlien_cfg = "ms3", tg = "DTG_H1_2C", tg_alien = "DTG_H2_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msAlien_cfg)

class Ms3RxMs1Tx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms3", msAlien_cfg = "ms2", tg = "DTG_H1_2C", tg_alien = "DTG_H2_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msAlien_cfg)

class Ms3TxMs1Rx(Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms3", msRX_cfg = "ms1", msAlien_cfg = "ms2", tg = "DTG_H1_2C", tg_alien = "DTG_H2_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msAlien_cfg)        
        

if __name__ == "__main__":
    suite = unittest.TestSuite([unittest.TestLoader().loadTestsFromTestCase(Ms1TxMs2Rx),
                                unittest.TestLoader().loadTestsFromTestCase(Ms1RxMs2Tx)])
    unittest.TextTestRunner(verbosity=2).run(suite)                     
