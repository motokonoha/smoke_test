__author__ = 'THCQ86'

import unittest
from time import sleep as real_sleep, localtime, strftime

from ms import create_ms
from mot_test import MotTestCase


def sleep(duration):
    print("%s sleep(%s)" % (strftime("%H:%M:%S", localtime()), duration))
    real_sleep(duration)


gw_rssi_threshold = 'cp_all_t.cp_dll_block.dll_data.dm_gw.gw_rssi_threshold'
rep_rssi_threshold = 'cp_all_t.cp_dll_block.dll_data.dm_rep.rep_rssi_threshold'
ms_ms_rssi_threshold = 'cp_all_t.cp_dll_block.dll_data.ms_ms_rssi_threshold'
via_gw_rep_rssi_threshold = 'cp_all_t.cp_dll_block.dll_data.via_gw_rep_rssi_threshold'
dt254_path = 'cp_all_t.cp_dll_block.dll_data.dm_rep.dt254'
dt264_path = 'cp_all_t.cp_dll_block.dll_data.dm_gw.dt264'
cp44_path = 'cp_all_t.cp_dll_block.dll_data.gw_rep_presence_timeout'

class GW_Improvements(MotTestCase):
    def __init__(self, testname, ms1_cfg="ms1", ms2_cfg="ms2", ms3_cfg="ms3", DTG="DTG_H1_1",
                 Alien_DTG="DTG_I1_1"):
        super(GW_Improvements, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 2
        self.DTG = DTG
        self.Alien_DTG = Alien_DTG
        self.rssi_threshold = 100
        self.rssi_off = -200
        self.dt254 = 20
        self.dt264 = 20
        self.cp44 = 2

    def calculate_rep_desync_time(self):
        rsl = (self.cp44 + 1) * self.dt254
        print("Expected desync_time: %s" % rsl)

        return rsl

    def calculate_gw_desync_time(self):
        rsl = (self.cp44 + 1) * self.dt264
        print("Expected desync_time: %s" % rsl)

        return rsl

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()

    def test_001_unsync_preparation(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()

        self.ms1.wait()
        self.ms2.wait()

        self.ms1.SetCpValue(dt264_path, 5)
        self.ms2.SetCpValue(dt254_path, 4)
        self.ms2.SetCpValue(cp44_path, 2)
        self.ms1.SetCpValue(cp44_path, 0)
        self.ms3.SetCpValue(cp44_path, 3)
        self.ms1.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 6)
        self.ms2.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 6)
        self.ms3.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 6)

        self.ms1.CommitCp(async=True)
        self.ms2.CommitCp(async=True)
        self.ms3.CommitCp()

        self.ms1.wait()
        self.ms2.wait()
        
    def test_002_gw_alien_and_txi_standby(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        sleep(5)

        self.DTG = "DTG_H1_2A"
        self.Alien_DTG = "DTG_I1_2A"

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.Alien_DTG)
        self.ms1.wait()

        self.ms2.SetConfig("MS - MS")

        self.ms1.EnterGW()
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        self.ms2.HoldPTT()
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        self.ms1.EnterTXI()
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        self.ms1.ExitTXI()
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        self.ms2.ReleasePTT()
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

    def test_003_gw_standby_sds(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO(async=True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        sleep(5)

        self.DTG = "DTG_H1_2C"
        self.Alien_DTG = "DTG_I1_2C"

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.Alien_DTG, async=True)
        self.ms3.ChangeTG(self.Alien_DTG)
        self.ms1.wait()
        self.ms2.wait()

        self.ms2.SetConfig("MS - MS", async=True)
        self.ms3.SetConfig("MS - MS")
        self.ms2.wait()

        self.ms1.EnterGW()
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        self.ms3.ClearInbox()
        self.ms2.PowerOff(async=True)
        self.ms3.PowerOff()
        self.ms2.wait()
        self.ms2.PowerOn(async=True)
        self.ms3.PowerOn()
        self.ms2.wait()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.ms2.PressAndReleaseKey("MENU")
        self.ms2.SelectMenuItem("Messages")
        sleep(0.5)
        self.ms2.SelectMenuItem("Templates")
        sleep(0.5)
        self.ms2.SelectMenuItem("long")
        sleep(0.5)
        self.ms2.SelectMenuItem("Group")
        sleep(0.5)
        self.ms2.PressAndReleaseKey("SK1")
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000, async=True)
        self.ms3.IsTextOnScreen("1 New Message", async=True)

        self.ms1.wait()
        self.ms3.wait()

        self.ms2.PressAndReleaseKey("END")
        self.ms3.PressAndReleaseKey("END")

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

    def test_004_unsync_end_on_occupation(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        sleep(5)

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.Alien_DTG)
        self.ms1.wait()

        self.ms2.SetConfig("MS - MS")

        self.ms1.EnterGW()
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        for i in range(3):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms2.PowerOff()
            self.ms2.PowerOn()
            self.ms2.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(3)
            self.ms2.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_005_unsync_end_on_reservation(self):
        self.ms1.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        sleep(5)

        self.DTG = "DTG_H1_2A"
        self.Alien_DTG = "DTG_I1_2A"

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms3.ChangeTG(self.Alien_DTG)
        self.ms1.wait()

        self.ms3.SetConfig("MS - MS")

        self.ms1.EnterGW()
        sleep(5)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)

        for i in range(3):
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            self.ms3.PowerOff()
            self.ms3.PowerOn()
            self.ms3.HoldPTT()
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
            sleep(3)
            self.ms3.ReleasePTT()
            sleep(1)
            self.ms3.PressAndReleaseKey("END")
            self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
            sleep(3)

    def test_006_prolonged_gw_n_x_dt264(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO(async=True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()

        self.DTG = "DTG_H1_2B"
        self.Alien_DTG = "DTG_I1_2B"

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.DTG, async=True)
        self.ms3.ChangeTG(self.DTG)
        self.ms1.wait()
        self.ms2.wait()

        self.ms2.SetConfig("Gateway", async=True)
        self.ms3.SetConfig("Gateway")
        self.ms2.wait()

        self.ms1.EnterGW()
        self.dt264 = 20
        self.cp44 = 2
        desync_time = self.calculate_gw_desync_time()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000, async=True)
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000)
        self.ms1.wait()

        self.ms3.HoldPTT()
        sleep(5)
        self.ms3.ReleasePTT()
        self.ms1.EnterDMO()

        sleep(desync_time - self.dt264)
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 5000)
        sleep(self.dt264)
        self.ms2.VerifyIcon("TOWER", "TOWER_BLINK", 5000)

    def test_007_prolonged_gw_60mf(self):
        self.ms1.Connect(async=True)
        self.ms3.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms3.EnterDMO()
        self.ms1.wait()

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms3.ChangeTG(self.DTG)
        self.ms1.wait()

        self.ms3.SetConfig("Gateway")

        self.dt264 = 20
        self.cp44 = 3

        self.ms1.EnterGW()

        desync_time = self.calculate_gw_desync_time()

        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000, async=True)
        self.ms3.VerifyIcon("TOWER", "TOWER_ON", 30000)
        self.ms1.wait()

        self.ms1.EnterDMO()

        sleep(60 - self.dt264)
        self.ms3.VerifyIcon("TOWER", "TOWER_ON", 5000)
        sleep(self.dt264)
        self.ms3.VerifyIcon("TOWER", "TOWER_BLINK", 5000)

    def test_008_prolonged_rep_n_x_dt254(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect()
        self.ms1.wait()

        self.ms1.EnterDMO(async=True)
        self.ms2.EnterDMO()
        self.ms1.wait()

        self.DTG = "DTG_H1_2C"
        self.Alien_DTG = "DTG_I1_2C"

        self.ms1.ChangeTG(self.DTG, async=True)
        self.ms2.ChangeTG(self.DTG)
        self.ms1.wait()

        self.ms1.SetConfig("Repeater")
        self.dt254 = 15
        self.cp44 = 0

        self.ms2.EnterREP()

        desync_time = self.calculate_rep_desync_time()

        self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000, async=True)
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        self.ms2.wait()

        self.ms2.EnterDMO()

        sleep(desync_time - self.dt254)
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 5000)
        sleep(self.dt254)
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_BLINK", 5000)

    # def test_009_rssi_preparation(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetCpValue(gw_rssi_threshold, self.rssi_threshold)
    #     self.ms1.SetCpValue(rep_rssi_threshold, self.rssi_threshold)
    #     self.ms2.SetCpValue(rep_rssi_threshold, self.rssi_threshold)
    #     self.ms3.SetCpValue(rep_rssi_threshold, self.rssi_threshold)
    #     self.ms1.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_threshold)
    #     self.ms2.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_threshold)
    #     self.ms3.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_threshold)
    #     self.ms1.SetCpValue(ms_ms_rssi_threshold, self.rssi_threshold)
    #     self.ms2.SetCpValue(ms_ms_rssi_threshold, self.rssi_threshold)
    #     self.ms3.SetCpValue(ms_ms_rssi_threshold, self.rssi_threshold)
    #
    #     self.ms1.CommitCp(async=True)
    #     self.ms2.CommitCp(async=True)
    #     self.ms3.CommitCp()
    #
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    # def test_010_ms_ms_private_call_changeovers(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.DTG = "DTG_H1_2C"
    #     self.Alien_DTG = "DTG_I1_2C"
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.DTG, async=True)
    #     self.ms3.ChangeTG(self.DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterNumber(self.ms3.issi)
    #     self.ms1.HoldPTT()
    #     sleep(2)
    #     self.ms2.MakeGC(self.DTG)
    #
    #     self.ms2.ReleasePTT()
    #     self.ms1.ReleasePTT()
    #
    #     self.ms3.HoldPTT()
    #     sleep(1)
    #     self.ms2.MakeGC(self.DTG)
    #
    #     self.ms2.ReleasePTT()
    #     self.ms3.ReleasePTT()
    #
    # def test_011_ms_ms_different_group_preemption(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms3.ChangeTG(self.Alien_DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms2.HoldPTT()
    #     sleep(2)
    #     self.ms1.MakeGC(self.DTG)
    #
    #     self.ms1.ReleasePTT()
    #     self.ms2.ReleasePTT()
    #
    #     self.ms2.EnterEmergencyMode()
    #     self.ms2.HoldPTT()
    #     sleep(1)
    #     self.ms1.MakeGC(self.DTG)
    #
    #     self.ms1.ReleasePTT()
    #     self.ms2.ReleasePTT()
    #     self.ms2.ExitEmergencyMode()
    #
    # def test_012_rep_sds_group(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.DTG = "DTG_H1_2B"
    #     self.Alien_DTG = "DTG_I1_2B"
    #
    #     self.ms1.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms2.ChangeTG(self.DTG, async=True)
    #     self.ms3.ChangeTG(self.DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("Repeater", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms3.EnterREP()
    #     sleep(5)
    #
    #     self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
    #
    #     self.ms1.PressAndReleaseKey("MENU")
    #     self.ms1.SelectMenuItem("Messages")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("Templates")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("long")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("Group")
    #     sleep(0.5)
    #     self.ms1.PressAndReleaseKey("SK1")
    #
    #     self.ms2.MakeGC(self.DTG, async=True)
    #     self.ms2.wait()
    #     self.ms1.PressAndReleaseKey("END")
    #
    # def test_013_gw_group_call(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms3.ChangeTG(self.DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("Gateway")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterGW()
    #     sleep(5)
    #
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #     self.ms3.VerifyIcon("TOWER", "TOWER_ON", 30000)
    #
    #     self.ms2.HoldPTT()
    #     sleep(2)
    #     self.ms3.MakeGC(self.DTG)
    #
    #     self.ms3.ReleasePTT()
    #     self.ms2.ReleasePTT()
    #
    # def test_014_gw_diff_group_alien_call(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.DTG = "DTG_H1_2C"
    #     self.Alien_DTG = "DTG_I1_2C"
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms3.ChangeTG(self.Alien_DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterGW()
    #     sleep(5)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #
    #     self.ms2.HoldPTT()
    #     sleep(5)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #     self.ms2.ReleasePTT()
    #
    # def test_015_gw_private_alien_sds(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.DTG, async=True)
    #     self.ms3.ChangeTG(self.DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterGW()
    #     sleep(5)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #
    #     self.ms2.PressAndReleaseKey("MENU")
    #     self.ms2.SelectMenuItem("Messages")
    #     sleep(0.5)
    #     self.ms2.SelectMenuItem("Templates")
    #     sleep(0.5)
    #     self.ms2.SelectMenuItem("long")
    #     sleep(0.5)
    #     self.ms2.SelectMenuItem("Private")
    #     sleep(0.5)
    #     self.ms2.EnterNumber(self.ms3.issi)
    #     self.ms2.PressAndReleaseKey("SK1")
    #     sleep(1)
    #
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #
    # def test_016_gw_call_via_rep(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("Repeater", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.DTG = "DTG_H1_2A"
    #     self.Alien_DTG = "DTG_I1_2A"
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms3.ChangeTG(self.Alien_DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterGW()
    #     sleep(5)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #     self.ms3.EnterREP()
    #     sleep(5)
    #     self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
    #
    #     self.ms2.HoldPTT()
    #     sleep(2)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #     self.ms2.ReleasePTT()
    #
    # def test_017_gw_diff_group_alien_call(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #     sleep(5)
    #
    #     self.DTG = "DTG_H1_2B"
    #     self.Alien_DTG = "DTG_I1_2B"
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms3.ChangeTG(self.Alien_DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms2.SetConfig("MS - MS", async=True)
    #     self.ms3.SetConfig("MS - MS")
    #     self.ms2.wait()
    #
    #     self.ms1.EnterREP()
    #     sleep(5)
    #     self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
    #
    #     self.ms2.HoldPTT()
    #     self.ms1.HoldPTT()
    #     self.ms1.VerifyOngoingGCasREP(self.DTG)
    #     self.ms2.ReleasePTT()
    #     self.ms1.ReleasePTT()
    #
    # def test_018_gw_private_alien_sds(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #     sleep(5)
    #
    #     self.DTG = "DTG_H1_2C"
    #     self.Alien_DTG = "DTG_I1_2C"
    #
    #     self.ms1.ChangeTG(self.DTG, async=True)
    #     self.ms2.ChangeTG(self.DTG, async=True)
    #     self.ms3.ChangeTG(self.DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.SetConfig("MS - MS", async=True)
    #     self.ms2.SetConfig("MS - MS")
    #     self.ms1.wait()
    #
    #     self.ms3.EnterREP()
    #     sleep(5)
    #     self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
    #
    #     self.ms1.PressAndReleaseKey("MENU")
    #     self.ms1.SelectMenuItem("Messages")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("Templates")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("long")
    #     sleep(0.5)
    #     self.ms1.SelectMenuItem("Private")
    #     sleep(0.5)
    #     self.ms1.EnterNumber(self.ms2.issi)
    #     self.ms1.PressAndReleaseKey("SK1")
    #
    #     self.ms3.HoldPTT()
    #     self.ms3.VerifyOngoingGCasREP(self.DTG)
    #     self.ms3.ReleasePTT()
    #
    # def test_019_rep_call_via_gw(self):
    #     self.ms1.Connect(async=True)
    #     self.ms2.Connect(async=True)
    #     self.ms3.Connect()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms1.EnterDMO(async=True)
    #     self.ms2.EnterDMO(async=True)
    #     self.ms3.EnterDMO()
    #     self.ms1.wait()
    #     self.ms2.wait()
    #     sleep(5)
    #
    #     self.ms1.ChangeTG(self.Alien_DTG, async=True)
    #     self.ms2.ChangeTG(self.DTG, async=True)
    #     self.ms3.ChangeTG(self.Alien_DTG)
    #     self.ms1.wait()
    #     self.ms2.wait()
    #
    #     self.ms3.SetConfig("Gateway")
    #
    #     self.ms1.EnterGW()
    #     sleep(5)
    #     self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
    #     self.ms2.EnterREP()
    #     sleep(5)
    #     self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
    #
    #     self.ms3.HoldPTT()
    #     self.ms1.VerifyIncomingGCasGW(self.ms3, self.Alien_DTG, "TG1")
    #     self.ms2.HoldPTT()
    #     self.ms2.VerifyOngoingGCasREP(self.DTG)
    #     self.ms3.ReleasePTT()
    #     self.ms2.ReleasePTT()

    def test_020_clear_codeplug(self):
        self.ms1.Connect(async=True)
        self.ms2.Connect(async=True)
        self.ms3.Connect()

        self.ms1.wait()
        self.ms2.wait()

        self.ms1.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 3)
        self.ms2.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 3)
        self.ms3.SetCpValue("cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def", 3)
        self.ms1.SetCpValue(gw_rssi_threshold, self.rssi_off)
        self.ms1.SetCpValue(rep_rssi_threshold, self.rssi_off)
        self.ms2.SetCpValue(rep_rssi_threshold, self.rssi_off)
        self.ms3.SetCpValue(rep_rssi_threshold, self.rssi_off)
        self.ms1.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_off)
        self.ms2.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_off)
        self.ms3.SetCpValue(via_gw_rep_rssi_threshold, self.rssi_off)
        self.ms1.SetCpValue(ms_ms_rssi_threshold, self.rssi_off)
        self.ms2.SetCpValue(ms_ms_rssi_threshold, self.rssi_off)
        self.ms3.SetCpValue(ms_ms_rssi_threshold, self.rssi_off)
        self.ms1.SetCpValue(dt264_path, 5)
        self.ms2.SetCpValue(dt254_path, 5)
        self.ms1.SetCpValue(cp44_path, 2)
        self.ms2.SetCpValue(cp44_path, 2)
        self.ms3.SetCpValue(cp44_path, 2)

        self.ms1.CommitCp(async=True)
        self.ms2.CommitCp(async=True)
        self.ms3.CommitCp()

        self.ms1.wait()
        self.ms2.wait()

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(GW_Improvements)
    suite = unittest.TestSuite([suite1])

    unittest.TextTestRunner(verbosity=2).run(suite)