from ms import create_ms
import unittest
import math
from time import sleep
from mot_test import MotTestCase

class ms1_FDPC(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2"):
        super(ms1_FDPC, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 5

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
    
    def connect(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
    
    def test_001_ms1_FDPC(self):
        self.connect()	
        for i in range(self.loop):
            self.ms1.MakeFDPC(self.ms2)
            self.ms2.AnswerFDPC(self.ms1)
            sleep(2)
            self.ms1.EndFDPC()
            self.ms2.IsTextOnScreen("Call Ended", 5)
    
    def test_002_ms1_starts_FDPC_preemption(self):
        self.connect()
        self.ms2.MakeFDPC(self.ms1)
        self.ms1.AnswerFDPC(self.ms2)
        self.ms1.EnterEmergencyMode()
        self.ms1.IsTextOnScreen("Alarm", 5)
        self.ms1.CheckOngoingEmergencyMicOn("TG1")
        self.ms2.CheckIncomingEmergencyCall(self.ms1, "TG1")
        self.ms1.HoldPTT()
        self.ms1.IsTextOnScreen("Emgcy Mic Ended")
        self.ms1.CheckOngoingEmergencyCall("TG1")
        self.ms2.CheckIncomingEmergencyCall(self.ms1, "TG1")
        self.ms1.ReleasePTT();
        self.ms1.ExitEmergencyMode()
        self.ms2.PressAndReleaseKey("END")

class ms2_FDPC(ms1_FDPC):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_FDPC, self).__init__(testname, ms1_cfg, ms2_cfg)
        
class ms3_FDPC(ms1_FDPC):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_FDPC, self).__init__(testname, ms1_cfg, ms2_cfg)        
if __name__ == "__main__":
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms2_FDPC)
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_FDPC)
    suite = unittest.TestSuite([suite1, suite2])
    unittest.TextTestRunner(verbosity=2).run(suite)            