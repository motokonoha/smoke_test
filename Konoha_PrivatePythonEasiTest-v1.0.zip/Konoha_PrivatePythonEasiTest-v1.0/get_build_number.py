import os, pickle, re, argparse

def get_build_baseline_from_configspec(config_spec):
    pattern = ".*[BDIR]\d{2}\.XXX\.(\d{4}.?)"
    if os.path.isfile(config_spec):
        with open(config_spec, "r") as f:
            for line in f:
                m = re.search(pattern, line)
                if m:
                    return m.group(1)

def load_history_file(filename):
    if os.path.isfile(filename):
        with open(filename, "rb") as f:
            return pickle.load(f)
    return []

def get_build_number_from_history(build_ver, history_file):
    history = load_history_file(history_file)
    last_time = 0.0
    last_ver = None
    for h in history:
        if h[0] == build_ver:
            if last_time < h[2]:
                last_time = h[2]
            last_ver = h[1]
    return last_ver
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cs", help="config_spec", type=str)
    parser.add_argument("-b", "--baseline", help="config_spec", type=str)
    parser.add_argument("-d", "--dump", help="artifacts history", type=str)
    arguments = parser.parse_args()
    baseline = None
    if arguments.cs:
        baseline = get_build_baseline_from_configspec(arguments.cs)
    if arguments.baseline:
        baseline = arguments.baseline
    if baseline:
        print("Found baseline:", baseline)
        build_ver = get_build_number_from_history(baseline, arguments.dump)
        if build_ver:
            print("Found build number:", build_ver)
            with open('properties.txt', 'w') as f:
                f.write("artifacts_build_number="+build_ver)
        else:
            raise Exception("Build numner wasn't found")
    else:
        raise Exception("Baseline wasn't found")

