from ms import create_ms
import unittest, xmlrunner
from time import sleep
from network_if import get_main_ipv4_address
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class TPCTests(MotTestCase):
    def __init__(self, testname, ms_cfg = "ms1"):
        super(TPCTests, self).__init__(testname)
        self.ms_cfg = ms_cfg
        self.result = None
        

    def check_result(self, result, max_time, perfect_time, size):
        if result == None:
            self.fail("Connection Error")
        transmission_time = float(result[1]) - float(result[0])
        print ("transmission time = " + str(transmission_time) + " data send = " + str(result[2]) + " data received = " + str(result[3]), " network fials = " + str(result[4]))
        if int(result[4]) != 0:
            self.fail("Network fails!")
        if int(result[3]) != size and int(result[2]) != size:
            self.fail("received/sent message size error")
        if transmission_time > max_time:
            print ("Too long transmission")
            return "Too long transmission"
        if transmission_time <= perfect_time:
            print ("Perfect transmission")
            self.time_rank[0] = int(self.time_rank[0])+ 1
        if transmission_time > perfect_time and transmission_time <= max_time:
            print("Good transmission")
            self.time_rank[1] = int(self.time_rank[1]) + 1
        return 0



    def check_time(self, number_of_good, number_of_perfect):
        print("Number of perfect transmissions = " + str(self.time_rank[0]))
        print("Number of good transmissions = " + str(self.time_rank[1]))
        if self.time_rank[0]+self.time_rank[1] < number_of_good or self.time_rank[0] < number_of_perfect:
            self.fail("Too few transmission with good or perfect time")
        return 0

    
    def setUp(self):
        self.time_rank = [0,0,0,0]
        self.ms = create_ms(self.ms_cfg)

    def tearDown(self):
        self.ms.destroy()
    
    @launch_during_rerun_if_any_test_failed
    def test_000_required(self):
        self.ms.Connect()
        self.ms.SetPDMode('QAM')
        self.ms.Disconnect()

    def test_001_Download20x100(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        for i in range(20):
            result = self.ms.ReceiveFileViaTPC(100000, 10)
            self.check_result(result, 11.00, 10.00, 100000)
        self.assertEqual(0, self.check_time(int(0.95*20), int(0.8*20)))
        self.ms.ClosePDConnection()
        self.ms.Disconnect()
        sleep(5)

    def test_002_Upload20x100(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        for i in range(20):
            result = self.ms.SendFileViaTPC(100000, 10)
            self.check_result(result, 11.00, 10.00, 100000)
        self.assertEqual(0, self.check_time(int(0.95*20), int(0.8*20)))
        self.ms.ClosePDConnection()
        self.ms.Disconnect()
        sleep(5)

    def test_004_Upload1MB(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        self.result = self.ms.SendFileViaTPC(1000000, 100)
        self.assertEqual(0, self.check_result(self.result, 110.00, 100.00, 1000000))
        self.ms.ClosePDConnection()
        self.ms.Disconnect()
        sleep(5)
        
    def test_003_Download1MB(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        self.result = self.ms.ReceiveFileViaTPC(1000000, 100)
        self.assertEqual(0, self.check_result(self.result, 110.00, 100.00, 1000000))
        self.ms.ClosePDConnection()
        self.ms.Disconnect()
        sleep(5)
        
    def test_005_Upload200kviaTFTP(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        self.result = self.ms.SendFileViaTFTP(204800, 105)
        self.assertEqual(0, self.result)
        self.ms.ClosePDConnection()
        sleep(5)
        
    def test_006_Download200kviaTFTP(self):
        self.ms.Connect()
        self.ms.SetPDConnection()
        sleep(5)
        self.result = self.ms.ReceiveFileViaTFTP(204800, 80)
        self.assertEqual(0, self.result)
        self.ms.ClosePDConnection()
        sleep(5)

    #~ def test_UploadLargedownloadSmall(self):
        #~ self.ms.Connect()
        #~ self.ms.EnterTMO()
        #~ self.ms.SetPDConnection()
        #~ sleep(5)
        #~ self.ms.SendFileViaTPC(1024000, 40, async = True)
        #~ for i in range(10):
            #~ resultSmall = self.ms.ReceiveFileViaTPC(100000, 20)
            #~ self.assertEqual(0, self.check_result(resultSmall, 11.00, 10.00, 100000))
        #~ resultBig = self.ms.wait()
        #~ self.assertEqual(0, self.check_result(resultBig, 11.00, 10.00, 100000))
        #~ self.ms.ClosePDConnection()
        #~ self.ms.Disconnect()
        #~ sleep(5)
        
#	def test_DownUpMS-MS(self)
        
        #self.ms1.Connect(async = True)
        #self.ms2.Connect(async = True)
        #self.ms1.wait()
        #self.ms2.wait()
        #self.ms1.Disconnect()
        #self.ms2.Disconnect()
        #self.ms1.wait()
        #self.ms2.wait()
        #self.ms1.SetPDConnection(async = True)
        #self.ms2.SetPDConnection(async = true)
        #self.ms1.wait()
        #self.ms2.wait()
        #sleep(5)
        #self.ms1.ReceiveFile(100000, self.ms2.port_udp, async = True)
        #sleep(1)
        #self.ms1.SendFile(100000, self.ms1.port_udp, async = True)
        #result1 = self.ms1.wait()
        #result2 = self.ms2.wait()
        #self.assertEqual(0, self.check_result(result1, 0.00, 0.00, 100000))
        #self.assertEqual(0, self.check_result(result2, 0.00, 0.00, 100000))
        #self.ms.ClosePDConnection(async = True)
        #self.ms.ClosePDConnection(async = True)
        #self.ms1.wait()
        #self.ms2.wait()