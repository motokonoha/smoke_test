from ms import create_ms, is_ms_patriot
import unittest, math, os
from time import sleep
from mot_test import MotTestCase

class ms1_Checklist(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2"):
        super(ms1_Checklist, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.loop = 2

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
    
    def connect(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        
    def repeater_sync(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterREP(async = True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        self.ms1.ChangeTG("DTG_H1_1", async = True)
        self.ms2.ChangeTG("DTG_H1_1")
        self.ms1.wait()
        self.ms1.VerifyREPIdle("DTG_H1_1", async = True)
        self.ms2.VerifyDMOIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive&Transmit", async = True)
        self.ms2.SetConfig("Repeater")
        self.ms1.wait()
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
        self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        
    def gw_sync(self, ms2_mode):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterTMO(async = True)
        if ms2_mode == "DMO":
            self.ms2.EnterDMO()
        else:
            self.ms2.EnterTMO()
        self.ms1.wait()
        self.ms1.ChangeTG("TG1", async = True)
        if ms2_mode == "DMO":
            self.ms2.ChangeTG("DTG_H1_1")
        else:
            self.ms2.ChangeTG("TG1")
        self.ms1.wait()
        self.ms1.EnterGW(async = True)
        if ms2_mode == "DMO":
            self.ms2.VerifyDMOIdle("DTG_H1_1")
        else:
            self.ms2.VerifyTMOIdle("TG1")
        self.ms1.wait()
        self.ms1.ChangeTG("DTG_H1_1")
        self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive only", async = True)
        if ms2_mode == "DMO":
            self.ms2.SetConfig("Gateway")
        self.ms1.wait()
        if ms2_mode == "DMO":
            self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000)
     
    def ms1_PCHD(self):
        sleep(1)  
        self.ms1.HoldPTT()
        sleep(2)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.ReleasePTT()
    
    def ms2_PCHD(self):
        sleep(1)
        self.ms2.HoldPTT()
        sleep(2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.IsPrivateCallOngoing(self.ms2)
        self.ms2.ReleasePTT()
    
    def ms1_GC(self):
        self.ms1.MakeGC('DTG_H1_1')
        sleep(1)
        self.ms2.VerifyIncomingGC(self.ms1, 'DTG_H1_1')
        self.ms2.VerifyOngoingGC('DTG_H1_1', async = True)       
        self.ms1.ReleasePTT()
        self.ms2.wait()
    
    def ms2_GC(self):
        self.ms2.MakeGC('DTG_H1_1')
        sleep(1)
        self.ms1.VerifyIncomingGC(self.ms2, 'DTG_H1_1')
        self.ms1.VerifyOngoingGC('DTG_H1_1', async = True)
        self.ms2.ReleasePTT()
        self.ms1.wait()    
        
    def connectDMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect()
        self.ms1.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO()
        self.ms1.wait()
        self.ms1.ChangeTG("DTG_H1_1", async = True)
        self.ms2.ChangeTG("DTG_H1_1")
        self.ms1.wait()    
    
    def atest_001_switching_between_DMO_TG(self):
        self.connectDMO()
        
        for i in range(self.loop):

            self.ms1.MakeGC('DTG_H1_1')
            self.ms2.VerifyIncomingGC(self.ms1, "DTG_H1_1",1)
            self.ms1.ReleasePTT()
            self.ms2.VerifyOngoingGC('DTG_H1_1')

            self.ms1.ChangeTG("DTG_H1_2A", async = True)
            self.ms2.ChangeTG("DTG_H1_2A")
            self.ms1.wait()

            self.ms2.MakeGC('DTG_H1_2A')
            self.ms1.VerifyIncomingGC(self.ms2,"DTG_H1_2A",1)
            self.ms2.ReleasePTT()
            self.ms1.VerifyOngoingGC('DTG_H1_2A')
            
            self.ms1.ChangeTG("DTG_H1_1", async = True)
            self.ms2.ChangeTG("DTG_H1_1")
            self.ms1.wait()
            
        
        
    def atest_002_ms1_HDPC_DMO(self):
        self.connectDMO()
        self.ms1.MakeHDPC_DMO(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms1)
        self.ms1.ReleasePTT()
        sleep(0.2)

        for i in range(self.loop*2):
            self.ms1_PCHD()
            self.ms2_PCHD()

        for i in range(self.loop):
            self.ms1_PCHD()

        for i in range(self.loop):
            self.ms2_PCHD()
    
    def atest_003_ms1_starts_GC_DMO(self):
        self.connectDMO()
        self.ms1.MakeGC('DTG_H1_1')
        self.ms2.VerifyIncomingGC(self.ms1, 'DTG_H1_1')
        self.ms1.ReleasePTT()

        for i in range(2*self.loop):
            self.ms1_GC()
            self.ms2_GC()
            

        for i in range(self.loop):
            self.ms1_GC()

        for i in range(self.loop):
            self.ms2_GC()

    def test_004_power_off_and_on_in_DMO(self):
        self.ms1.Connect()
        self.ms1.EnterDMO()
        self.ms1.ChangeTG("DTG_H1_1")
        self.ms1.PowerCycle()
        self.ms1.VerifyDMOIdle("DTG_H1_1")
        
    def test_005_ms1_goes_into_test_mode(self):
        self.ms1.Connect()
        self.ms1.EnterDMO()
        self.ms1.ChangeTG("DTG_H1_1")
        self.ms1.PowerOff()
        self.ms1.PowerOn()
        self.ms1.VerifyDMOIdle("DTG_H1_1")

    def test_006_ms1_at_commands(self):
        self.ms1.Connect()
        self.ms1.EnterTMO()
        self.ms1.SwitchToAT()
        self.ms1.at.Open()
        at_result = self.ms1.at.Send('at\r')
        self.ms1.at.Close()
        self.ms1.SwitchToIMT()
        self.assertNotEqual(at_result, None)

    def test_007_ms1_airtracer(self):
        self.ms1.Connect()
        self.ms1.EnterTMO()
        self.ms1.ChangeTG("TG1")
        self.ms1.VerifyTMOIdle("TG1")
        log = self.ms1.airtracer_file
        self.assertNotEqual(log, None)
        self.assertNotEqual(os.path.getsize(log), 0)
        
    def test_008_power_off_and_on_in_repeater_mode(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.ms1.Connect()
            self.ms1.EnterREP()
            self.ms1.ChangeTG("DTG_H1_1")
            self.ms1.VerifyREPIdle("DTG_H1_1")
            self.ms1.PowerCycle()
            self.ms1.VerifyREPIdle("DTG_H1_1")
        else:
            self.skipTest("Not supporting gateway feature")    
            
    def test_009_power_off_and_on_in_gateway_mode(self):
        gw_mode = self.ms1.IsGWMode()
        if gw_mode:
            self.ms1.Connect()
            self.ms1.EnterTMO()
            self.ms1.ChangeTG("TG1")
            self.ms1.EnterGW()
            self.ms1.ChangeTG("DTG_H1_1")
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms1.PowerCycle()
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1") 
        else:
            self.skipTest("Not supporting gateway feature")    
    
    def test_010_power_off_and_on_in_TMO(self):
        self.ms1.Connect()
        self.ms1.EnterTMO()
        self.ms1.ChangeTG("TG1")
        sleep(2)
        self.ms1.PowerCycle()
        self.ms1.VerifyTMOIdle("TG1")
       
    def test_011_crypto_registr(self):
        if self.ms1.isBSI():
            self.ms1.Connect()
            self.ms1.EnterTMO()
            self.ms1.ChangeTG("TG1")
            self.ms1.CryptoRegistr()
            self.ms1.VerifyTMOIdle("TG1")
        else:
            self.skipTest("Non BSI radio")
            
       
    def atest_012_makes_group_call_as_interactive_repeater_with_changeover(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.repeater_sync()
            self.ms1.MakeGCasREP("DTG_H1_1")
            self.ms2.VerifyIncomingGC(self.ms1, "DTG_H1_1")
            self.ms1.ReleasePTT()
            sleep(2)
            self.ms2.MakeGC("DTG_H1_1")
            self.ms1.VerifyIncomingGCasREP(self.ms2, "DTG_H1_1")
            self.ms2.ReleasePTT()
        else:
            self.skipTest("Not supporting gateway feature")    
            
    def atest_013_ms1_makes_group_call_via_ms2_repeater_with_changeover(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.repeater_sync()
            self.ms2.MakeGC("DTG_H1_1")
            self.ms1.VerifyIncomingGCasREP(self.ms2, "DTG_H1_1")
            self.ms2.ReleasePTT()
            sleep(1)
            self.ms1.MakeGCasREP("DTG_H1_1")
            self.ms2.VerifyIncomingGC(self.ms1, "DTG_H1_1")
            self.ms1.ReleasePTT()
        else:
            self.skipTest("Not supporting repeater feature")    
            
    def atest_014_ms2_in_DMO_makes_group_call_via_ms1_in_gateway_mode(self):
        gw_mode = self.ms1.IsGWMode()
        if gw_mode:
            self.gw_sync("DMO")
            self.ms2.MakeGC("DTG_H1_1")
            self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", "DTG_H1_1")
            self.ms2.ReleasePTT()
        else:
            self.skipTest("Not supporting gateway feature")    

    def atest_015_ms2_in_TMO_makes_group_call_via_ms1_in_gateway_mode(self):
        gw_mode = self.ms1.IsGWMode()
        if gw_mode:
            self.gw_sync("TMO")
            self.ms2.MakeGC("TG1")
            self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", "DTG_H1_1")
            self.ms2.ReleasePTT()
        else:
            self.skipTest("Not supporting gateway feature")
                
class ms2_Checklist(ms1_Checklist):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1"):
        super(ms2_Checklist, self).__init__(testname, ms1_cfg, ms2_cfg)      

class ms3_Checklist(ms1_Checklist):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1"):
        super(ms3_Checklist, self).__init__(testname, ms1_cfg, ms2_cfg)         
                
class ms1_ms2_ms3_Checklist(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3"):
        super(ms1_ms2_ms3_Checklist, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 2

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg, air_tracer = True)
        self.ms2 = create_ms(self.ms2_cfg, air_tracer = True)
        self.ms3 = create_ms(self.ms3_cfg, air_tracer = True)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()
    
    def connectTMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterTMO(async = True)
        self.ms3.EnterTMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG("TG1", async = True)
        self.ms3.ChangeTG("TG1")
        self.ms1.wait()
        self.ms2.wait()
        
    def connectDMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()       
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("DTG_H1_1", async = True)
        self.ms2.ChangeTG("DTG_H1_1", async = True)
        self.ms3.ChangeTG("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        
    def test_001_power_off_and_on_in_DMO(self):
        self.connectDMO()
        self.ms1.PowerCycle(async = True)
        self.ms2.PowerCycle(async = True)
        self.ms3.PowerCycle()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms2.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms3.VerifyDMOIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        
    def test_002_ms_goes_into_test_mode(self):
        self.connectDMO()
        self.ms1.PowerOff(async = True)
        self.ms2.PowerOff(async = True)
        self.ms3.PowerOff()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.PowerOn(async = True)
        self.ms2.PowerOn(async = True)
        self.ms3.PowerOn()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms2.VerifyDMOIdle("DTG_H1_1", async = True)
        self.ms3.VerifyDMOIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        
    def test_003_ms_at_commands(self):
        self.connectTMO()
        self.ms1.SwitchToAT(async = True)
        self.ms2.SwitchToAT(async = True)
        self.ms3.SwitchToAT()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.at.Open()
        self.ms2.at.Open()
        self.ms3.at.Open()
        at_result1 = self.ms1.at.Send('at\r')
        at_result2 = self.ms2.at.Send('at\r')
        at_result3 = self.ms3.at.Send('at\r')
        self.ms1.at.Close()
        self.ms2.at.Close()
        self.ms3.at.Close()
        self.ms1.SwitchToIMT(async = True)
        self.ms2.SwitchToIMT(async = True)
        self.ms3.SwitchToIMT()
        self.ms1.wait()
        self.ms2.wait()
        self.assertNotEqual(at_result1, None)
        self.assertNotEqual(at_result2, None)
        self.assertNotEqual(at_result3, None)

    def test_004_ms_airtracer(self):
        self.connectTMO()
        log1 = self.ms1.airtracer_file
        self.assertNotEqual(log1, None)
        self.assertNotEqual(os.path.getsize(log1), 0)
        log2 = self.ms2.airtracer_file
        self.assertNotEqual(log2, None)
        self.assertNotEqual(os.path.getsize(log2), 0)
        log3 = self.ms3.airtracer_file
        self.assertNotEqual(log3, None)
        self.assertNotEqual(os.path.getsize(log3), 0)

    def test_005_power_off_and_on_in_repeater_mode(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()       
        self.ms1.EnterREP(async = True)
        self.ms2.EnterREP(async = True)
        self.ms3.EnterREP()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("DTG_H1_1", async = True)
        self.ms2.ChangeTG("DTG_H1_1", async = True)
        self.ms3.ChangeTG("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyREPIdle("DTG_H1_1", async = True)
        self.ms2.VerifyREPIdle("DTG_H1_1", async = True)
        self.ms3.VerifyREPIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.PowerCycle(async = True)
        self.ms2.PowerCycle(async = True)
        self.ms3.PowerCycle()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyREPIdle("DTG_H1_1", async = True)
        self.ms2.VerifyREPIdle("DTG_H1_1", async = True)
        self.ms3.VerifyREPIdle("DTG_H1_1")
        self.ms1.wait()
        self.ms2.wait()

    def test_006_power_off_and_on_in_gateway_mode(self):
        gw_mode1 = self.ms1.IsGWMode()
        self.connectTMO()
        if gw_mode1:
            self.ms1.EnterGW()
            self.ms1.ChangeTG("DTG_H1_1")
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms1.PowerCycle()
            self.ms1.VerifyGWIdle("TG1", "DTG_H1_1")
        else:
            self.logger.info("Not supporting gateway feature for ms1")

        gw_mode2 = self.ms2.IsGWMode()
        if gw_mode2:
            self.ms2.EnterGW()
            self.ms2.ChangeTG("DTG_H1_1")
            self.ms2.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms2.PowerCycle()
            self.ms2.VerifyGWIdle("TG1", "DTG_H1_1")
        else:
            self.logger.info("Not supporting gateway feature for ms2")

        gw_mode3 = self.ms3.IsGWMode()
        if gw_mode3:
            self.ms3.EnterGW()
            self.ms3.ChangeTG("DTG_H1_1")
            self.ms3.VerifyGWIdle("TG1", "DTG_H1_1")
            self.ms3.PowerCycle()
            self.ms3.VerifyGWIdle("TG1", "DTG_H1_1") 
        else:
            self.logger.info("Not supporting gateway feature for ms3")
    
    def test_007_power_off_and_on_in_TMO(self):
        self.connectTMO()
        self.ms1.PowerCycle(async = True)
        self.ms2.PowerCycle(async = True)
        self.ms3.PowerCycle()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyTMOIdle("TG1", async = True)
        self.ms2.VerifyTMOIdle("TG1", async = True)
        self.ms3.VerifyTMOIdle("TG1")
        self.ms1.wait()
        self.ms2.wait()

    def test_008_crypto_registr(self):
        if self.ms1.isBSI():
            self.connectTMO()
            self.ms1.CryptoRegistr(async = True)
            self.ms2.CryptoRegistr(async = True)
            self.ms3.CryptoRegistr()
            self.ms1.wait()
            self.ms2.wait()
            self.ms1.VerifyTMOIdle("TG1", async = True)
            self.ms2.VerifyTMOIdle("TG1", async = True)
            self.ms3.VerifyTMOIdle("TG1")
            self.ms1.wait()
            self.ms2.wait()
        else:
            self.skipTest("Non BSI radios")

if __name__ == "__main__":
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms2_Checklist)
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_Checklist)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ms3_Checklist)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(ms1_ms2_ms3_Checklist)
    suite = unittest.TestSuite([suite4])
    #suite = unittest.TestSuite([suite1, suite2, suite3])
    unittest.TextTestRunner(verbosity=2).run(suite)                     