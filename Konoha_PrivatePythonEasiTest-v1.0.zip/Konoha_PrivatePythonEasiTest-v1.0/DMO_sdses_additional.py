from ms import create_ms, RCException
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class SDS_transmission_tests_Ms1TxMs2Rx(MotTestCase):
    def __init__(self, testname, msTX_cfg = "ms3", msRX_cfg = "ms2", msGW_cfg = "ms1", tg = "DTG_H1_1"):
        super().__init__(testname)
        self.msTX_cfg = msTX_cfg
        self.msRX_cfg = msRX_cfg
        self.msGW_cfg = msGW_cfg
        self.tg = tg

    def setUp(self):
        self.msTX = create_ms(self.msTX_cfg)
        self.msRX = create_ms(self.msRX_cfg)
        self.msGW = create_ms(self.msGW_cfg)

    def tearDown(self):
        self.msTX.destroy()
        self.msRX.destroy()
        self.msGW.destroy()

    def connectDMO(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msGW.Connect()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.EnterDMO(async = True)
        self.msRX.EnterDMO(async = True)
        self.msGW.EnterDMO()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.SetConfig("MS - MS", async = True)
        self.msRX.SetConfig("MS - MS", async = True)
        self.msTX.wait()
        self.msRX.wait()

        self.changeToTalkgroup([self.msTX, self.msRX, self.msGW], self.tg)

        self.msTX.ClearInbox(async = True)
        self.msRX.ClearInbox(async = True)
        self.msGW.ClearInbox()
        self.msTX.wait()
        self.msRX.wait()

    def gw_sync_dmo(self):
        self.msGW.Connect(async = True)
        self.msTX.Connect(async = True)
        self.msRX.Connect()
        self.msGW.wait()
        self.msTX.wait()
        self.msGW.EnterTMO(async = True)
        self.msTX.EnterDMO(async = True)
        self.msRX.EnterDMO()
        self.msGW.wait()
        self.msTX.wait()
        self.msGW.ChangeTG("TG1", async = True)
        self.msTX.ChangeTG(self.tg, async = True)
        self.msRX.ChangeTG(self.tg)
        self.msGW.wait()
        self.msTX.wait()
        self.msGW.EnterGW(async = True)
        self.msTX.VerifyDMOIdle(self.tg, async = True)
        self.msRX.VerifyDMOIdle(self.tg)
        self.msGW.wait()
        self.msTX.wait()
        self.msGW.ChangeTG(self.tg)
        self.msGW.VerifyGWIdle("TG1", self.tg)
        self.msGW.PressAndReleaseKey("END")
        self.msTX.PressAndReleaseKey("END")
        self.msGW.SetMonitor("Receive only", async = True)
        self.msTX.SetConfig("Gateway", async = True)
        self.msRX.SetConfig("Gateway")
        self.msGW.wait()
        self.msTX.wait()
        self.msTX.VerifyDMOIdle(self.tg, async = True)
        self.msRX.VerifyDMOIdle(self.tg)
        self.msTX.wait()
        self.msTX.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.msRX.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.msGW.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msTX.wait()
        self.msRX.wait()
        sleep(3)

    @launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.msTX.Connect(async = True)
        self.msGW.Connect()
        self.msTX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msGW.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)

        self.msTX.CommitCp(async = True)
        self.msGW.CommitCp()
        self.msTX.wait()

    @launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msGW.Connect()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', 0)
        self.msRX.SetCpValue('cp_all_t.cp_dll_block.dll_data.dev_and_test[31]', 0)
        self.msGW.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)

        self.msTX.CommitCp(async = True)
        self.msRX.CommitCp(async = True)
        self.msGW.CommitCp()
        self.msTX.wait()
        self.msRX.wait()

    def sendGroupSds(self, srcMs):
        srcMs.SendGroupSDSFromTemplate("vlong")
        sleep(2)

    def sendPrivateSds(self, srcMs, dstMs):
        srcMs.SendPrivSDSFromTemplate(dstMs, "vlong")

    def changeToTalkgroup(self, msesList, tg):
        for ms in msesList:
            ms.ChangeTG(tg, async = True)
        for ms in msesList:
            ms.wait()

    def test_001_send_and_receive_group_sds_in_idle(self):
        self.connectDMO()
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.CommitCp()
        mses = [self.msTX, self.msRX]
        num_of_sdses = 10
        talkgroups = [
            "DTG_H1_1",
            "DTG_H1_2A",
            "DTG_H1_2B",
            "DTG_H1_2C",
            "DTG_OG"
        ]

        for tg in talkgroups:
            self.changeToTalkgroup(mses, tg)

            for i in range(0, num_of_sdses):
                self.sendGroupSds(self.msTX)

            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
            self.msRX.ClearInbox()

    def test_002_send_and_receive_group_sds_to_not_attached_tg(self):
        self.connectDMO()
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.CommitCp()
        num_of_sdses = 10
        self.msTX.ChangeTG("DTG_H1_1")
        self.msRX.ChangeTG("DTG_OG")

        for i in range(0, num_of_sdses):
            self.sendGroupSds(self.msTX)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        self.msRX.ClearInbox()	


    def test_003_send_and_receive_100_group_sds_in_idle(self):
        self.connectDMO()
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msTX.CommitCp()
        num_of_sdses = 30
        mses = [self.msTX, self.msRX]

        talkgroups = [
            "DTG_H1_1",
            "DTG_H1_2A"
        ]

        for tg in talkgroups:
            self.changeToTalkgroup(mses, "DTG_H1_1")

        for i in range(0, num_of_sdses):
            self.sendGroupSds(self.msTX)


        try:
            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        except RCException as rcErr:
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses-1)

        self.msRX.ClearInbox()


    def test_004_send_and_receive_10_private_sds_in_idle(self):
        self.connectDMO()
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.CommitCp()
        num_of_sdses = 10
        outgoing_security_class = {"clear" : 0,
                                  "2a" : 2,
                                   "2b" : 3,
                                   "2c" : 1}

        for cp_sec_val in outgoing_security_class.values():
            self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', cp_sec_val)
            self.msTX.CommitCp()

        for i in range(0, num_of_sdses):
            self.sendPrivateSds(self.msTX, self.msRX)
            self.msTX.IsTextOnScreen("Message Delivered")
            self.msRX.PressAndReleaseKey("END")

        self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        self.msRX.ClearInbox()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', outgoing_security_class["clear"])
        self.msTX.CommitCp()


    def test_005_send_and_receive_100_private_sds_in_idle(self):
        self.connectDMO()
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msTX.CommitCp()


        num_of_sdses = 100
        for i in range(0, num_of_sdses):
            self.sendPrivateSds(self.msTX, self.msRX)

        try:
            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        except RCException as rcErr:
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses-1)

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.CommitCp()


        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        self.msRX.ClearInbox()

    def test_006_gw_receives_group_sds_from_dmo(self):
        self.gw_sync_dmo()
        for i in range(0,10):
            self.sendGroupSds(self.msTX)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(10)
        self.msRX.ClearInbox()

        self.msGW.PressAndReleaseKey("END")
        self.msGW.VerifyNumberOfMsgInInbox(10)
        self.msGW.ClearInbox()

class SDS_transmission_tests_Ms1RxMs2Tx(SDS_transmission_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms3", msRX_cfg = "ms2", msGW_cfg = "ms1", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msGW_cfg)

class SDS_transmission_tests_Ms3RxMs1Tx(SDS_transmission_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "msGW", msRX_cfg = "msTX", msGW_cfg = "ms2", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msGW_cfg)

class SDS_transmission_tests_Ms3TxMs1Rx(SDS_transmission_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "msTX", msRX_cfg = "msGW", msGW_cfg = "ms2", tg = "DTG_H1_2C"):
       super().__init__(testname, msTX_cfg, msRX_cfg, msGW_cfg)

if __name__ == "__main__":
    suite = unittest.TestSuite([unittest.TestLoader().loadTestsFromTestCase(SDS_transmission_tests_Ms1TxMs2Rx),
                                unittest.TestLoader().loadTestsFromTestCase(SDS_transmission_tests_Ms1RxMs2Tx)
    ])
    unittest.TextTestRunner(verbosity=2).run(suite)
