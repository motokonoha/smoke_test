from ms import create_ms
import unittest
import math
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class ms1_Repeater(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_1" ):
        super(ms1_Repeater, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 5
        self.TG = TG

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()
    
    def connect_repeater_sync(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterDMO()
        self.ms1.EnterREP(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.TG, async = True)
        self.ms2.ChangeTG(self.TG, async = True)
        self.ms3.ChangeTG(self.TG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyREPIdle(self.TG, async = True)
        self.ms2.VerifyDMOIdle(self.TG, async = True)
        self.ms3.VerifyDMOIdle(self.TG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms3.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive&Transmit", async = True)
        self.ms2.SetConfig("Repeater", async = True)
        self.ms3.SetConfig("Repeater")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
        self.ms2.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
    
    def ms2_GC_via_ms1_Repeater(self, TG):
        self.ms2.MakeGC(TG)
        sleep(1)
        self.ms1.VerifyIncomingGCasREP(self.ms2, TG)
        self.ms3.VerifyIncomingGC(self.ms2, TG)
        self.ms1.VerifyOngoingGCasREP(TG, async = True)
        self.ms3.VerifyOngoingGC(TG, async = True)               
        self.ms2.ReleasePTT()
        self.ms1.wait()
        self.ms3.wait()
        
    
    def ms3_GC_via_ms1_Repeater(self, TG):
        self.ms3.MakeGC(TG)
        sleep(1)
        self.ms1.VerifyIncomingGCasREP(self.ms3, TG)
        self.ms2.VerifyIncomingGC(self.ms3, TG)
        self.ms1.VerifyOngoingGCasREP(TG, async = True)
        self.ms2.VerifyOngoingGC(TG, async = True)               
        self.ms3.ReleasePTT()
        self.ms1.wait()
        self.ms2.wait()

    def ms2_HDPC_via_ms1_Repeater(self):
        sleep(1)  
        self.ms2.HoldPTT()
        sleep(2)
        self.ms1.VerifyOngoingPCasREP(self.ms2, self.ms3)
        self.ms2.IsPrivateCallOngoing(self.ms3)
        self.ms3.IsPrivateCallOngoing(self.ms2)
        self.ms2.ReleasePTT()
        
    def ms3_HDPC_via_ms1_Repeater(self):
        sleep(1)  
        self.ms3.HoldPTT()
        sleep(2)
        self.ms1.VerifyOngoingPCasREP(self.ms3, self.ms2)
        self.ms3.IsPrivateCallOngoing(self.ms2)
        self.ms2.IsPrivateCallOngoing(self.ms3)
        self.ms3.ReleasePTT()


    def ms2_emgcy_call_via_ms1_Repeater(self):
        self.ms2.HoldPTT()
        sleep(1)
        self.ms3.CheckIncomingEmergencyCall(self.ms2,self.TG)
        self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        self.ms2.ReleasePTT()
        self.ms3.CheckOngoingEmergencyCall(self.TG)
        sleep(0.5)

    
    def ms3_emgcy_call_via_ms1_Repeater(self):
        self.ms3.HoldPTT()
        sleep(1)
        self.ms2.CheckIncomingEmergencyCall(self.ms3, self.TG)
        self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
        self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 3000)
        self.ms3.CheckOngoingEmergencyCall(self.TG)
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyCall(self.TG)
        sleep(0.5)        
    
   
    def test_001_GC_via_ms1_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.MakeGC(self.TG)
            self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)            
            self.ms1.ReleasePTT()
            sleep(1)
            
            for i in range(2*self.loop):
                self.ms2_GC_via_ms1_Repeater(self.TG)
                self.ms3_GC_via_ms1_Repeater(self.TG)
                
            for i in range(self.loop):
                self.ms2_GC_via_ms1_Repeater(self.TG)

            for i in range(self.loop):
                self.ms3_GC_via_ms1_Repeater(self.TG)
            
        else:
            self.skipTest("Not supporting repeater feature")


    def test_002_HDPC_via_ms1_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            
            #HDPC to radio in emergency mode
            self.ms3.EnterEmergencyMode()
            self.ms3.PressAndReleaseKey("END")
            sleep(10)
            issi = self.ms3.issi
            self.ms2.EnterNumber(issi)
            self.ms2.PressAndHoldKey("PTT")
            self.ms2.IsTextOnScreen("Call Cancelled")
            self.ms2.ReleasePTT()
            self.ms3.ExitEmergencyMode()
            self.ms3.IsTextOnScreen("1 Missed Call")
            self.ms3.PressAndReleaseKey("END")
            
            #normal HDPC
            self.ms2.MakeHDPC_DMO(self.ms3)
            self.ms1.VerifyOngoingPCasREP(self.ms2, self.ms3)
            self.ms2.ReleasePTT()
            sleep(0.2)

            for i in range(self.loop*2):
                self.ms2_HDPC_via_ms1_Repeater()
                self.ms3_HDPC_via_ms1_Repeater()

            for i in range(self.loop):
                self.ms2_HDPC_via_ms1_Repeater()

            for i in range(self.loop):
                self.ms3_HDPC_via_ms1_Repeater()
            
        else:
            self.skipTest("Not supporting repeater feature")


    def test_003_SDS_via_ms1_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.ClearInbox(async = True)
            self.ms3.ClearInbox()
            self.ms2.wait()
            sleep(1)
            for i in range(3):
                self.ms3.IsTextOnScreen(str(i+1)+" New Message", async = True)
                self.ms2.SendPrivSDSFromTemplate(self.ms3, "long")
                self.ms3.wait()
                sleep(10)
            self.ms3.VerifyNumberOfMsgInInbox(3)
            
            self.ms1.ClearInbox(async = True)
            self.ms2.ClearInbox(async = True)
            self.ms3.ClearInbox()
            self.ms1.wait()
            self.ms2.wait()
            
            for j in range(3):
                self.ms1.IsTextOnScreen(str(j+1)+" New Message", async = True)
                self.ms3.IsTextOnScreen(str(j+1)+" New Message", async = True)
                self.ms2.SendGroupSDSFromTemplate("long")
                self.ms1.wait()
                self.ms3.wait()
                sleep(10)
            self.ms1.VerifyNumberOfMsgInInbox(3)
            self.ms3.VerifyNumberOfMsgInInbox(3)
            
        else:
            self.skipTest("Not supporting repeater feature")

    def test_004_GC_PC_radios_in_diffrent_modes(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            self.ms2.SetConfig("MS - MS")
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000)
            self.ms2.MakeGC(self.TG)
            sleep(1)
            self.ms1.VerifyIncomingGC(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)
            self.ms1.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000, async = True)
            self.ms3.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000)
            self.ms1.wait()
            self.ms1.VerifyOngoingGC(self.TG, async = True)
            self.ms3.VerifyOngoingGC(self.TG, async = True)               
            self.ms2.ReleasePTT()
            self.ms1.wait()
            self.ms3.wait()
            sleep(5)
            self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000, async = True)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000, async = True)
            self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
            self.ms1.wait()
            self.ms2.wait()
            self.ms2.MakeHDPC_DMO(self.ms3)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000, async = True)
            self.ms3.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000)
            self.ms2.wait()
            self.ms1.VerifyREPIdle(self.TG)
            self.ms1.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000, async = True)
            self.ms2.ReleasePTT()
            sleep(5)
            self.ms2.VerifyIcon("DIRECT_MODE", "DMO_ON", 30000, async = True)
            self.ms3.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
            self.ms2.wait()           
        else:
            self.skipTest("Not supporting repeater feature")
            
    def test_005_GC_with_preemption_via_ms1_repeater(self):
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            
            #preemption in reservation
            for i in range (2):
                self.ms2.MakeGC(self.TG)
                self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
                self.ms3.VerifyIncomingGC(self.ms2, self.TG)
                self.ms2.ReleasePTT()
                self.ms3.EnterEmergencyMode()
                self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
                self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 30000)
                self.ms3.ClickPTT()
                self.ms3.IsTextOnScreen("Emgcy Mic Ended")
                sleep(10)
                self.ms3.ExitEmergencyMode()
                
            #preemption in occupation
            self.ms2.MakeGC(self.TG)
            self.ms1.VerifyIncomingGCasREP(self.ms2, self.TG)
            self.ms3.VerifyIncomingGC(self.ms2, self.TG)
            self.ms3.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted", 5)
            self.ms2.IsTextOnScreen("PTT Denied", 5)
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 30000)
            self.ms2.ReleasePTT()
            self.ms3.ClickPTT()
            self.ms3.IsTextOnScreen("Emgcy Mic Ended")
            sleep(0.5)

            for i in range(self.loop):
                self.ms2_emgcy_call_via_ms1_Repeater()
                self.ms3_emgcy_call_via_ms1_Repeater()

            for i in range(self.loop):
                self.ms2_emgcy_call_via_ms1_Repeater()

            for i in range(self.loop):
                self.ms3_emgcy_call_via_ms1_Repeater()

            self.ms3.IsTextOnScreen("Emergency")
            self.ms3.ExitEmergencyMode()
            
        else:
            self.skipTest("Not supporting repeater feature")        
        
    def test_006_HDPC_with_preemption_via_ms1_repeater(self): 
        rep_mode = self.ms1.IsREPMode()
        if rep_mode:
            self.connect_repeater_sync()
            
            #preemption in reservation
            for i in range (2):
                self.ms2.MakeHDPC_DMO(self.ms3)
                self.ms1.VerifyOngoingPCasREP(self.ms2, self.ms3)
                self.ms2.ReleasePTT()
                self.ms3.EnterEmergencyMode()
                self.ms2.IsTextOnScreen("Call Preempted", 5)
                self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
                self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 30000)
                self.ms3.ClickPTT()
                self.ms3.IsTextOnScreen("Emgcy Mic Ended")
                sleep(10)
                self.ms3.ExitEmergencyMode()
                sleep(2)
            
            #preemption in occupation
            self.ms2.MakeHDPC_DMO(self.ms3)
            self.ms1.VerifyOngoingPCasREP(self.ms2, self.ms3)
            self.ms3.EnterEmergencyMode()
            self.ms2.IsTextOnScreen("Call Preempted",5)
            self.ms2.IsTextOnScreen("PTT Denied", 5)
            self.ms3.CheckOngoingEmergencyMicOn(self.TG)
            self.ms2.ReleasePTT()
            self.ms1.VerifyIncomingGCasREP(self.ms3, self.TG)
            self.ms1.VerifyIcon("EMERGENCY", "EMERGENCY_BLINK", 30000)
            self.ms2.CheckIncomingEmergencyCall(self.ms3, self.TG)
            self.ms3.HoldPTT()
            self.ms3.IsTextOnScreen("Emgcy Mic Ended")
            self.ms3.CheckOngoingEmergencyCall(self.TG)
            self.ms2.CheckIncomingEmergencyCall(self.ms3, self.TG)
            self.ms3.ReleasePTT();
            self.ms3.ExitEmergencyMode()
            self.ms2.PressAndReleaseKey("END")        
        else:
            self.skipTest("Not supporting repeater feature")

    @launch_during_rerun_if_any_test_failed
    def test_999_enter_DMO(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS", async = True)
        self.ms3.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms2.wait()            



class ms2_Repeater(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_1" ):
        super(ms2_Repeater, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG) 
        
class ms3_Repeater(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_1" ):
        super(ms3_Repeater, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG) 

class ms1_Repeater_2A(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2A" ):
        super(ms1_Repeater_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms2_Repeater_2A(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2A" ):
        super(ms2_Repeater_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms3_Repeater_2A(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_2A" ):
        super(ms3_Repeater_2A, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms1_Repeater_2B(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2B" ):
        super(ms1_Repeater_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms2_Repeater_2B(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2B" ):
        super(ms2_Repeater_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms3_Repeater_2B(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_1" ):
        super(ms3_Repeater_2B, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms1_Repeater_2C(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", TG = "DTG_H1_2C" ):
        super(ms1_Repeater_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)

class ms2_Repeater_2C(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", TG = "DTG_H1_2C" ):
        super(ms2_Repeater_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
        
class ms3_Repeater_2C(ms1_Repeater):
    def __init__(self, testname, ms1_cfg = "ms3", ms2_cfg = "ms1", ms3_cfg = "ms2", TG = "DTG_H1_2C" ):
        super(ms3_Repeater_2C, self).__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, TG)
                    
     

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms3_Repeater_2C)
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)                   
                