from ms import create_ms
import unittest
import math
from time import sleep
from mot_test import MotTestCase, always_launch_during_rerun

class clean_up(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3"):
        super(clean_up, self).__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()

    @always_launch_during_rerun
    def test_999_exit_emergency(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterDMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.SetConfig("MS - MS", async = True)
        self.ms2.SetConfig("MS - MS", async = True)
        self.ms3.SetConfig("MS - MS")
        self.ms1.wait()
        self.ms2.wait()

if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(clean_up)
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)
