from ms import create_ms, is_ms_frodo
import unittest, math, os
from time import sleep
from mot_test import MotTestCase

class ms1_Gateway(MotTestCase):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", DTG = "DTG_H1_1"):
        super().__init__(testname)
        self.ms1_cfg = ms1_cfg
        self.ms2_cfg = ms2_cfg
        self.ms3_cfg = ms3_cfg
        self.loop = 2
        self.DTG = DTG

    def setUp(self):
        self.ms1 = create_ms(self.ms1_cfg)
        self.ms2 = create_ms(self.ms2_cfg)
        self.ms3 = create_ms(self.ms3_cfg)

    def tearDown(self):
        self.ms1.destroy()
        self.ms2.destroy()
        self.ms3.destroy()
    
    def gw_sync(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()        
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterTMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG(self.DTG, async = True)
        self.ms3.ChangeTG("TG1")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterGW(async = True)       
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyTMOIdle("TG1")
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.DTG)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive only", async = True)
        self.ms2.SetConfig("Gateway")
        self.ms1.wait()
        self.ms2.VerifyDMOIdle(self.DTG)
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.ms2.wait()
        
    def gw_sync_dmo(self):
        self.ms1.Connect(async = True)
        self.ms2.Connect(async = True)
        self.ms3.Connect()        
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterTMO(async = True)
        self.ms2.EnterDMO(async = True)
        self.ms3.EnterDMO()
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG("TG1", async = True)
        self.ms2.ChangeTG(self.DTG, async = True)
        self.ms3.ChangeTG(self.DTG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.EnterGW(async = True)
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyDMOIdle(self.DTG)
        self.ms1.wait()
        self.ms2.wait()
        self.ms1.ChangeTG(self.DTG)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        self.ms1.PressAndReleaseKey("END")
        self.ms2.PressAndReleaseKey("END")
        self.ms1.SetMonitor("Receive only", async = True)
        self.ms2.SetConfig("Gateway", async = True)
        self.ms3.SetConfig("Gateway")
        self.ms1.wait()
        self.ms2.wait()
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyDMOIdle(self.DTG)
        self.ms2.wait()
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.ms3.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.ms2.wait()
        self.ms3.wait()
        sleep(3)
    
    def ms2_GC_via_gw(self):
        self.ms2.MakeGC(self.DTG)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG)
        if self.ms3.isBSI():
            self.ms3.VerifyIncomingGCfromGW(self.ms2, "TG1")
        else:
            self.ms3.VerifyIncomingGC(self.ms1, "TG1")
        
        
    def ms3_GC_via_gw(self):
        self.ms3.MakeGC("TG1")
        self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        
    def VerifyReservationDmoTmo(self):
        self.ms3.VerifyReservation("TG1", async = True)
        self.ms1.VerifyReservationAsGW(self.DTG, "TG1", async = True)
        self.ms2.VerifyReservation(self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        
    def VerifyReservationTmoDmo(self):
        self.ms3.VerifyReservation("TG1", async = True)
        self.ms1.VerifyReservationAsGW("TG1", self.DTG, async = True)
        self.ms2.VerifyReservation(self.DTG)
        self.ms3.wait()
        self.ms1.wait()
            
    def test_000_init_test(self):
        self.ms1.Connect()
        self.ms1.SetCpValue("cp_all_t.cp_ergo_block.ergo_data.rw.gateway_settings.gateway_forwarding_address", self.ms2.issi)
        self.ms1.CommitCp()  
            
    def test_001_call_in_DMO_via_gateway_changovers_resetups(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        for i in range(2):
            self.ms2_GC_via_gw()
            self.ms2.ReleasePTT()
            self.VerifyReservationDmoTmo()
            sleep(3)
            self.ms3_GC_via_gw()
            self.ms3.ReleasePTT()
            self.VerifyReservationTmoDmo()
            sleep(3)
        for i in range(3):
            self.ms2_GC_via_gw()
            self.ms2.ReleasePTT()
            self.VerifyReservationDmoTmo()
            sleep(3)
                
    def test_002_call_in_TMO_via_gateway_changovers_resetups(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        for i in range(2):
            self.ms3_GC_via_gw()
            self.ms3.ReleasePTT()
            self.VerifyReservationTmoDmo()
            sleep(3)
            self.ms2_GC_via_gw()
            self.ms2.ReleasePTT()
            self.VerifyReservationDmoTmo()
            sleep(3)
        for i in range(3):
            self.ms3_GC_via_gw()
            self.ms3.ReleasePTT()
            self.VerifyReservationTmoDmo()
            sleep(3)
                
                
    def test_003_preemption_of_call_in_TMO_by_synchronized_radio_in_DMO(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms3_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in occupation")
        self.ms2.EnterEmergencyMode()
        self.ms3.IsTextOnScreen("PTT Denied")
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG, async = True)
        if self.ms3.isBSI():
            self.ms3.VerifyIncomingGCfromGW(self.ms2, "TG1")
        else:
            self.ms3.VerifyIncomingGC(self.ms1, "TG1")
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()
        sleep(3)
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyTMOIdle("TG1", async = True)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        self.ms2.wait()
        self.ms3.wait()
        self.ms3_GC_via_gw()
        sleep(2)
        self.logger.info("Starting preemption in reservation")
        self.ms3.ReleasePTT()
        self.VerifyReservationTmoDmo()
        sleep(1)
        self.ms2.EnterEmergencyMode()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG, async = True)
        if self.ms3.isBSI():
            self.ms3.VerifyIncomingGCfromGW(self.ms2, "TG1")
        else:
            self.ms3.VerifyIncomingGC(self.ms1, "TG1")
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()
    
    def test_004_preemption_of_call_in_DMO_by_radio_in_TMO(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms2_GC_via_gw()
        sleep(2)
        self.ms3.EnterEmergencyMode(async = True)
        self.ms2.IsTextOnScreen("Call Ended", async = True)
        self.ms1.IsTextOnScreen("Call Ended")
        self.ms2.wait()
        self.ms3.wait()
        self.ms2.ReleasePTT()
        self.ms3.CheckOngoingEmergencyMicOn("TG1", async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG, async = True)
        self.ms2.CheckIncomingEmergencyCall(self.ms3, self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms3.ExitEmergencyMode()          
            
    def test_005_DMO_call_by_synchornized_and_unsynchronized_radio(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync_dmo()
        self.ms3.SetConfig("MS - MS")
        self.ms3.MakeGC(self.DTG)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        sleep(2)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_STANDBY", 30000)
        self.ms3.ReleasePTT()
        self.ms2.VerifyIcon("TOWER", "TOWER_ON", 30000, async = True)
        self.ms1.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.ms2.wait()
        self.ms2.MakeGC(self.DTG)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG)
        self.ms3.VerifyIncomingGC(self.ms2, self.DTG)
        self.ms2.ReleasePTT()      
        
    def test_006_DMO_preemption_of_DMO_call_via_gw(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync_dmo()
        self.ms3.MakeGC(self.DTG)        
        self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        self.logger.info("Starting preemption")
        self.ms2.EnterEmergencyMode()
        self.ms3.IsTextOnScreen("Channel Busy")
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG, async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms2, self.DTG)
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()  

    def test_007_interrupt_of_call_in_DMO_by_radio_in_TMO(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        # self.ms3.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.ptt_during_rcv_grpcall', 1)
        # self.ms3.CommitCp()
        self.ms2_GC_via_gw()
        sleep(2)
        self.ms3.HoldPTT()
        self.ms2.IsTextOnScreen("PTT Denied")
        self.ms2.ReleasePTT()
        self.ms3.VerifyOngoingGC("TG1", async = True)
        if self.ms1.isBSI():
            self.logger.warning("TEMPORARY SOLUTION because of CCMPD01942720 - [SigTests] BSI Gateway don't show OPTA after TMO radio interrupt DMO call")
            self.ms1.IsTextOnScreen(["Gateway"])
            self.ms1.IsTextOnScreen(["ID: "+str(self.ms3.issi)], async = True)
        else:
            self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG, async = True)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms3.ReleasePTT()      
        
    def test_008_preemption_of_call_in_DMO_by_GW(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms2_GC_via_gw()
        sleep(2)
        self.ms1.EnterEmergencyMode(async = True)
        self.ms2.IsTextOnScreen("Call Ended", async = True)
        self.ms3.IsTextOnScreen("Call Preempted")
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ReleasePTT()
        self.ms1.CheckOngoingEmergencyMicOn("TG1", async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms1, "TG1", async = True)
        self.ms2.VerifyDMOIdle(self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms1.ExitEmergencyMode()
        
    def test_009_preemption_of_call_in_TMO_by_GW(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms3_GC_via_gw()
        sleep(2)
        self.ms1.EnterEmergencyMode()
        self.ms3.IsTextOnScreen("Call Preempted")
        self.ms3.ReleasePTT()
        self.ms1.CheckOngoingEmergencyMicOn("TG1", async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms1, "TG1", async = True)
        self.ms2.VerifyDMOIdle(self.DTG)
        self.ms3.wait()
        self.ms1.wait()
        self.ms1.ExitEmergencyMode()
     
    def test_010_sds_via_gw_from_DMO_to_TMO(self):
        msg_counter = 3
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms1.ClearInbox(async = True)
        self.ms3.ClearInbox()
        self.ms1.wait()
        for i in range(msg_counter):
            self.ms2.SendGroupSDSFromTemplate("vlong")
            self.ms1.IsTextOnScreen(str(i+1)+" New Message", async = True)
            self.ms3.IsTextOnScreen(str(i+1)+" New Message")
            self.ms1.wait()
        sleep(10)
        self.ms1.VerifyNumberOfMsgInInbox(msg_counter, async = True)
        self.ms3.VerifyNumberOfMsgInInbox(msg_counter)
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms3.ClearInbox()
        self.ms1.wait()
        for i in range(msg_counter):
            self.ms2.SendPrivSDSFromTemplate(self.ms3, "vlong")
            self.ms3.IsTextOnScreen(str(i+1)+" New Message")
        sleep(10)
        self.ms3.VerifyNumberOfMsgInInbox(msg_counter)
        self.ms3.ClearInbox()
        
        
    def test_011_sds_via_gw_from_TMO_to_DMO(self):
        msg_counter = 3
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox(async = True)
        self.ms3.ClearInbox()
        self.ms1.wait()
        self.ms2.wait()
        for i in range(msg_counter):
            self.ms3.SendGroupSDSFromTemplate("vlong")
            self.ms1.IsTextOnScreen(str(i+1)+" New Message", async = True)
            self.ms2.IsTextOnScreen(str(i+1)+" New Message", async = True)
            self.ms3.IsTextOnScreen(str(i+1)+" New Message")
            self.ms1.wait()
            self.ms2.wait()
            self.ms3.PressAndReleaseKey("END")
        sleep(10)
        self.ms1.VerifyNumberOfMsgInInbox(msg_counter, async = True)
        self.ms2.VerifyNumberOfMsgInInbox(msg_counter, async = True)
        self.ms3.VerifyNumberOfMsgInInbox(msg_counter)
        self.ms2.wait()
        self.ms1.wait()
        self.ms1.ClearInbox(async = True)
        self.ms2.ClearInbox(async = True)
        self.ms3.ClearInbox()
        self.ms1.wait()
        self.ms2.wait()
        for i in range(msg_counter):
            self.ms3.SendPrivSDSFromTemplate(self.ms1, "vlong")
            self.ms2.IsTextOnScreen(str(i+1)+" New Message")
        sleep(10)
        self.ms2.VerifyNumberOfMsgInInbox(msg_counter)
        self.ms2.ClearInbox()
        

        
class ms1_Gateway_2A(ms1_Gateway):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", DTG = "DTG_H1_2A"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)
        
    def test_006_DMO_preemption_of_DMO_call_via_gw(self):
        if not is_ms_frodo(self.ms1_cfg):
            self.skipTest("Not supporting gateway feature")
        self.gw_sync_dmo()
        self.ms3.MakeGC(self.DTG)        
        self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG)
        self.ms2.VerifyIncomingGC(self.ms3, self.DTG)
        self.logger.info("Starting preemption")
        self.ms2.EnterEmergencyMode()
        self.ms3.IsTextOnScreen("Channel Busy")
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyMicOn(self.DTG, async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG, async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms2, self.DTG)
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()    
        sleep(3)
        self.ms2.VerifyDMOIdle(self.DTG, async = True)
        self.ms3.VerifyDMOIdle(self.DTG, async = True)
        self.ms1.VerifyGWIdle("TG1", self.DTG)
        self.ms2.wait()
        self.ms3.wait()
        self.ms2.ChangeTG("DTG_H1_1")
        self.ms3.MakeGC(self.DTG)        
        self.ms1.VerifyIncomingGCasGW(self.ms3, "TG1", self.DTG)
        self.ms2.VerifyDMOIdle("DTG_H1_1")
        self.logger.info("Starting clear preemption")
        self.ms2.EnterEmergencyMode()
        self.ms3.IsTextOnScreen("Call Preempted")
        self.ms3.ReleasePTT()
        self.ms2.CheckOngoingEmergencyMicOn("DTG_H1_1", async = True)
        self.ms1.VerifyIncomingGCasGW(self.ms2, "TG1", self.DTG, async = True)
        self.ms3.CheckIncomingEmergencyCall(self.ms2, self.DTG)
        self.ms2.wait()
        self.ms1.wait()
        self.ms2.ExitEmergencyMode()  

class ms1_Gateway_2B(ms1_Gateway_2A):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", DTG = "DTG_H1_2B"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG) 
        
class ms1_Gateway_2C(ms1_Gateway_2A):
    def __init__(self, testname, ms1_cfg = "ms1", ms2_cfg = "ms2", ms3_cfg = "ms3", DTG = "DTG_H1_2C"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG) 

class ms2_Gateway(ms1_Gateway):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", DTG = "DTG_H1_1"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG) 

class ms2_Gateway_2A(ms1_Gateway_2A):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", DTG = "DTG_H1_2A"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG) 

class ms2_Gateway_2B(ms1_Gateway_2A):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", DTG = "DTG_H1_2B"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)         
        
class ms2_Gateway_2C(ms1_Gateway_2A):
    def __init__(self, testname, ms1_cfg = "ms2", ms2_cfg = "ms1", ms3_cfg = "ms3", DTG = "DTG_H1_2C"):
        super().__init__(testname, ms1_cfg, ms2_cfg, ms3_cfg, DTG)           
                
if __name__ == "__main__":
    suite1 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway)
    suite2 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway_2A)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ms1_Gateway_2C)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(ms2_Gateway)
    suite5 = unittest.TestLoader().loadTestsFromTestCase(ms2_Gateway_2A)
    suite6 = unittest.TestLoader().loadTestsFromTestCase(ms2_Gateway_2C)
    # suite = unittest.TestSuite([suite1, suite2, suite3, suite4, suite5, suite6])
    suite = unittest.TestSuite([suite1])
    unittest.TextTestRunner(verbosity=2).run(suite)                     