from ms import create_ms, RCException
import unittest
from time import sleep
from mot_test import MotTestCase, launch_during_rerun_if_any_test_failed

class SDS_reception_tests_Ms1TxMs2Rx(MotTestCase):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms2", msGwRep_cfg = "ms3", tg = "DTG_H1_1"):
        super().__init__(testname)
        self.msTX_cfg = msTX_cfg
        self.msRX_cfg = msRX_cfg
        self.msGwRep_cfg = msGwRep_cfg
        self.tg = tg

    def setUp(self):
        self.msTX = create_ms(self.msTX_cfg)
        self.msRX = create_ms(self.msRX_cfg)
        self.msGwRep = create_ms(self.msGwRep_cfg)

    def tearDown(self):
        self.msTX.destroy()
        self.msRX.destroy()   
        self.msGwRep.destroy()
        
    def connectDMO(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msGwRep.Connect()
        self.msTX.wait()
        self.msRX.wait()
        
        self.msTX.EnterDMO(async = True)
        self.msRX.EnterDMO(async = True)
        self.msGwRep.EnterDMO()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.SetConfig("MS - MS", async = True)
        self.msRX.SetConfig("MS - MS", async = True)
        self.msTX.wait()
        self.msRX.wait()

        self.changeToTalkgroup([self.msTX, self.msRX, self.msGwRep], self.tg)

        self.msTX.ClearInbox(async = True)
        self.msRX.ClearInbox(async = True)
        self.msGwRep.ClearInbox()
        self.msTX.wait()
        self.msRX.wait()

    @launch_during_rerun_if_any_test_failed
    def test_000_setup(self):
        self.msTX.Connect(async = True)
        self.msGwRep.Connect()
        self.msTX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)
        self.msGwRep.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 1)

        self.msTX.CommitCp(async = True)
        self.msGwRep.CommitCp()
        self.msTX.wait()

    @launch_during_rerun_if_any_test_failed
    def test_999_teardown(self):
        self.msTX.Connect(async = True)
        self.msRX.Connect(async = True)
        self.msGwRep.Connect()
        self.msTX.wait()
        self.msRX.wait()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', 0)
        self.msRX.SetCpValue('cp_all_t.cp_dll_block.dll_data.dev_and_test[31]', 0)
        self.msGwRep.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.ro.feature_flags.dmo_emergency_alarm', 0)

        self.msTX.CommitCp(async = True)
        self.msRX.CommitCp(async = True)
        self.msGwRep.CommitCp()
        self.msTX.wait()
        self.msRX.wait()

    def sendGroupSds(self, srcMs):
        srcMs.SendGroupSDSFromTemplate("vlong")
        sleep(2)

    def sendPrivateSds(self, srcMs, dstMs):
        srcMs.SendPrivSDSFromTemplate(dstMs, "vlong")

    def changeToTalkgroup(self, msesList, tg):
        for ms in msesList:
            ms.ChangeTG(tg, async = True)
        for ms in msesList:
            ms.wait()

    # DMO_SDS_RX_T_001
    # DMO_SDS_RX_T_004 
    # DMO_SDS_RX_T_011
    def test_001_send_and_receive_group_sds_in_idle(self):
        self.connectDMO()

        mses = [self.msTX, self.msRX]

        talkgroups = ["DTG_H1_1", "DTG_H1_2A", "DTG_H1_2B", "DTG_H1_2C", "DTG_OG"]

        for tg in talkgroups:
            self.changeToTalkgroup(mses, tg)

            for i in range(0, 5):
                self.sendGroupSds(self.msTX)

            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(5)
            self.msRX.ClearInbox()

    # DMO_SDS_RX_T_002
    # DMO_SDS_RX_T_006
    def test_002_send_and_receive_5_private_sds_in_idle(self):
        self.connectDMO()

        outgoing_security_class = {"clear" : 0, 
                                   "2a" : 2,
                                   "2b" : 3,
                                   "2c" : 1}

        for cp_sec_val in outgoing_security_class.values():
            self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', cp_sec_val)
            self.msTX.CommitCp()

            for i in range(0, 5):
                self.sendPrivateSds(self.msTX, self.msRX)

            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(5)
            self.msRX.ClearInbox()

        self.msTX.SetCpValue('cp_all_t.cp_ergo_block.ergo_data.rw.dmo_sck_parameters.default_outgoing_security_class', outgoing_security_class["clear"])
        self.msTX.CommitCp()

    # DMO_SDS_RX_T_003
    def test_003_send_and_receive_100_group_sds_in_idle(self):
        self.connectDMO()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.CommitCp()

        num_of_sdses = 100
        for i in range(0, num_of_sdses):
            self.sendGroupSds(self.msTX)

        try:
            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        except RCException as rcErr:
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses-1)

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.CommitCp()

    # DMO_SDS_RX_T_005
    def test_005_send_and_receive_100_private_sds_in_idle(self):
        self.connectDMO()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.CommitCp()

        num_of_sdses = 100
        for i in range(0, num_of_sdses):
            self.sendPrivateSds(self.msTX, self.msRX)

        try:
            self.msRX.PressAndReleaseKey("END")
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses)
        except RCException as rcErr:
            self.msRX.VerifyNumberOfMsgInInbox(num_of_sdses-1)

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.CommitCp()

    # DMO_SDS_RX_T_007
    def test_007_reception_of_group_sds_in_TXI_mode(self):
        self.connectDMO()

        self.msRX.EnterTXI()
        self.msRX.ClickPTT()
        self.msRX.IsTextOnScreen("Not Allowed In TXI Mode")

        for i in range(0, 5):
            self.sendGroupSds(self.msTX)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(5)

    # DMO_SDS_RX_T_008
    # DMO_SDS_RX_T_009
    def test_008_reception_of_group_sds_via_repeater(self):
        self.connectDMO()

        self.msGwRep.EnterREP()
        self.msTX.SetConfig("Repeater", async = True)
        self.msRX.SetConfig("Repeater", async = True)
        self.msTX.wait()
        self.msRX.wait()

        self.msGwRep.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
        self.msTX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        self.msRX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)

        for i in range(0, 5):
            self.sendGroupSds(self.msTX)
            self.msTX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 0)
            self.msRX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 0)

        self.msRX.PressAndReleaseKey("END")
        self.msGwRep.PressAndReleaseKey("END")

        self.msRX.VerifyNumberOfMsgInInbox(5, async = True)
        self.msGwRep.VerifyNumberOfMsgInInbox(5, async = True)
        self.msRX.wait()
        self.msGwRep.wait()

    # DMO_SDS_RX_T_010
    def test_010_reception_of_group_sds_via_repeater_on_radio_not_synced_with_rep(self):
        self.connectDMO()

        self.msGwRep.EnterREP(async = True)
        self.msTX.SetConfig("Repeater")
        self.msGwRep.wait()

        self.msGwRep.VerifyIcon("REPEATER_MODE", "REPEATER_MODE", 30000)
        self.msTX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 30000)
        self.msRX.VerifyIcon("DIRECT_MODE", "DMO_ON", 0)

        for i in range(0, 5):
            self.sendGroupSds(self.msTX)
            self.msTX.VerifyIcon("REPEATER_MODE", "REPEATER_ON", 0)
            self.msRX.VerifyIcon("DIRECT_MODE", "DMO_ON", 0)

        self.msRX.PressAndReleaseKey("END")

        self.msRX.VerifyNumberOfMsgInInbox(5)

    # DMO_SDS_RX_T_012
    def test_011_ms_ignores_sds_to_unknown_mni(self):
        self.connectDMO()

        self.msRX.ChangeTG("DTG_I1_1")

        self.sendGroupSds(self.msTX)

        self.msRX.PressAndReleaseKey("END")
        self.msRX.VerifyNumberOfMsgInInbox(0)

    # DMO_SDS_TX_001
    # DMO_SDS_TX_006
    def test_012_send_and_receive_10_group_sds_via_gateway(self):
        self.connectDMO()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msTX.CommitCp()

        self.msGwRep.EnterGW()
        self.msTX.SetConfig("Gateway", async = True)
        self.msRX.SetConfig("Gateway", async = True)
        self.msTX.wait()
        self.msRX.wait()

        self.msGwRep.VerifyIcon("GATEWAY_MODE", "GATEWAY_ACTIVE", 30000)
        self.msTX.VerifyIcon("TOWER", "TOWER_ON", 30000)
        self.msRX.VerifyIcon("TOWER", "TOWER_ON", 30000)

        for i in range(0, 10):
            self.sendGroupSds(self.msTX)
            self.msTX.VerifyIcon("TOWER", "TOWER_ON", 0)
            self.msRX.VerifyIcon("TOWER", "TOWER_ON", 0)

        self.msRX.PressAndReleaseKey("END")
        self.msGwRep.PressAndReleaseKey("END")

        self.msRX.VerifyNumberOfMsgInInbox(10, async = True)
        self.msGwRep.VerifyNumberOfMsgInInbox(10, async = True)
        self.msRX.wait()
        self.msGwRep.wait()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.CommitCp()

    # DMO_SDS_TX_001
    # DMO_SDS_TX_007
    def test_013_send_and_receive_10_group_sds_via_repeater(self):
        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 2)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 1)
        self.msTX.CommitCp()

        self._test_008_reception_of_group_sds_via_repeater()

        self.msTX.SetCpValue('cp_all_t.cp_dll_block.dll_data.sds_udata_fcd', 4)
        self.msTX.SetCpValue('cp_all_t.cp_cmcecc_block.cmcecc_data.n314_dmcc_def', 3)
        self.msTX.CommitCp()

    # DMO_SDS_TX_001
    # DMO_SDS_TX_009
    def test_014_start_GC_after_sds_transmission(self):
        self.connectDMO()

        self.sendGroupSds(self.msTX)

        self.msTX.MakeGC(self.tg)
        self.msRX.VerifyIncomingGC(self.msTX, self.tg)
        self.msGwRep.VerifyIncomingGC(self.msTX, self.tg)
        self.msTX.ReleasePTT()
        self.msRX.wait()
        self.msGwRep.wait()

    # DMO_SDS_TX_001
    # DMO_SDS_TX_009
    def test_015_start_HDPC_after_sds_transmission(self):
        self.connectDMO()

        self.sendGroupSds(self.msTX)

        self.msTX.MakeHDPC_DMO(self.msRX)
        self.msRX.IsPrivateCallOngoing(self.msTX)
        self.msTX.ReleasePTT()

class SDS_reception_tests_Ms1RxMs2Tx(SDS_reception_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms2", msRX_cfg = "ms1", msGwRep_cfg = "ms3", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msGwRep_cfg)
        
class SDS_reception_tests_Ms3RxMs1Tx(SDS_reception_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms1", msRX_cfg = "ms3", msGwRep_cfg = "ms2", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msGwRep_cfg)
        
class SDS_reception_tests_Ms3TxMs1Rx(SDS_reception_tests_Ms1TxMs2Rx):
    def __init__(self, testname, msTX_cfg = "ms3", msRX_cfg = "ms1", msGwRep_cfg = "ms2", tg = "DTG_H1_2C"):
        super().__init__(testname, msTX_cfg, msRX_cfg, msGwRep_cfg)

if __name__ == "__main__":
    suite = unittest.TestSuite([unittest.TestLoader().loadTestsFromTestCase(SDS_reception_tests_Ms1TxMs2Rx),
                                unittest.TestLoader().loadTestsFromTestCase(SDS_reception_tests_Ms1RxMs2Tx)
    ])
    unittest.TextTestRunner(verbosity=2).run(suite)                     
